<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>رویه‌های ارسال | بیوتی پینک - فروشگاه لوازم آرایشی</title>
    <!-- Bootstrap 5 RTL -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Minimal Custom CSS -->
    <style>
    .bg-pink-light {
        background: linear-gradient(to left, #ff85a2, #ffaccb);
    }

    .text-pink {
        color: #d63384;
    }

    .btn-pink {
        background-color: #d63384;
        color: white;
    }

    .btn-pink:hover {
        background-color: #c22575;
        color: white;
    }

    .shipping-step {
        border-right: 3px solid #d63384;
        transition: all 0.3s;
    }

    .shipping-step:hover {
        transform: translateX(-5px);
        box-shadow: 0 5px 15px rgba(214, 51, 132, 0.1);
    }
    </style>
</head>

<body class="bg-pink-light">
    <!-- Header -->
    <header class="bg-gradient py-5" style="background: linear-gradient(135deg, #ff85a2 0%, #d63384 100%);">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h1 class="text-white display-4 fw-bold mb-3">
                        <i class="fas fa-truck me-2"></i>رویه‌های ارسال بیوتی پینک
                    </h1>
                    <p class="lead text-white">اطلاعات کامل درباره فرآیند ارسال و تحویل سفارشات</p>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div class="container my-5">
        <!-- Shipping Overview -->
        <div class="row mb-5">
            <div class="col-12">
                <div class="card shadow-sm border-0">
                    <div class="card-body p-4">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <h2 class="text-pink mb-3">تحویل سریع و مطمئن سفارشات شما</h2>
                                <p class="lead">ما در بیوتی پینک تلاش می‌کنیم سفارشات شما را در کوتاه‌ترین زمان ممکن با
                                    بهترین روش‌های حمل و نقل تحویل دهیم.</p>
                                <div class="d-flex flex-wrap gap-2 mt-4">
                                    <span class="badge bg-pink text-white py-2 px-3">
                                        <i class="fas fa-check-circle me-1"></i>ارسال به تمام نقاط ایران
                                    </span>
                                    <span class="badge bg-pink text-white py-2 px-3">
                                        <i class="fas fa-check-circle me-1"></i>بسته‌بندی حرفه‌ای
                                    </span>
                                    <span class="badge bg-pink text-white py-2 px-3">
                                        <i class="fas fa-check-circle me-1"></i>پشتیبانی تا لحظه تحویل
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-6 mt-4 mt-md-0">
                                <img src="https://cdn.pixabay.com/photo/2018/03/10/12/00/teamwork-3213924_1280.jpg"
                                    alt="تیم ارسال بیوتی پینک" class="img-fluid rounded-3 shadow">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Shipping Steps -->
        <div class="row mb-5">
            <div class="col-12">
                <h2 class="text-center text-pink mb-4">فرآیند ارسال سفارشات</h2>

                <div class="row g-4">
                    <!-- Step 1 -->
                    <div class="col-md-6 col-lg-3">
                        <div class="card h-100 border-0 shipping-step p-3">
                            <div class="card-body text-center">
                                <div class="bg-pink text-white rounded-circle p-3 mx-auto mb-3"
                                    style="width: 70px; height: 70px;">
                                    <i class="fas fa-shopping-cart fa-2x"></i>
                                </div>
                                <h4 class="text-pink">ثبت سفارش</h4>
                                <p>پس از ثبت نهایی سفارش در سایت، کد رهگیری برای شما ارسال می‌شود.</p>
                                <span class="badge bg-secondary">زمان: فوری</span>
                            </div>
                        </div>
                    </div>

                    <!-- Step 2 -->
                    <div class="col-md-6 col-lg-3">
                        <div class="card h-100 border-0 shipping-step p-3">
                            <div class="card-body text-center">
                                <div class="bg-pink text-white rounded-circle p-3 mx-auto mb-3"
                                    style="width: 70px; height: 70px;">
                                    <i class="fas fa-box-open fa-2x"></i>
                                </div>
                                <h4 class="text-pink">آماده‌سازی</h4>
                                <p>سفارش شما با دقت بسته‌بندی شده و برای ارسال آماده می‌شود.</p>
                                <span class="badge bg-secondary">زمان: 24 ساعت</span>
                            </div>
                        </div>
                    </div>

                    <!-- Step 3 -->
                    <div class="col-md-6 col-lg-3">
                        <div class="card h-100 border-0 shipping-step p-3">
                            <div class="card-body text-center">
                                <div class="bg-pink text-white rounded-circle p-3 mx-auto mb-3"
                                    style="width: 70px; height: 70px;">
                                    <i class="fas fa-truck fa-2x"></i>
                                </div>
                                <h4 class="text-pink">تحویل به پست</h4>
                                <p>سفارش شما به پست یا پیک موتوری تحویل داده می‌شود.</p>
                                <span class="badge bg-secondary">زمان: 1 روز کاری</span>
                            </div>
                        </div>
                    </div>

                    <!-- Step 4 -->
                    <div class="col-md-6 col-lg-3">
                        <div class="card h-100 border-0 shipping-step p-3">
                            <div class="card-body text-center">
                                <div class="bg-pink text-white rounded-circle p-3 mx-auto mb-3"
                                    style="width: 70px; height: 70px;">
                                    <i class="fas fa-home fa-2x"></i>
                                </div>
                                <h4 class="text-pink">تحویل به شما</h4>
                                <p>سفارش شما طبق زمانبندی اعلام شده تحویل داده می‌شود.</p>
                                <span class="badge bg-secondary">زمان: 1-3 روز</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Shipping Methods -->
        <div class="row mb-5">
            <div class="col-12">
                <div class="card shadow-sm border-0">
                    <div class="card-body p-4">
                        <h2 class="text-center text-pink mb-4">روش‌های ارسال</h2>

                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>روش ارسال</th>
                                        <th>هزینه</th>
                                        <th>زمان تحویل</th>
                                        <th>پوشش جغرافیایی</th>
                                        <th>ویژگی‌ها</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <i class="fas fa-motorcycle text-pink me-2"></i>
                                            پیک موتوری
                                        </td>
                                        <td>رایگان (بالای 300 هزار تومان)</td>
                                        <td>همان روز (تهران)</td>
                                        <td>فقط تهران</td>
                                        <td>
                                            <span class="badge bg-pink text-white">پرداخت در محل</span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <i class="fas fa-truck text-pink me-2"></i>
                                            تیپاکس
                                        </td>
                                        <td>25,000 تومان</td>
                                        <td>1-2 روز کاری</td>
                                        <td>شهرهای بزرگ</td>
                                        <td>
                                            <span class="badge bg-pink text-white">پیگیری آنلاین</span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <i class="fas fa-plane text-pink me-2"></i>
                                            پست پیشتاز
                                        </td>
                                        <td>35,000 تومان</td>
                                        <td>2-4 روز کاری</td>
                                        <td>سراسر کشور</td>
                                        <td>
                                            <span class="badge bg-pink text-white">بیمه شده</span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <i class="fas fa-store text-pink me-2"></i>
                                            تحویل در فروشگاه
                                        </td>
                                        <td>رایگان</td>
                                        <td>1 روز کاری</td>
                                        <td>تهران، شعبه مرکزی</td>
                                        <td>
                                            <span class="badge bg-pink text-white">مشاوره رایگان</span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Delivery Time Estimate -->
        <div class="row">
            <div class="col-md-6 mb-4 mb-md-0">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-body p-4">
                        <h3 class="text-pink mb-4">
                            <i class="fas fa-clock me-2"></i>زمان‌بندی تخمینی تحویل
                        </h3>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item d-flex justify-content-between align-items-center border-0">
                                تهران
                                <span class="badge bg-pink rounded-pill">1-2 روز کاری</span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center border-0">
                                شهرهای مرکزی
                                <span class="badge bg-pink rounded-pill">2-3 روز کاری</span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center border-0">
                                شهرهای شمالی
                                <span class="badge bg-pink rounded-pill">3-4 روز کاری</span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center border-0">
                                شهرهای جنوبی
                                <span class="badge bg-pink rounded-pill">4-5 روز کاری</span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center border-0">
                                مناطق دورافتاده
                                <span class="badge bg-pink rounded-pill">5-7 روز کاری</span>
                            </li>
                        </ul>
                        <div class="alert alert-warning mt-3">
                            <i class="fas fa-info-circle me-2"></i>این زمان‌ها تقریبی بوده و ممکن است تحت تأثیر شرایط
                            خاص (مانند تعطیلات رسمی) تغییر کند.
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-body p-4">
                        <h3 class="text-pink mb-4">
                            <i class="fas fa-question-circle me-2"></i>سوالات متداول ارسال
                        </h3>
                        <div class="accordion" id="shippingFAQ">
                            <div class="accordion-item border-0 mb-2">
                                <h2 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#faq1">
                                        آیا امکان تغییر آدرس پس از ارسال وجود دارد؟
                                    </button>
                                </h2>
                                <div id="faq1" class="accordion-collapse collapse" data-bs-parent="#shippingFAQ">
                                    <div class="accordion-body">
                                        خیر، پس از ثبت سفارش و پردازش آن، امکان تغییر آدرس وجود ندارد. لطفاً قبل از
                                        نهایی کردن سفارش، آدرس را با دقت بررسی کنید.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item border-0 mb-2">
                                <h2 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#faq2">
                                        چگونه می‌توانم سفارش خود را پیگیری کنم؟
                                    </button>
                                </h2>
                                <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#shippingFAQ">
                                    <div class="accordion-body">
                                        پس از ارسال سفارش، کد رهگیری برای شما پیامک خواهد شد. می‌توانید این کد را در
                                        سایت پست ایران یا تیپاکس وارد کنید. همچنین می‌توانید از بخش "پیگیری سفارش" در
                                        حساب کاربری خود استفاده نمایید.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item border-0">
                                <h2 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#faq3">
                                        آیا برای محصولات آسیب‌دیده در حین ارسال تضمینی وجود دارد؟
                                    </button>
                                </h2>
                                <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#shippingFAQ">
                                    <div class="accordion-body">
                                        تمام سفارشات ما بیمه شده ارسال می‌شوند. در صورت آسیب دیدن محصول در حین حمل و
                                        نقل، لطفاً بدون دریافت بسته، مراتب را به پشتیبانی ما اطلاع دهید تا پیگیری لازم
                                        انجام شود.
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a href="contact.html" class="btn btn-pink w-100 mt-3">
                            <i class="fas fa-headset me-2"></i>تماس با پشتیبانی ارسال
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-center text-md-start">
                    <p class="mb-0">© ۲۰۲۳ بیوتی پینک - تمام حقوق محفوظ است</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <a href="#" class="text-white text-decoration-none me-3">قوانین ارسال</a>
                    <a href="#" class="text-white text-decoration-none">حریم خصوصی</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>