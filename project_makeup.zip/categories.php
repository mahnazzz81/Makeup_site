<?php
// اتصال به دیتابیس با کنترل خطا
require_once __DIR__ . '/db.php';

if (!$conn) {
    die("خطا در اتصال به دیتابیس. لطفاً تنظیمات دیتابیس را بررسی کنید.");
}

// دریافت نام دسته‌بندی با فیلتر کردن
$category_name = isset($_GET['category']) ? 
    $conn->real_escape_string($_GET['category']) : 
    die("دسته‌بندی مشخص نشده است");

// کوئری با استفاده از prepared statement
$query = "SELECT * FROM products WHERE category = ?";
$stmt = $conn->prepare($query);

if (!$stmt) {
    die("خطا در آماده‌سازی کوئری: " . $conn->error);
}

$stmt->bind_param("s", $category_name);
$stmt->execute();
$result = $stmt->get_result();
$products = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html dir="rtl" lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($category_name) ?> | فروشگاه آرایشی</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <style>
    .product-card {
        border: none;
        border-radius: 10px;
        transition: all 0.3s;
        margin-bottom: 20px;
    }

    .product-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    }

    .discount-badge {
        background-color: #ff6b6b;
        color: white;
        padding: 3px 10px;
        border-radius: 5px;
        font-size: 0.8rem;
    }

    .original-price {
        text-decoration: line-through;
        color: #999;
        font-size: 0.9rem;
    }

    .category-title {
        color: #ff6b6b;
        border-bottom: 2px solid #ff6b6b;
        padding-bottom: 10px;
        margin-bottom: 30px;
    }

    .filter-section {
        background-color: #f8f9fa;
        border-radius: 10px;
        padding: 15px;
    }
    </style>
</head>

<body>
    <?php include 'includes/header.php'; ?>

    <div class="container py-5">
        <!-- عنوان دسته‌بندی -->
        <h1 class="text-center category-title"><?= htmlspecialchars($category_name) ?></h1>

        <div class="row">
            <!-- سایدبار فیلترها -->
            <div class="col-md-3">
                <div class="filter-section mb-4">
                    <h5 class="mb-3">فیلترها</h5>
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" id="inStock">
                        <label class="form-check-label" for="inStock">فقط کالاهای موجود</label>
                    </div>

                    <h6 class="mt-4">برند</h6>
                    <?php
                    // دریافت برندهای این دسته‌بندی
                    $brands_query = "SELECT DISTINCT brand FROM products WHERE category = ?";
                    $stmt = $conn->prepare($brands_query);
                    $stmt->bind_param("s", $category_name);
                    $stmt->execute();
                    $brands = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                    
                    foreach ($brands as $brand): ?>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="brand<?= $brand['brand'] ?>">
                        <label class="form-check-label" for="brand<?= $brand['brand'] ?>"><?= $brand['brand'] ?></label>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- لیست محصولات -->
            <div class="col-md-9">
                <div class="row">
                    <?php foreach ($products as $product): ?>
                    <div class="col-md-4 col-6 mb-4">
                        <div class="card product-card h-100">
                            <img src="images/products/<?= $product['image'] ?>" class="card-img-top p-2"
                                alt="<?= $product['name'] ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?= $product['name'] ?></h5>
                                <p class="card-text text-muted"><?= substr($product['description'], 0, 50) ?>...</p>

                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <?php if ($product['discount'] > 0): ?>
                                        <span class="discount-badge">%<?= $product['discount'] ?></span>
                                        <span class="original-price"><?= number_format($product['price']) ?>
                                            تومان</span>
                                        <br>
                                        <span
                                            class="text-danger fw-bold"><?= number_format($product['price'] * (1 - $product['discount']/100)) ?>
                                            تومان</span>
                                        <?php else: ?>
                                        <span class="fw-bold"><?= number_format($product['price']) ?> تومان</span>
                                        <?php endif; ?>
                                    </div>
                                    <button class="btn btn-sm btn-outline-danger">
                                        <i class="bi bi-cart-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <?php include 'footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // اینجا می‌توانید اسکریپت‌های فیلتر کردن را اضافه کنید
    </script>
</body>

</html>