<?php
session_start();
require_once 'db.php';

$error = '';
if(isset($_POST['register'])) {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // اعتبارسنجی
    if(empty($name) || empty($phone) || empty($password)) {
        $error = "همه فیلدها الزامی هستند";
    } elseif(!preg_match('/^09[0-9]{9}$/', $phone)) {
        $error = "شماره تلفن معتبر نیست (مثال: 09123456789)";
    } elseif(strlen($password) < 6) {
        $error = "رمز عبور باید حداقل 6 کاراکتر باشد";
    } elseif($password != $confirm_password) {
        $error = "رمز عبور و تکرار آن مطابقت ندارند";
    } else {
        // بررسی تکراری نبودن شماره تلفن
        $stmt = $db->prepare("SELECT id FROM users WHERE phone = ?");
        $stmt->execute([$phone]);
        
        if($stmt->rowCount() > 0) {
            $error = "این شماره تلفن قبلا ثبت شده است";
        } else {
            // ثبت کاربر جدید
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $db->prepare("INSERT INTO users (name, phone, password, role) VALUES (?, ?, ?, 'user')");
            $stmt->execute([$name, $phone, $hashed_password]);
            
            $_SESSION['user'] = [
                'id' => $db->lastInsertId(),
                'name' => $name,
                'phone' => $phone,
                'role' => 'user'
            ];
            
            header('Location: profile.php');
            exit;
        }
    }
}

?>

<!DOCTYPE html>
<html dir="rtl" lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ثبت نام</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
    body {
        background-color: #f8f9fa;
    }

    .card {
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    </style>
</head>

<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="card shadow-sm">
                    <div class="card-body p-4">
                        <h2 class="card-title text-center mb-4">ثبت نام کاربر جدید</h2>

                        <?php if($error): ?>
                        <div class="alert alert-danger"><?= $error ?></div>
                        <?php endif; ?>

                        <form method="POST">
                            <div class="mb-3">
                                <label for="name" class="form-label">نام کامل</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">شماره تلفن</label>
                                <input type="tel" class="form-control" id="phone" name="phone" pattern="09[0-9]{9}"
                                    placeholder="09123456789" required>
                                <small class="text-muted">فرمت: 09123456789</small>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">رمز عبور</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <div class="mb-3">
                                <label for="confirm_password" class="form-label">تکرار رمز عبور</label>
                                <input type="password" class="form-control" id="confirm_password"
                                    name="confirm_password" required>
                            </div>
                            <button type="submit" name="register" class="btn search-button w-100">ثبت نام</button>
                        </form>

                        <div class="mt-3 text-center">
                            <a href="login.php" class="text-decoration-none">قبلا ثبت نام کرده‌اید؟ وارد شوید</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>