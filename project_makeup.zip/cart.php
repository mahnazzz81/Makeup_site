<?php
session_start();
require_once __DIR__ . '/db.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

try {
    $user_id = $_SESSION['user_id'];
    
    // کاهش تعداد یا حذف محصول
    if (isset($_GET['remove_item']) && is_numeric($_GET['remove_item'])) {
        $product_id = $_GET['remove_item'];
        
        // بررسی تعداد فعلی محصول
        $stmt = $db->prepare("SELECT quantity FROM cart WHERE user_id = ? AND product_id = ?");
        $stmt->execute([$user_id, $product_id]);
        $current_quantity = $stmt->fetchColumn();
        
        if ($current_quantity > 1) {
            // کاهش تعداد
            $stmt = $db->prepare("UPDATE cart SET quantity = quantity - 1 WHERE user_id = ? AND product_id = ?");
            $stmt->execute([$user_id, $product_id]);
            $message = "یک عدد از محصول از سبد خرید حذف شد.";
        } else {
            // حذف کامل محصول
            $stmt = $db->prepare("DELETE FROM cart WHERE user_id = ? AND product_id = ?");
            $stmt->execute([$user_id, $product_id]);
            $message = "محصول از سبد خرید حذف شد.";
        }
        
        header("Location: cart.php?removed=1&message=" . urlencode($message));
        exit();
    }

    // اگر محصول جدید اضافه شده باشد
    if (isset($_GET['added'])) {
        $query = "SELECT * FROM cart WHERE user_id = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$user_id]);
        $cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $success_message = "محصول با موفقیت به سبد خرید اضافه شد!";
    } else {
        // حالت عادی
        $query = "SELECT * FROM cart WHERE user_id = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$user_id]);
        $cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // محاسبه جمع کل
    $total_price = 0;
    foreach ($cart_items as $item) {
        $price = isset($item['price']) ? (int) str_replace(',', '', $item['price']) : 0;
        $qty = isset($item['quantity']) ? (int) $item['quantity'] : 1;
        $total_price += $price * $qty;
    }

    // به‌روزرسانی سبد خرید
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_cart'])) {
        foreach ($_POST['quantity'] as $product_id => $quantity) {
            $quantity = (int)$quantity;
            if ($quantity > 0) {
                $stmt = $db->prepare("UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?");
                $stmt->execute([$quantity, $_SESSION['user_id'], $product_id]);
            } else {
                $stmt = $db->prepare("DELETE FROM cart WHERE user_id = ? AND product_id = ?");
                $stmt->execute([$_SESSION['user_id'], $product_id]);
            }
        }
        header("Location: cart.php");
        exit();
    }

} catch(PDOException $e) {
    die("خطا در دریافت سبد خرید: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سبد خرید</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style.css">
    <style>
    .product-quantity {
        min-width: 30px;
        display: inline-block;
        text-align: center;
    }

    .remove-btn {
        cursor: pointer;
        transition: color 0.2s;
    }

    .remove-btn:hover {
        color: #dc3545 !important;
    }
    </style>
</head>

<body>

    <div class="container mt-5">
        <?php if(isset($_GET['removed']) && isset($_GET['message'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?= htmlspecialchars($_GET['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if(isset($success_message)): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?= htmlspecialchars($success_message) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-8">
                <div class="card mb-3">
                    <div class="card-header" style="background-color: #ec5a8be6;">
                        <h5 class="text-white">سبد خرید شما</h5>
                    </div>
                    <div class="card-body">
                        <?php if(empty($cart_items)): ?>
                        <div class="text-center py-4">
                            <i class="bi bi-cart-x" style="font-size: 3rem; color: #6c757d;"></i>
                            <p class="mt-3">سبد خرید شما خالی است</p>
                            <a href="products.php" class="btn search-button">مشاهده محصولات</a>
                        </div>
                        <?php else: ?>
                        <?php foreach ($cart_items as $item): ?>
                        <div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
                            <div class="d-flex align-items-center">
                                <?php if(isset($item['image']) && !empty($item['image'])): ?>
                                <img src="images/products/<?= htmlspecialchars($item['image']) ?>"
                                    alt="<?= htmlspecialchars($item['product_name']) ?>" class="img-thumbnail me-3"
                                    style="width: 110px; height: 110px; object-fit: cover;">
                                <?php endif; ?>
                                <div>
                                    <h6 class="m-2"><?= htmlspecialchars($item['product_name']) ?></h6>
                                    <?php if(isset($item['description']) && !empty($item['description'])): ?>
                                    <p class="text-muted"><?= htmlspecialchars($item['description']) ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="fw-bold"><?= number_format($item['price']) ?> تومان</span>
                                <span class="mx-2 product-quantity">× <?= $item['quantity'] ?></span>
                                <a href="cart.php?remove_item=<?= $item['product_id'] ?>"
                                    class="text-danger remove-btn me-2"
                                    onclick="return confirm('آیا از حذف یک عدد از این محصول از سبد خرید مطمئن هستید؟')">
                                    <i class="bi bi-trash-fill"></i>
                                </a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </div>

                </div>
                <a href="index.php" class="btn search-button py-2 fs-6 fs-md-5" style="white-space: nowrap;">
                    <i class="bi bi-arrow-right"></i>
                    بازگشت به صفحه اصلی
                </a>
            </div>

            <div class="col-md-4">
                <div class="card">
                    <div class="card-header" style="background-color: #ec5a8be6;">
                        <h5 class="text-white">جمع کل</h5>
                    </div>
                    <div class="card-body align-items-center">
                        <div class="d-flex justify-content-between mb-3">
                            <span class="fw-bold">جمع سبد خرید</span>
                            <span class="fw-bold"><?= number_format($total_price) ?> تومان</span>
                        </div>
                        <hr>
                        <?php if(!empty($cart_items)): ?>
                        <a href="checkout.php" class="btn search-button w-100">پرداخت</a>
                        <p class="text-muted small mt-2">کالا پس از پرداخت برای شما ارسال خواهد شد.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // تایید قبل از حذف
    function confirmRemove() {
        return confirm('آیا از حذف یک عدد از این محصول از سبد خرید مطمئن هستید؟');
    }
    </script>
</body>

</html>