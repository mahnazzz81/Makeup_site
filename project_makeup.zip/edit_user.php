<?php
session_start();
require_once 'db.php';

// بررسی سطح دسترسی
if(!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header('Location: login.php');
    exit;
}

// دریافت ID کاربر
$user_id = $_GET['id'] ?? null;
if(!$user_id) {
    header('Location: admin_users.php');
    exit;
}

// دریافت اطلاعات کاربر
try {
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if(!$user) {
        $_SESSION['error'] = "کاربر مورد نظر یافت نشد";
        header('Location: admin_users.php');
        exit;
    }
} catch(PDOException $e) {
    die("خطا در دریافت اطلاعات کاربر: " . $e->getMessage());
}

// پردازش فرم ویرایش
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $nationalcode = trim($_POST['nationalcode']);
    $birth_date = trim($_POST['birth_date']);
    $address = trim($_POST['address']);
    $role = trim($_POST['role']);
    
    try {
        $stmt = $db->prepare("UPDATE users SET 
                             name = ?, 
                             phone = ?, 
                             nationalcode = ?, 
                             birth_date = ?, 
                             address = ?, 
                             role = ? 
                             WHERE id = ?");
        $stmt->execute([$name, $phone, $nationalcode, $birth_date, $address, $role, $user_id]);
        
        $_SESSION['success'] = "اطلاعات کاربر با موفقیت به روز رسانی شد";
        header('Location: user_details.php?id=' . $user_id);
        exit;
    } catch(PDOException $e) {
        $error = "خطا در به روز رسانی اطلاعات: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html dir="rtl" lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ویرایش کاربر - <?= htmlspecialchars($user['name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>

<body>
    <div class="container py-4">
        <div class="row">
            <!-- سایدبار -->
            <div class="col-md-3">
                <!-- مانند فایل user_details.php -->
            </div>

            <!-- محتوای اصلی -->
            <div class="col-md-9">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="mb-0">ویرایش اطلاعات کاربر</h4>
                    <a href="user_details.php?id=<?= $user['id'] ?>" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-right"></i> بازگشت
                    </a>
                </div>

                <?php if(isset($error)): ?>
                <div class="alert alert-danger"><?= $error ?></div>
                <?php endif; ?>

                <div class="card shadow-sm">
                    <div class="card-body">
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="name" class="form-label">نام کامل</label>
                                        <input type="text" class="form-control" id="name" name="name"
                                            value="<?= htmlspecialchars($user['name']) ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="phone" class="form-label">شماره تلفن</label>
                                        <input type="text" class="form-control" id="phone" name="phone"
                                            value="<?= htmlspecialchars($user['phone']) ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="nationalcode" class="form-label">کد ملی</label>
                                        <input type="text" class="form-control" id="nationalcode" name="nationalcode"
                                            value="<?= htmlspecialchars($user['nationalcode']) ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="birth_date" class="form-label">تاریخ تولد</label>
                                        <input type="date" class="form-control" id="birth_date" name="birth_date"
                                            value="<?= htmlspecialchars($user['birth_date']) ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label for="address" class="form-label">آدرس</label>
                                        <textarea class="form-control" id="address" name="address"
                                            rows="3"><?= htmlspecialchars($user['address']) ?></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label for="role" class="form-label">نقش</label>
                                        <select class="form-select" id="role" name="role" required>
                                            <option value="user" <?= $user['role'] == 'user' ? 'selected' : '' ?>>کاربر
                                                عادی</option>
                                            <option value="admin" <?= $user['role'] == 'admin' ? 'selected' : '' ?>>مدیر
                                            </option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn" style="background-color:#f07fa5ea;">
                                <i class="bi bi-save"></i> ذخیره تغییرات
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>