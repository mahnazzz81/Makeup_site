<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>فرصت‌های شغلی | بیوتی پینک - فروشگاه لوازم آرایشی</title>
    <!-- Bootstrap 5 RTL -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Minimal Custom CSS -->
    <style>
    .bg-pink-light {
        background: linear-gradient(to left, #ff85a2, #ffaccb);
    }

    .text-pink {
        color: #d63384;
    }

    .btn-pink {
        background-color: #d63384;
        color: white;
    }

    .btn-pink:hover {
        background-color: #c22575;
        color: white;
    }

    .job-card {
        transition: transform 0.3s;
    }

    .job-card:hover {
        transform: translateY(-5px);
    }
    </style>
</head>

<body class="bg-pink-light">
    <!-- Header -->
    <header class="bg-gradient py-5" style="background: linear-gradient(135deg, #ff85a2 0%, #d63384 100%);">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h1 class="text-white display-4 fw-bold mb-3">
                        <i class="fas fa-briefcase me-2"></i>فرصت‌های شغلی در بیوتی پینک
                    </h1>
                    <p class="lead text-white">همراه ما باشید و آینده زیبایی را بسازید</p>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div class="container my-5">
        <div class="row">
            <div class="col-12">
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-body p-4">
                        <h3 class="text-pink mb-4">چرا در بیوتی پینک کار کنید؟</h3>
                        <div class="row g-4">
                            <div class="col-md-6 col-lg-3">
                                <div class="d-flex align-items-center">
                                    <div class="flex-shrink-0 bg-pink text-white rounded-circle p-3 me-3">
                                        <i class="fas fa-heart fa-lg"></i>
                                    </div>
                                    <div>
                                        <h5 class="mb-0">محیط کاری پویا</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-3">
                                <div class="d-flex align-items-center">
                                    <div class="flex-shrink-0 bg-pink text-white rounded-circle p-3 me-3">
                                        <i class="fas fa-coins fa-lg"></i>
                                    </div>
                                    <div>
                                        <h5 class="mb-0">حقوق و مزایای رقابتی</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-3">
                                <div class="d-flex align-items-center">
                                    <div class="flex-shrink-0 bg-pink text-white rounded-circle p-3 me-3">
                                        <i class="fas fa-chart-line fa-lg"></i>
                                    </div>
                                    <div>
                                        <h5 class="mb-0">فرصت رشد حرفه‌ای</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-3">
                                <div class="d-flex align-items-center">
                                    <div class="flex-shrink-0 bg-pink text-white rounded-circle p-3 me-3">
                                        <i class="fas fa-gift fa-lg"></i>
                                    </div>
                                    <div>
                                        <h5 class="mb-0">تخفیف ویژه محصولات</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Job Listings -->
        <div class="row g-4">
            <!-- Job 1 -->
            <div class="col-md-6 col-lg-4">
                <div class="card shadow-sm border-0 h-100 job-card">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <span class="badge bg-pink text-white">فول‌تایم</span>
                            <span class="text-muted"><i class="far fa-calendar-alt me-1"></i>۲ روز پیش</span>
                        </div>
                        <h4 class="text-pink">کارشناس فروش و مشاوره</h4>
                        <p class="text-muted"><i class="fas fa-map-marker-alt me-2"></i>تهران، شعبه مرکزی</p>
                        <ul class="list-unstyled">
                            <li class="mb-2"><i class="fas fa-check-circle text-pink me-2"></i>حداقل ۲ سال سابقه کار در
                                فروش لوازم آرایشی</li>
                            <li class="mb-2"><i class="fas fa-check-circle text-pink me-2"></i>تسلط به محصولات آرایشی و
                                بهداشتی</li>
                            <li class="mb-2"><i class="fas fa-check-circle text-pink me-2"></i>مهارت ارتباطی عالی</li>
                        </ul>
                        <div class="d-flex justify-content-between align-items-center mt-4">
                            <h5 class="mb-0 text-pink">حقوق: از ۸ میلیون تومان</h5>
                            <button class="btn btn-pink">ارسال رزومه</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Job 2 -->
            <div class="col-md-6 col-lg-4">
                <div class="card shadow-sm border-0 h-100 job-card">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <span class="badge bg-pink text-white">پاره‌وقت</span>
                            <span class="text-muted"><i class="far fa-calendar-alt me-1"></i>۱ هفته پیش</span>
                        </div>
                        <h4 class="text-pink">انباردار و مسئول لجستیک</h4>
                        <p class="text-muted"><i class="fas fa-map-marker-alt me-2"></i>کرج، شهرک صنعتی</p>
                        <ul class="list-unstyled">
                            <li class="mb-2"><i class="fas fa-check-circle text-pink me-2"></i>تجربه کار با نرم‌افزارهای
                                انبارداری</li>
                            <li class="mb-2"><i class="fas fa-check-circle text-pink me-2"></i>مسلط به اکسل و گزارش‌گیری
                            </li>
                            <li class="mb-2"><i class="fas fa-check-circle text-pink me-2"></i>دقت و نظم بالا</li>
                        </ul>
                        <div class="d-flex justify-content-between align-items-center mt-4">
                            <h5 class="mb-0 text-pink">حقوق: توافقی</h5>
                            <button class="btn btn-pink">ارسال رزومه</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Job 3 -->
            <div class="col-md-6 col-lg-4">
                <div class="card shadow-sm border-0 h-100 job-card">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <span class="badge bg-pink text-white">دورکاری</span>
                            <span class="text-muted"><i class="far fa-calendar-alt me-1"></i>۳ روز پیش</span>
                        </div>
                        <h4 class="text-pink">تولیدکننده محتوا برای اینستاگرام</h4>
                        <p class="text-muted"><i class="fas fa-map-marker-alt me-2"></i>دورکاری</p>
                        <ul class="list-unstyled">
                            <li class="mb-2"><i class="fas fa-check-circle text-pink me-2"></i>تسلط به ادیت عکس و ویدیو
                                (Photoshop, Premiere)</li>
                            <li class="mb-2"><i class="fas fa-check-circle text-pink me-2"></i>آشنایی با ترندهای آرایشی
                            </li>
                            <li class="mb-2"><i class="fas fa-check-circle text-pink me-2"></i>خلاقیت و ایده‌پردازی قوی
                            </li>
                        </ul>
                        <div class="d-flex justify-content-between align-items-center mt-4">
                            <h5 class="mb-0 text-pink">حقوق: پروژه‌ای</h5>
                            <button class="btn btn-pink">ارسال رزومه</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Application Form -->
        <div class="row mt-5">
            <div class="col-lg-8 mx-auto">
                <div class="card shadow-sm border-0">
                    <div class="card-body p-4">
                        <h3 class="text-pink text-center mb-4">فرم عمومی ارسال رزومه</h3>
                        <form>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="fullname" class="form-label">نام کامل</label>
                                    <input type="text" class="form-control" id="fullname" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="phone" class="form-label">شماره تماس</label>
                                    <input type="tel" class="form-control" id="phone" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="email" class="form-label">ایمیل</label>
                                    <input type="email" class="form-control" id="email" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="position" class="form-label">عنوان شغلی مورد نظر</label>
                                    <input type="text" class="form-control" id="position" required>
                                </div>
                                <div class="col-12">
                                    <label for="experience" class="form-label">سابقه کار مرتبط (سال)</label>
                                    <input type="number" class="form-control" id="experience" min="0">
                                </div>
                                <div class="col-12">
                                    <label for="cv" class="form-label">ارسال رزومه (PDF)</label>
                                    <input type="file" class="form-control" id="cv" accept=".pdf">
                                </div>
                                <div class="col-12">
                                    <label for="message" class="form-label">توضیحات اضافی (اختیاری)</label>
                                    <textarea class="form-control" id="message" rows="3"></textarea>
                                </div>
                                <div class="col-12 mt-3">
                                    <button type="submit" class="btn btn-pink w-100 py-2">ارسال درخواست</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-center text-md-start">
                    <p class="mb-0">© ۲۰۲۳ بیوتی پینک - تمام حقوق محفوظ است</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <a href="#" class="text-white text-decoration-none me-3">قوانین استخدام</a>
                    <a href="#" class="text-white text-decoration-none">حریم خصوصی</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>