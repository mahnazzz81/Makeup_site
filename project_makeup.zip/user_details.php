<?php
session_start();
require_once 'db.php';

// بررسی سطح دسترسی
if(!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header('Location: login.php');
    exit;
}

// دریافت ID کاربر از پارامتر URL
$user_id = $_GET['id'] ?? null;
if(!$user_id) {
    header('Location: admin_users.php');
    exit;
}

// دریافت اطلاعات کاربر از دیتابیس
try {
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if(!$user) {
        $_SESSION['error'] = "کاربر مورد نظر یافت نشد";
        header('Location: admin_users.php');
        exit;
    }
} catch(PDOException $e) {
    die("خطا در دریافت اطلاعات کاربر: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html dir="rtl" lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>جزئیات کاربر - <?= htmlspecialchars($user['name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
    .user-detail-card {
        border-left: 4px solid #9c1e48;
    }

    .detail-label {
        font-weight: bold;
        color: #6c757d;
    }
    </style>
</head>

<body>
    <div class="container py-4">
        <div class="row">
            <!-- سایدبار -->
            <div class="col-md-3">
                <div class="card shadow-sm sticky-top" style="top: 20px;">
                    <div class="card-body p-0">
                        <div class="list-group list-group-flush rounded">
                            <a href="dashboard.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-speedometer2 me-2"></i> داشبورد
                            </a>
                            <a href="admin_users.php" class="list-group-item list-group-item-action active py-3"
                                style="background-color: #9c1e48 !important; border:none !important;">
                                <i class="bi bi-people me-2"></i> کاربران
                            </a>
                            <!-- سایر لینک‌های منو -->
                        </div>
                    </div>
                </div>
            </div>

            <!-- محتوای اصلی -->
            <div class="col-md-9">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="mb-0">جزئیات کاربر</h4>
                    <a href="admin_users.php" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-right"></i> بازگشت
                    </a>
                </div>

                <div class="card shadow-sm user-detail-card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <span class="detail-label">نام کامل:</span>
                                    <p><?= htmlspecialchars($user['name']) ?></p>
                                </div>
                                <div class="mb-3">
                                    <span class="detail-label">شماره تلفن:</span>
                                    <p><?= htmlspecialchars($user['phone']) ?></p>
                                </div>
                                <div class="mb-3">
                                    <span class="detail-label">کد ملی:</span>
                                    <p><?= htmlspecialchars($user['nationalcode']) ?></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <span class="detail-label">نقش:</span>
                                    <p>
                                        <span
                                            class="badge <?= $user['role'] == 'admin' ? 'bg-danger' : 'bg-secondary' ?>">
                                            <?= $user['role'] == 'admin' ? 'مدیر' : 'کاربر عادی' ?>
                                        </span>
                                    </p>
                                </div>
                                <div class="mb-3">
                                    <span class="detail-label">تاریخ تولد:</span>
                                    <p><?= htmlspecialchars($user['birth_date']) ?></p>
                                </div>
                                <div class="mb-3">
                                    <span class="detail-label">آدرس:</span>
                                    <p><?= htmlspecialchars($user['address']) ?></p>
                                </div>
                            </div>
                        </div>

                        <div class="mt-4">
                            <a href="edit_user.php?id=<?= $user['id'] ?>" class="btn"
                                style="background-color: #9c1e48 ;">
                                <i class="bi bi-pencil text-white">ویرایش اطلاعات</i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>