<?php
session_start();
require_once 'db.php';

if(!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user']['id'];

// دریافت اطلاعات پرداخت و آدرس از فرم
$payment_method = $_POST['payment_method']; // مثلاً 'credit_card' یا 'online'
$shipping_address = $_POST['shipping_address']; // آدرس کاربر

// محاسبه جمع کل سبد خرید
$cart_total = 0;
$cart_items = $db->query("SELECT * FROM cart WHERE user_id = $user_id")->fetchAll();
foreach($cart_items as $item) {
    $cart_total += $item['price'] * $item['quantity'];
}

// شروع تراکنش دیتابیس
$db->beginTransaction();

try {
    // 1. ایجاد سفارش جدید
    $order_query = "INSERT INTO orders 
                    (user_id, total_price, payment_method, shipping_address, status)
                    VALUES (?, ?, ?, ?, 'processing')";
    $order_stmt = $db->prepare($order_query);
    $order_stmt->execute([$user_id, $cart_total, $payment_method, $shipping_address]);
    $order_id = $db->lastInsertId();
    
    // 2. انتقال آیتم‌های سبد خرید به orders_items
    $items_query = "INSERT INTO orders_items 
                    (order_id, product_id, product_name, product_image, quantity, price, final_price)
                    SELECT ?, p.id, p.name, p.image, c.quantity, p.price, p.price
                    FROM cart c
                    JOIN products p ON c.product_id = p.id
                    WHERE c.user_id = ?";
    $items_stmt = $db->prepare($items_query);
    $items_stmt->execute([$order_id, $user_id]);
    
    // 3. خالی کردن سبد خرید
    $db->query("DELETE FROM cart WHERE user_id = $user_id");
    
    $db->commit();
    
    $_SESSION['order_success'] = "سفارش شما با موفقیت ثبت شد. شماره سفارش: #$order_id";
    header("Location: order_details.php?id=$order_id");
    exit;
    
} catch(PDOException $e) {
    $db->rollBack();
    $_SESSION['order_error'] = "خطا در ثبت سفارش: " . $e->getMessage();
    header("Location: checkout.php");
    exit;
}