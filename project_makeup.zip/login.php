<?php
session_start();
require_once 'db.php';

$error = '';

if(isset($_POST['login'])) {
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    
    // اعتبارسنجی شماره تلفن
    if(!preg_match('/^09[0-9]{9}$/', $phone)) {
        $error = "شماره تلفن معتبر نیست (مثال: 09123456789)";
    } else {
        $stmt = $db->prepare("SELECT * FROM users WHERE phone = ?");
        $stmt->execute([$phone]);
        $user = $stmt->fetch();
        
        if($user && password_verify($password, $user['password'])) {
            $_SESSION['user'] = $user;
            $_SESSION['user_id'] = $user['id']; // اضافه کردن user_id به session
            
            if(isset($user['role']) && $user['role'] === 'admin') {
                header('Location: dashboard.php');
            } else {
                header('Location: index.php');
            }
            exit;
        } else {
            $error = "شماره تلفن یا رمز عبور اشتباه است";
        }
    }

}

?>

<!DOCTYPE html>
<html dir="rtl" lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ورود به حساب کاربری</title>
    <!-- Bootstrap 5 RTL -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/fonts.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
    body {
        background-color: #f8f9fa;
        font-family: Vazirmatn, sans-serif;
    }

    .login-container {
        position: relative;
        max-width: 416px;
        min-height: 496px;
        border-radius: 4px;
        background-color: white;
        border: 1px solid #d4d4d4;
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
    }

    .login-logo {
        width: 164px;
        height: 64px;
    }

    .form-input {
        border: 1px solid #d4d4d4;
        border-radius: 4px;
        padding: 12px;
        width: 100%;
    }

    .form-input:focus {
        outline: none;
        border-color: #000;
    }

    .login-btn {
        background-color: #EC4899;
        color: white;
        border: none;
        border-radius: 4px;
        padding: 10px;
        width: 100%;
    }
    </style>
</head>

<body>
    <div class="container d-flex justify-content-center align-items-center min-vh-100 p-3">
        <div class="login-container p-4 p-md-5">
            <!-- Logo -->
            <div class="text-center mb-5">
                <img src="images/logo.jpg" alt="Logo" class="login-logo">
            </div>

            <!-- Login Form -->
            <div>
                <h1 class="h4 fw-bold mb-4">ورود به حساب کاربری</h1>
                <p class="text-secondary mb-4">لطفا شماره موبایل و رمز عبور خود را وارد کنید.</p>

                <?php if($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
                <?php endif; ?>

                <form method="POST" action="">
                    <!-- Phone Number Input -->
                    <div class="mb-3">
                        <input type="tel" name="phone" id="phoneNumber" class="form-input py-2 ltr-text"
                            placeholder="09123456789" maxlength="11" dir="ltr" required>
                    </div>

                    <!-- Password Input -->
                    <div class="mb-3">
                        <input type="password" name="password" id="password" class="form-input py-2"
                            placeholder="رمز عبور" required>
                    </div>

                    <!-- Submit Button -->
                    <button type="submit" name="login" class="login-btn mt-4">
                        ورود
                    </button>
                </form>

                <!-- Register Link -->
                <p class="text-center mt-3">
                    حساب کاربری ندارید؟
                    <a href="register.php" class="text-primary text-decoration-none">ثبت نام کنید</a>
                </p>

                <!-- Privacy Policy -->
                <p class="text-muted text-center mt-4 small">
                    ورود به منزله پذیرش
                    <a href="privacy.php" class="text-primary text-decoration-none">قوانین حریم خصوصی</a>
                    است.
                </p>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // تبدیل اعداد به انگلیسی هنگام ورود
    document.querySelector('.ltr-text').addEventListener('input', function(e) {
        this.value = this.value.replace(/[۰-۹]/g, function(d) {
            return String.fromCharCode(d.charCodeAt(0) - 1728);
        });
    });
    </script>
</body>

</html>