<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>وبلاگ زیبایی | بیوتی پینک</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
    .bg-pink {
        background: linear-gradient(to left, #ff85a2, #ffaccb);
    }

    .text-pink {
        color: #ff66b3 !important;
    }

    .blog-card {
        transition: transform 0.3s;
    }

    .blog-card:hover {
        transform: translateY(-5px);
    }

    .category-badge {
        position: absolute;
        top: 10px;
        left: 10px;
        z-index: 2;
    }
    </style>
</head>

<body class="bg-light">
    <!-- هدر -->
    <header class="bg-pink text-white py-5">
        <div class="container text-center">
            <h1 class="display-4 fw-bold mb-3"><i class="bi bi-pen"></i> وبلاگ زیبایی بیوتی پینک</h1>
            <p class="lead mb-4">تازه‌ترین مقالات مراقبت پوست، آرایش و زیبایی</p>
            <div class="d-flex justify-content-center">
                <div class="w-75">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="جستجو در مقالات...">
                        <button class="btn btn-light text-pink" type="button"><i class="bi bi-search"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- محتوای اصلی -->
    <div class="container py-5">
        <div class="row">
            <!-- مقالات اصلی -->
            <div class="col-lg-8">
                <!-- مقاله ویژه -->
                <div class="card border-0 shadow-lg mb-5 blog-card">
                    <span class="category-badge bg-danger text-white px-3 py-1 rounded-pill">پوست</span>
                    <img src="https://via.placeholder.com/800x400/ff66b3/ffffff?text=Beauty+Blog" class="card-img-top"
                        alt="مقاله ویژه">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <small class="text-muted me-3"><i class="bi bi-calendar me-1"></i> ۲۵ خرداد ۱۴۰۲</small>
                            <small class="text-muted"><i class="bi bi-eye me-1"></i> ۱,۲۴۵ بازدید</small>
                        </div>
                        <h2 class="card-title h3">راهنمای کامل مراقبت از پوست در فصل تابستان</h2>
                        <p class="card-text">در این مقاله شما را با بهترین روش‌های مراقبت از پوست در برابر آفتاب داغ
                            تابستان آشنا می‌کنیم. از کرم‌های ضد آفتاب تا روش‌های آبرسانی پوست...</p>
                        <a href="#" class="btn btn-pink mt-3">ادامه مطلب <i class="bi bi-arrow-left"></i></a>
                    </div>
                </div>

                <!-- لیست مقالات -->
                <div class="row g-4">
                    <!-- مقاله 1 -->
                    <div class="col-md-6">
                        <div class="card h-100 border-0 shadow-sm blog-card">
                            <span class="category-badge bg-success text-white px-3 py-1 rounded-pill">آرایش</span>
                            <img src="https://via.placeholder.com/400x250/ff66b3/ffffff?text=Makeup"
                                class="card-img-top" alt="مقاله آرایش">
                            <div class="card-body">
                                <h3 class="card-title h5">ترندهای آرایشی سال ۲۰۲۳</h3>
                                <p class="card-text text-muted small">آخرین ترندهای دنیای آرایش را بشناسید و استایل خود
                                    را به روز کنید...</p>
                            </div>
                            <div class="card-footer bg-transparent border-0">
                                <a href="#" class="btn btn-outline-pink btn-sm">مطالعه مقاله</a>
                            </div>
                        </div>
                    </div>

                    <!-- مقاله 2 -->
                    <div class="col-md-6">
                        <div class="card h-100 border-0 shadow-sm blog-card">
                            <span class="category-badge bg-primary text-white px-3 py-1 rounded-pill">مراقبت مو</span>
                            <img src="https://via.placeholder.com/400x250/ff66b3/ffffff?text=Hair+Care"
                                class="card-img-top" alt="مقاله مراقبت مو">
                            <div class="card-body">
                                <h3 class="card-title h5">۷ ماسک طبیعی برای تقویت موها</h3>
                                <p class="card-text text-muted small">با مواد طبیعی موجود در خانه موهایی پرپشت و درخشان
                                    داشته باشید...</p>
                            </div>
                            <div class="card-footer bg-transparent border-0">
                                <a href="#" class="btn btn-outline-pink btn-sm">مطالعه مقاله</a>
                            </div>
                        </div>
                    </div>

                    <!-- مقاله 3 -->
                    <div class="col-md-6">
                        <div class="card h-100 border-0 shadow-sm blog-card">
                            <span class="category-badge bg-warning text-dark px-3 py-1 rounded-pill">ناخن</span>
                            <img src="https://via.placeholder.com/400x250/ff66b3/ffffff?text=Nails" class="card-img-top"
                                alt="مقاله ناخن">
                            <div class="card-body">
                                <h3 class="card-title h5">جدیدترین طرح‌های ناخن سال</h3>
                                <p class="card-text text-muted small">با زیباترین طرح‌های ناخن ۲۰۲۳ آشنا شوید و ایده
                                    بگیرید...</p>
                            </div>
                            <div class="card-footer bg-transparent border-0">
                                <a href="#" class="btn btn-outline-pink btn-sm">مطالعه مقاله</a>
                            </div>
                        </div>
                    </div>

                    <!-- مقاله 4 -->
                    <div class="col-md-6">
                        <div class="card h-100 border-0 shadow-sm blog-card">
                            <span class="category-badge bg-info text-white px-3 py-1 rounded-pill">لوازم آرایشی</span>
                            <img src="https://via.placeholder.com/400x250/ff66b3/ffffff?text=Cosmetics"
                                class="card-img-top" alt="مقاله لوازم آرایشی">
                            <div class="card-body">
                                <h3 class="card-title h5">بهترین برندهای آرایشی سال</h3>
                                <p class="card-text text-muted small">معرفی محبوب‌ترین و باکیفیت‌ترین برندهای آرایشی
                                    دنیا...</p>
                            </div>
                            <div class="card-footer bg-transparent border-0">
                                <a href="#" class="btn btn-outline-pink btn-sm">مطالعه مقاله</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- صفحه‌بندی -->
                <nav aria-label="Page navigation" class="mt-5">
                    <ul class="pagination justify-content-center">
                        <li class="page-item disabled">
                            <a class="page-link" href="#" tabindex="-1" aria-disabled="true">قبلی</a>
                        </li>
                        <li class="page-item active"><a class="page-link" href="#">۱</a></li>
                        <li class="page-item"><a class="page-link" href="#">۲</a></li>
                        <li class="page-item"><a class="page-link" href="#">۳</a></li>
                        <li class="page-item">
                            <a class="page-link" href="#">بعدی</a>
                        </li>
                    </ul>
                </nav>
            </div>

            <!-- سایدبار -->
            <div class="col-lg-4">
                <!-- دسته‌بندی‌ها -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-pink text-white">
                        <h3 class="h6 mb-0"><i class="bi bi-tags"></i> دسته‌بندی‌ها</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                مراقبت پوست
                                <span class="badge bg-pink rounded-pill">۱۴</span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                آرایش
                                <span class="badge bg-pink rounded-pill">۲۳</span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                مراقبت مو
                                <span class="badge bg-pink rounded-pill">۹</span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                ناخن
                                <span class="badge bg-pink rounded-pill">۵</span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                لوازم آرایشی
                                <span class="badge bg-pink rounded-pill">۱۷</span>
                            </li>
                        </ul>
                    </div>
                </div>

                <!-- مقالات پرطرفدار -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-pink text-white">
                        <h3 class="h6 mb-0"><i class="bi bi-fire"></i> پرطرفدارترین‌ها</h3>
                    </div>
                    <div class="card-body">
                        <div class="list-group list-group-flush">
                            <a href="#" class="list-group-item list-group-item-action">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1">۱۰ اشتباه رایج در آرایش</h6>
                                    <small>۳ روز پیش</small>
                                </div>
                                <small class="text-muted"><i class="bi bi-eye"></i> ۲,۳۴۵ بازدید</small>
                            </a>
                            <a href="#" class="list-group-item list-group-item-action">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1">راه حل‌های خانگی برای جوش صورت</h6>
                                    <small>۱ هفته پیش</small>
                                </div>
                                <small class="text-muted"><i class="bi bi-eye"></i> ۱,۸۷۶ بازدید</small>
                            </a>
                            <a href="#" class="list-group-item list-group-item-action">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1">معرفی محصولات ضد پیری</h6>
                                    <small>۲ هفته پیش</small>
                                </div>
                                <small class="text-muted"><i class="bi bi-eye"></i> ۱,۵۴۳ بازدید</small>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- خبرنامه -->
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-pink text-white">
                        <h3 class="h6 mb-0"><i class="bi bi-envelope"></i> عضویت در خبرنامه</h3>
                    </div>
                    <div class="card-body">
                        <p class="small text-muted">با عضویت در خبرنامه از جدیدترین مقالات ما مطلع شوید.</p>
                        <div class="mb-3">
                            <input type="email" class="form-control" placeholder="آدرس ایمیل">
                        </div>
                        <button class="btn btn-pink w-100">عضویت</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- فوتر -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <h5 class="text-pink">بیوتی پینک</h5>
                    <p class="small">مرجع تخصصی مقالات زیبایی و مراقبت پوست</p>
                </div>
                <div class="col-md-4 mb-3">
                    <h5 class="text-pink">لینک‌های مفید</h5>
                    <ul class="list-unstyled small">
                        <li><a href="#" class="text-white-50">صفحه اصلی</a></li>
                        <li><a href="#" class="text-white-50">مقالات</a></li>
                        <li><a href="#" class="text-white-50">درباره ما</a></li>
                        <li><a href="#" class="text-white-50">تماس با ما</a></li>
                    </ul>
                </div>
                <div class="col-md-4 mb-3">
                    <h5 class="text-pink">شبکه‌های اجتماعی</h5>
                    <div class="d-flex">
                        <a href="#" class="text-white me-3"><i class="bi bi-instagram fs-5"></i></a>
                        <a href="#" class="text-white me-3"><i class="bi bi-telegram fs-5"></i></a>
                        <a href="#" class="text-white me-3"><i class="bi bi-whatsapp fs-5"></i></a>
                        <a href="#" class="text-white"><i class="bi bi-youtube fs-5"></i></a>
                    </div>
                </div>
            </div>
            <hr class="my-3 bg-secondary">
            <div class="text-center small text-muted">
                © ۱۴۰۲ کلیه حقوق برای بیوتی پینک محفوظ است.
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>