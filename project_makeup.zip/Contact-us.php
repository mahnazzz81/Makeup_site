<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تماس با ما | بیوتی پینک - فروشگاه لوازم آرایشی</title>
    <!-- Bootstrap 5 RTL -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Minimal Custom CSS -->
    <style>
    .bg-pink-light {
        background: linear-gradient(to left, #ff85a2, #ffaccb);
    }

    .text-pink {
        color: #d63384;
    }

    .btn-pink {
        background-color: #d63384;
        color: white;
    }

    .btn-pink:hover {
        background-color: #c22575;
        color: white;
    }
    </style>
</head>

<body class="bg-pink-light">
    <!-- Header -->
    <header class="bg-gradient py-5" style="background: linear-gradient(135deg, #ff85a2 0%, #d63384 100%);">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h1 class="text-white display-4 fw-bold mb-3">
                        <i class="fas fa-phone-alt me-2"></i>تماس با بیوتی پینک
                    </h1>
                    <p class="lead text-white">ما اینجا هستیم تا به شما کمک کنیم</p>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div class="container my-5">
        <div class="row g-4">
            <!-- Contact Form -->
            <div class="col-lg-6">
                <div class="card shadow-sm border-0">
                    <div class="card-body p-4">
                        <h3 class="text-pink mb-4">پیام به ما</h3>
                        <form>
                            <div class="mb-3">
                                <label for="name" class="form-label">نام کامل</label>
                                <input type="text" class="form-control" id="name" placeholder="نام شما">
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">ایمیل</label>
                                <input type="email" class="form-control" id="email" placeholder="example@example.com">
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">شماره تماس</label>
                                <input type="tel" class="form-control" id="phone" placeholder="09123456789">
                            </div>
                            <div class="mb-3">
                                <label for="subject" class="form-label">موضوع</label>
                                <select class="form-select" id="subject">
                                    <option selected>انتخاب کنید</option>
                                    <option>پرسش درباره محصولات</option>
                                    <option>پیگیری سفارش</option>
                                    <option>پیشنهاد یا انتقاد</option>
                                    <option>همکاری با ما</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="message" class="form-label">متن پیام</label>
                                <textarea class="form-control" id="message" rows="5"
                                    placeholder="متن پیام شما..."></textarea>
                            </div>
                            <button type="submit" class="btn btn-pink w-100 py-2">ارسال پیام</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Contact Info -->
            <div class="col-lg-6">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-body p-4">
                        <h3 class="text-pink mb-4">راه های ارتباطی</h3>

                        <div class="d-flex align-items-start mb-4">
                            <div class="flex-shrink-0 bg-pink text-white rounded-circle p-3">
                                <i class="fas fa-map-marker-alt fa-lg"></i>
                            </div>
                            <div class="ms-3">
                                <h5 class="mb-1">آدرس فروشگاه</h5>
                                <p class="text-muted mb-0">تهران، خیابان ولیعصر، پلاک ۱۲۳۴، طبقه دوم</p>
                            </div>
                        </div>

                        <div class="d-flex align-items-start mb-4">
                            <div class="flex-shrink-0 bg-pink text-white rounded-circle p-3">
                                <i class="fas fa-phone fa-lg"></i>
                            </div>
                            <div class="ms-3">
                                <h5 class="mb-1">تلفن تماس</h5>
                                <p class="text-muted mb-0">۰۲۱-۱۲۳۴۵۶۷۸</p>
                                <p class="text-muted mb-0">۰۹۱۲۳۴۵۶۷۸۹</p>
                            </div>
                        </div>

                        <div class="d-flex align-items-start mb-4">
                            <div class="flex-shrink-0 bg-pink text-white rounded-circle p-3">
                                <i class="fas fa-envelope fa-lg"></i>
                            </div>
                            <div class="ms-3">
                                <h5 class="mb-1">ایمیل</h5>
                                <p class="text-muted mb-0">info@beautypink.ir</p>
                                <p class="text-muted mb-0">support@beautypink.ir</p>
                            </div>
                        </div>

                        <div class="d-flex align-items-start mb-4">
                            <div class="flex-shrink-0 bg-pink text-white rounded-circle p-3">
                                <i class="fas fa-clock fa-lg"></i>
                            </div>
                            <div class="ms-3">
                                <h5 class="mb-1">ساعات کاری</h5>
                                <p class="text-muted mb-0">شنبه تا چهارشنبه: ۹ صبح تا ۶ عصر</p>
                                <p class="text-muted mb-0">پنجشنبه: ۹ صبح تا ۲ بعدازظهر</p>
                            </div>
                        </div>

                        <hr class="my-4">

                        <h5 class="text-pink mb-3">ما را در شبکه های اجتماعی دنبال کنید</h5>
                        <div class="d-flex gap-3">
                            <a href="#" class="btn btn-outline-pink btn-lg rounded-circle">
                                <i class="fab fa-instagram"></i>
                            </a>
                            <a href="#" class="btn btn-outline-pink btn-lg rounded-circle">
                                <i class="fab fa-telegram"></i>
                            </a>
                            <a href="#" class="btn btn-outline-pink btn-lg rounded-circle">
                                <i class="fab fa-whatsapp"></i>
                            </a>
                            <a href="#" class="btn btn-outline-pink btn-lg rounded-circle">
                                <i class="fab fa-aparat"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Map Section -->
    <div class="container mb-5">
        <div class="row">
            <div class="col-12">
                <div class="card shadow-sm border-0">
                    <div class="card-body p-0">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3239.676321926684!2d51.38882131526948!3d35.73252398018758!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzXCsDQzJzU3LjEiTiA1McKwMjMnMjMuNiJF!5e0!3m2!1sen!2sir!4v1620000000000!5m2!1sen!2sir"
                            width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy"
                            class="rounded-3"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-center text-md-start">
                    <p class="mb-0">© ۲۰۲۳ بیوتی پینک - تمام حقوق محفوظ است</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <a href="#" class="text-white text-decoration-none me-3">قوانین و مقررات</a>
                    <a href="#" class="text-white text-decoration-none">حریم خصوصی</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>