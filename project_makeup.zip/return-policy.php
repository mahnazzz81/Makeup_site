<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>شرایط مرجوعی کالا | بیوتی پینک</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
    .bg-pink {
        background: linear-gradient(to left, #ff85a2, #ffaccb);
    }

    .text-pink {
        color: #ff85a2 !important;
    }

    .return-step {
        border-right: 3px solid #ff66b3;
    }
    </style>
</head>

<body class="bg-light">
    <div class="container py-5">
        <!-- هدر -->
        <header class="bg-pink text-white p-4 mb-5 rounded text-center">
            <h1 class="mb-0"><i class="bi bi-arrow-return-left"></i> شرایط مرجوعی کالا</h1>
        </header>

        <!-- شرایط کلی -->
        <div class="bg-white p-4 rounded shadow-sm mb-5">
            <div class="alert alert-info">
                <h2 class="h4 mb-3"><i class="bi bi-info-circle"></i> نکات مهم قبل از مرجوع کردن کالا</h2>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">• کالا باید در بسته‌بندی اصلی و بدون استفاده باشد</li>
                    <li class="list-group-item">• فاکتور خرید باید همراه کالا ارسال شود</li>
                    <li class="list-group-item">• مهلت مرجوعی ۷ روز از تاریخ دریافت کالا می‌باشد</li>
                </ul>
            </div>
        </div>

        <!-- مراحل مرجوعی -->
        <div class="bg-white p-4 rounded shadow-sm mb-5">
            <h2 class="text-pink mb-4"><i class="bi bi-list-ol"></i> مراحل مرجوع کردن کالا</h2>

            <div class="row g-4">
                <div class="col-md-6">
                    <div class="d-flex">
                        <div class="return-step pe-3 me-3 text-center">
                            <div class="bg-pink text-white rounded-circle d-flex align-items-center justify-content-center"
                                style="width: 40px; height: 40px;">1</div>
                        </div>
                        <div>
                            <h3 class="h5">ثبت درخواست مرجوعی</h3>
                            <p class="text-muted small">از طریق پنل کاربری در بخش "سفارشات من" درخواست مرجوعی را ثبت
                                کنید.</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="d-flex">
                        <div class="return-step pe-3 me-3 text-center">
                            <div class="bg-pink text-white rounded-circle d-flex align-items-center justify-content-center"
                                style="width: 40px; height: 40px;">2</div>
                        </div>
                        <div>
                            <h3 class="h5">تایید توسط پشتیبانی</h3>
                            <p class="text-muted small">پشتیبانی در کمتر از ۲۴ ساعت درخواست شما را بررسی می‌کند.</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="d-flex">
                        <div class="return-step pe-3 me-3 text-center">
                            <div class="bg-pink text-white rounded-circle d-flex align-items-center justify-content-center"
                                style="width: 40px; height: 40px;">3</div>
                        </div>
                        <div>
                            <h3 class="h5">بسته‌بندی و ارسال</h3>
                            <p class="text-muted small">کالا را به همراه فاکتور در بسته‌بندی اصلی آماده کنید.</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="d-flex">
                        <div class="return-step pe-3 me-3 text-center">
                            <div class="bg-pink text-white rounded-circle d-flex align-items-center justify-content-center"
                                style="width: 40px; height: 40px;">4</div>
                        </div>
                        <div>
                            <h3 class="h5">عودت وجه</h3>
                            <p class="text-muted small">پس از بررسی کالا، وجه طی ۴۸ ساعت عودت داده می‌شود.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- موارد غیرقابل مرجوع -->
        <div class="bg-white p-4 rounded shadow-sm mb-5">
            <h2 class="text-pink mb-4"><i class="bi bi-x-circle"></i> موارد غیرقابل مرجوع</h2>
            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-3 border-danger">
                        <div class="card-body">
                            <h3 class="h6 text-danger"><i class="bi bi-exclamation-triangle"></i> محصولات آرایشی بازشده
                            </h3>
                            <p class="text-muted small">کلیه محصولات آرایشی که بسته‌بندی آنها باز شده باشد.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card mb-3 border-danger">
                        <div class="card-body">
                            <h3 class="h6 text-danger"><i class="bi bi-exclamation-triangle"></i> محصولات بهداشتی</h3>
                            <p class="text-muted small">کلیه محصولات مرتبط با بهداشت شخصی.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card mb-3 border-danger">
                        <div class="card-body">
                            <h3 class="h6 text-danger"><i class="bi bi-exclamation-triangle"></i> کالاهای تخفیف‌دار</h3>
                            <p class="text-muted small">کالاهایی که با تخفیف ویژه خریداری شده‌اند.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card mb-3 border-danger">
                        <div class="card-body">
                            <h3 class="h6 text-danger"><i class="bi bi-exclamation-triangle"></i> کالاهای سفارشی</h3>
                            <p class="text-muted small">محصولاتی که به سفارش مشتری تولید شده‌اند.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- هزینه مرجوعی -->
        <div class="bg-white p-4 rounded shadow-sm">
            <h2 class="text-pink mb-4"><i class="bi bi-cash-stack"></i> هزینه مرجوعی</h2>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="bg-pink text-white">
                        <tr>
                            <th>نوع مرجوعی</th>
                            <th>هزینه ارسال</th>
                            <th>زمان عودت وجه</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>ایراد از طرف فروشگاه</td>
                            <td>رایگان</td>
                            <td>۲۴ ساعت</td>
                        </tr>
                        <tr>
                            <td>تغییر نظر مشتری</td>
                            <td>به عهده مشتری</td>
                            <td>۴۸ ساعت پس از دریافت کالا</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- دکمه اقدام -->
        <div class="text-center mt-5">
            <a href="#" class="btn btn-pink btn-lg me-3">
                <i class="bi bi-arrow-return-left"></i> درخواست مرجوعی
            </a>
            <a href="#" class="btn btn-outline-pink btn-lg">
                <i class="bi bi-headset"></i> پشتیبانی
            </a>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>