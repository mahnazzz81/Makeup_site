<?php
session_start();
require_once 'db.php';

// بررسی آیا کاربر مدیر است یا نه
if(!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header('Location: login.php');
    exit;
}

// دریافت ID محصول از URL
$product_id = $_GET['id'] ?? 0;

// دریافت اطلاعات محصول
$product = $db->prepare("SELECT * FROM products WHERE id = ?");
$product->execute([$product_id]);
$product = $product->fetch();

if(!$product) {
    header('Location: products.php');
    exit;
}

// دریافت دسته‌بندی‌ها از دیتابیس
$categories = $db->query("SELECT * FROM categories")->fetchAll();

// پردازش فرم ارسال شده
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $category_id = $_POST['category_id'];
    $special_offer = isset($_POST['special_offer']) ? 1 : 0;
    $is_best_seller = isset($_POST['is_best_seller']) ? 1 : 0;
    $is_new_arrival = isset($_POST['is_new_arrival']) ? 1 : 0;
    $is_recommended = isset($_POST['is_recommended']) ? 1 : 0;
    $image = $product['image'];

    // آپلود تصویر جدید اگر ارسال شده باشد
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "images/products/";
        $target_file = $target_dir . basename($_FILES["image"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        
        // بررسی نوع فایل
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
            $error = "فقط فایل‌های JPG, JPEG, PNG مجاز هستند.";
        } else {
            // حذف تصویر قبلی
            if($image && file_exists($target_dir . $image)) {
                unlink($target_dir . $image);
            }
            
            // ایجاد نام منحصر به فرد برای فایل جدید
            $image = uniqid() . '.' . $imageFileType;
            move_uploaded_file($_FILES["image"]["tmp_name"], $target_dir . $image);
        }
    }

    if(!isset($error)) {
        // به روزرسانی محصول در دیتابیس
        $stmt = $db->prepare("UPDATE products SET name = ?, description = ?, price = ?, stock = ?, image = ?, category_id = ?, special_offer = ?, is_best_seller = ?, is_new_arrival = ?, is_recommended = ? WHERE id = ?");
        $stmt->execute([$name, $description, $price, $stock, $image, $category_id, $special_offer, $is_best_seller, $is_new_arrival, $is_recommended, $product_id]);
        
        $_SESSION['success'] = "محصول با موفقیت ویرایش شد.";
        header('Location: products/');
        exit;
    }
}
?>

<!DOCTYPE html>
<html dir="rtl" lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ویرایش محصول</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
    .form-container {
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        padding: 30px;
    }

    .form-label {
        font-weight: 600;
    }

    .preview-image {
        max-width: 200px;
        max-height: 200px;
        display: block;
        margin-top: 10px;
    }
    </style>
</head>

<body>
    <div class="container py-4">
        <div class="row g-4">
            <!-- سایدبار -->
            <div class="col-md-4">
                <div class="card shadow-sm sticky-top" style="top: 20px;">
                    <div class="card-body p-0">
                        <!-- منوی اصلی -->
                        <div class="list-group list-group-flush rounded">
                            <a href="dashboard.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-speedometer2 me-2"></i> داشبورد
                            </a>
                            <a href="products.php" class="list-group-item list-group-item-action active py-3"
                                style="background-color: #9c1e48 !important; border:none !important;">
                                <i class="bi bi-box-seam me-2"></i> محصولات
                            </a>
                            <a href="admin_categories.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-tags me-2"></i> دسته‌بندی‌ها
                            </a>
                            <a href="admin_orders.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-cart-check me-2"></i> سفارشات
                            </a>
                            <a href="admin_users.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-people me-2"></i> کاربران
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- محتوای اصلی -->
            <div class="col-md-8">
                <div class="form-container">
                    <h4 class="mb-4 p-style p-3 rounded text-white">ویرایش محصول</h4>

                    <?php if(isset($error)): ?>
                    <div class="alert alert-danger"><?= $error ?></div>
                    <?php endif; ?>

                    <form method="POST" enctype="multipart/form-data" action="edit-product.php?id=<?= $product_id ?>">
                        <div class="mb-3">
                            <label for="name" class="form-label">نام محصول</label>
                            <input type="text" class="form-control" id="name" name="name"
                                value="<?= htmlspecialchars($product['name']) ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="description" class="form-label">توضیحات محصول</label>
                            <textarea class="form-control" id="description" name="description" rows="3"
                                required><?= htmlspecialchars($product['description']) ?></textarea>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="price" class="form-label">قیمت (تومان)</label>
                                <input type="number" class="form-control" id="price" name="price"
                                    value="<?= $product['price'] ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="stock" class="form-label">موجودی</label>
                                <input type="number" class="form-control" id="stock" name="stock"
                                    value="<?= $product['stock'] ?>" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="category_id" class="form-label">دسته‌بندی</label>
                            <select class="form-select" id="category_id" name="category_id" required>
                                <option value="">انتخاب دسته‌بندی</option>
                                <?php foreach($categories as $category): ?>
                                <option value="<?= $category['id'] ?>"
                                    <?= $category['id'] == $product['category_id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($category['name']) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="image" class="form-label">تصویر محصول</label>
                            <input type="file" class="form-control" id="image" name="image" accept="image/*">
                            <div id="imagePreview" class="mt-2">
                                <?php if($product['image']): ?>
                                <img src="images/products/<?= $product['image'] ?>" class="preview-image"
                                    alt="تصویر فعلی">
                                <small class="text-muted d-block">تصویر فعلی محصول</small>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="special_offer"
                                        name="special_offer" <?= $product['special_offer'] ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="special_offer">پیشنهاد ویژه</label>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="is_best_seller"
                                        name="is_best_seller" <?= $product['is_best_seller'] ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="is_best_seller">پرفروش</label>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="is_new_arrival"
                                        name="is_new_arrival" <?= $product['is_new_arrival'] ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="is_new_arrival">محصول جدید</label>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="is_recommended"
                                        name="is_recommended" <?= $product['is_recommended'] ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="is_recommended">توصیه شده</label>
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">تعداد بازدید: <?= $product['views'] ?? 0 ?></label>
                        </div>

                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="submit" class="btn" style="background-color: #9c1e48; color: white;">ذخیره
                                تغییرات</button>
                            <a href="products/" class="btn btn-secondary">انصراف</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
    // نمایش پیش‌نمایش تصویر
    document.getElementById('image').addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const preview = document.getElementById('imagePreview');
                preview.innerHTML =
                    `<img src="${e.target.result}" class="preview-image" alt="پیش‌نمایش تصویر">`;
            }
            reader.readAsDataURL(file);
        }
    });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>

<!-- در بخش فرم ویرایش محصول -->