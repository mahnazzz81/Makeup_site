<?php
session_start();
require_once 'db.php';

if(!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user']['id'];

// دریافت آدرس‌های کاربر
try {
    // دریافت آدرس قدیمی از جدول users
    $user_query = "SELECT address FROM users WHERE id = ?";
    $user_stmt = $db->prepare($user_query);
    $user_stmt->execute([$user_id]);
    $user = $user_stmt->fetch();
    
    // دریافت آدرس‌های جدید از جدول user_addresses
    $addresses_query = "SELECT * FROM user_addresses WHERE user_id = ? ORDER BY is_default DESC, created_at DESC";
    $addresses_stmt = $db->prepare($addresses_query);
    $addresses_stmt->execute([$user_id]);
    $addresses = $addresses_stmt->fetchAll();
    
    // اگر آدرس قدیمی وجود دارد، به عنوان اولین آدرس نمایش داده شود
    if(!empty($user['address'])) {
        $legacy_address = [
            'id' => 0,
            'title' => 'آدرس اصلی',
            'address' => $user['address'],
            'is_default' => empty($addresses) ? 1 : 0,
            'is_legacy' => true
        ];
        array_unshift($addresses, $legacy_address);
    }
    
} catch(PDOException $e) {
    die("خطا در دریافت آدرس‌ها: " . $e->getMessage());
}

// پردازش عملیات
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if(isset($_POST['add_address'])) {
        // اگر کاربر آدرس قدیمی دارد و اولین آدرس جدید را اضافه می‌کند، آن را به عنوان پیش‌فرض تنظیم کنید
        $is_default = empty($addresses) || (count($addresses) == 1 && isset($addresses[0]['is_legacy'])) ? 1 : 0;
        
        try {
            $stmt = $db->prepare("INSERT INTO user_addresses 
                                 (user_id, title, receiver_name, phone, province, city, address, postal_code, is_default)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $user_id,
                $_POST['title'],
                $_POST['receiver_name'],
                $_POST['phone'],
                $_POST['province'],
                $_POST['city'],
                $_POST['address'],
                $_POST['postal_code'],
                $is_default
            ]);
            
            $_SESSION['message'] = "آدرس جدید با موفقیت افزوده شد";
            header("Location: addresses.php");
            exit;
            
        } catch(PDOException $e) {
            die("خطا در افزودن آدرس: " . $e->getMessage());
        }
        
    } elseif(isset($_POST['set_default'])) {
        // تنظیم آدرس پیش‌فرض
        $db->beginTransaction();
        try {
            // همه آدرس‌ها را غیرپیش‌فرض کنیم
            $db->prepare("UPDATE user_addresses SET is_default = 0 WHERE user_id = ?")->execute([$user_id]);
            // آدرس انتخاب شده را پیش‌فرض کنیم (فقط برای آدرس‌های جدید)
            if($_POST['address_id'] != 0) {
                $db->prepare("UPDATE user_addresses SET is_default = 1 WHERE id = ? AND user_id = ?")
                   ->execute([$_POST['address_id'], $user_id]);
            }
            
            $db->commit();
            $_SESSION['message'] = "آدرس پیش‌فرض با موفقیت تغییر کرد";
        } catch(PDOException $e) {
            $db->rollBack();
            $_SESSION['error'] = "خطا در تغییر آدرس پیش‌فرض";
        }
        header("Location: addresses.php");
        exit;
        
    } elseif(isset($_POST['delete_address'])) {
        // حذف آدرس (فقط آدرس‌های جدید)
        if($_POST['address_id'] != 0) {
            try {
                $stmt = $db->prepare("DELETE FROM user_addresses WHERE id = ? AND user_id = ?");
                $stmt->execute([$_POST['address_id'], $user_id]);
                
                $_SESSION['message'] = "آدرس با موفقیت حذف شد";
            } catch(PDOException $e) {
                $_SESSION['error'] = "خطا در حذف آدرس";
            }
        }
        header("Location: addresses.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html dir="rtl" lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت آدرس‌ها</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
    .address-card {
        border-left: 4px solid #ec5a8b;
        transition: all 0.3s;
    }

    .address-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    .address-card.default {
        border-left: 4px solid #28a745;
    }

    .badge-default {
        background-color: #28a745;
    }

    .legacy-address {
        border-left: 4px solid #6c757d;
    }
    </style>
</head>

<body>
    <!-- هدر و منو مانند صفحات دیگر -->

    <div class="container py-5">
        <div class="row">
            <!-- سایدبار پروفایل -->
            <div class="col-md-3">
                <div class="card shadow-sm sticky-top" style="top: 20px;">
                    <div class="card-body p-0">
                        <div class="list-group list-group-flush rounded">
                            <a href="profile.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-person-fill me-2"></i> پروفایل
                            </a>
                            <a href="orders.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-cart-check me-2"></i> سفارشات
                            </a>
                            <a href="wallet.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-wallet-fill me-2"></i> کیف پول
                            </a>
                            <a href="addresses.php" class="list-group-item list-group-item-action active py-3"
                                style="background-color: #9c1e48; border:none !important;">
                                <i class="bi bi-geo-alt-fill me-2"></i>آدرس های من
                            </a>
                            <a href="support.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-headset me-2"></i> پشتیبانی
                            </a>
                            <a href="index.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-house me-2"></i>صفحه اصلی
                            </a>
                            <a href="logout.php" class="list-group-item list-group-item-action text-danger py-3">
                                <i class="bi bi-box-arrow-left me-2"></i> خروج
                            </a>


                        </div>
                    </div>
                </div>
            </div>

            <!-- محتوای اصلی -->
            <div class="col-md-9 bg-light">
                <?php if(isset($_SESSION['message'])): ?>
                <div class="alert alert-success mb-4"><?= $_SESSION['message'] ?></div>
                <?php unset($_SESSION['message']); ?>
                <?php endif; ?>

                <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-danger mb-4"><?= $_SESSION['error'] ?></div>
                <?php unset($_SESSION['error']); ?>
                <?php endif; ?>

                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="mb-0">آدرس‌های من</h4>
                    <button class="btn search-button mt-2" data-bs-toggle="modal" data-bs-target="#addAddressModal">
                        <i class="bi bi-plus-lg me-2"></i> افزودن آدرس جدید
                    </button>
                </div>

                <?php if(empty($addresses)): ?>
                <div class="alert alert-info">
                    هنوز هیچ آدرسی ثبت نکرده‌اید.
                </div>
                <?php else: ?>
                <div class="row">
                    <?php foreach($addresses as $address): ?>
                    <div class="col-md-6 mb-4">
                        <div
                            class="card address-card h-100 <?= $address['is_default'] ? 'default' : '' ?> <?= isset($address['is_legacy']) ? 'legacy-address' : '' ?>">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <h5><?= htmlspecialchars($address['title'] ?? 'آدرس اصلی') ?></h5>
                                    <?php if($address['is_default']): ?>
                                    <span class="badge badge-default">پیش‌فرض</span>
                                    <?php endif; ?>
                                </div>

                                <div class="mb-3">
                                    <?php if(isset($address['is_legacy'])): ?>
                                    <!-- نمایش آدرس قدیمی -->
                                    <p class="mb-1"><strong>آدرس:</strong>
                                        <?= nl2br(htmlspecialchars($address['address'])) ?></p>
                                    <?php else: ?>
                                    <!-- نمایش آدرس جدید -->
                                    <p class="mb-1"><strong>تحویل گیرنده:</strong>
                                        <?= htmlspecialchars($address['receiver_name']) ?></p>
                                    <p class="mb-1"><strong>تلفن:</strong> <?= htmlspecialchars($address['phone']) ?>
                                    </p>
                                    <p class="mb-1"><strong>استان:</strong>
                                        <?= htmlspecialchars($address['province']) ?></p>
                                    <p class="mb-1"><strong>شهر:</strong> <?= htmlspecialchars($address['city']) ?></p>
                                    <p class="mb-1"><strong>آدرس:</strong>
                                        <?= nl2br(htmlspecialchars($address['address'])) ?></p>
                                    <?php if(!empty($address['postal_code'])): ?>
                                    <p class="mb-1"><strong>کد پستی:</strong>
                                        <?= htmlspecialchars($address['postal_code']) ?></p>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </div>

                                <div class="d-flex">
                                    <?php if(!$address['is_default']): ?>
                                    <form method="POST" class="me-2">
                                        <input type="hidden" name="address_id" value="<?= $address['id'] ?>">
                                        <button type="submit" name="set_default" class="btn btn-sm btn-outline-success">
                                            تنظیم به عنوان پیش‌فرض
                                        </button>
                                    </form>
                                    <?php endif; ?>

                                    <?php if(!isset($address['is_legacy'])): ?>
                                    <!-- دکمه حذف فقط برای آدرس‌های جدید نمایش داده شود -->
                                    <form method="POST" onsubmit="return confirm('آیا از حذف این آدرس مطمئن هستید؟')">
                                        <input type="hidden" name="address_id" value="<?= $address['id'] ?>">
                                        <button type="submit" name="delete_address"
                                            class="btn btn-sm btn-outline-danger">
                                            حذف آدرس
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- مودال افزودن آدرس جدید -->
    <div class="modal fade" id="addAddressModal" tabindex="-1" aria-labelledby="addAddressModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title search-button" id="addAddressModalLabel">افزودن آدرس جدید</h5>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="title" class="form-label">عنوان آدرس</label>
                                <input type="text" class="form-control" id="title" name="title" required
                                    placeholder="مثال: خانه، محل کار">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="receiver_name" class="form-label">نام تحویل گیرنده</label>
                                <input type="text" class="form-control" id="receiver_name" name="receiver_name"
                                    required>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="phone" class="form-label">تلفن تماس</label>
                                <input type="text" class="form-control" id="phone" name="phone" required
                                    pattern="09[0-9]{9}" placeholder="09123456789">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="postal_code" class="form-label">کد پستی (اختیاری)</label>
                                <input type="text" class="form-control" id="postal_code" name="postal_code"
                                    pattern="\d{10}">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="province" class="form-label">استان</label>
                                <input type="text" class="form-control" id="province" name="province" required
                                    placeholder="مثال: تهران">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="city" class="form-label">شهر</label>
                                <input type="text" class="form-control" id="city" name="city" required
                                    placeholder="مثال: مشهد">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="address" class="form-label">آدرس کامل</label>
                            <textarea class="form-control" id="address" name="address" rows="4" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">انصراف</button>
                        <button type="submit" name="add_address" class="btn search-button">ذخیره آدرس</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>