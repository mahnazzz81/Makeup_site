<?php
session_start();
require_once 'db.php';

// بررسی لاگین بودن کاربر
if(!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user']['id'];

// دریافت اطلاعات کیف پول کاربر
try {
    $wallet_query = "SELECT balance, updated_at FROM wallets WHERE user_id = ?";
    $wallet_stmt = $db->prepare($wallet_query);
    $wallet_stmt->execute([$user_id]);
    $wallet = $wallet_stmt->fetch();
    
    if(!$wallet) {
        // اگر کیف پول وجود نداشت، یک کیف پول خالی ایجاد کنید
        $db->query("INSERT INTO wallets (user_id, balance) VALUES ($user_id, 0)");
        $wallet = ['balance' => 0, 'updated_at' => date('Y-m-d H:i:s')];
    }
    
} catch(PDOException $e) {
    die("خطا در دریافت اطلاعات کیف پول: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html dir="rtl" lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>کیف پول من</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
    .wallet-card {
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        border: none;
    }

    .wallet-balance {
        font-size: 2rem;
        font-weight: bold;
    }
    </style>
</head>

<body>
    <!-- هدر و منو مانند صفحات دیگر -->

    <div class="container py-5">
        <div class="row">
            <!-- سایدبار پروفایل -->
            <div class="col-md-3">
                <div class="card shadow-sm sticky-top" style="top: 20px;">
                    <div class="card-body p-0">
                        <div class="list-group list-group-flush rounded">
                            <a href="profile.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-person-fill me-2"></i> پروفایل
                            </a>


                            <a href="orders.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-cart-check me-2"></i> سفارشات
                            </a>
                            <a href="wallet.php" class="list-group-item list-group-item-action active py-3"
                                style="background-color: #9c1e48; border: none !important;">
                                <i class="bi bi-wallet-fill me-2"></i> کیف پول
                            </a>
                            <a href="addresses.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-geo-alt-fill me-2"></i>آدرس های من
                            </a>
                            <a href="support.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-headset me-2"></i> پشتیبانی
                            </a>
                            <a href="index.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-house me-2"></i>صفحه اصلی
                            </a>
                            <a href="logout.php" class="list-group-item list-group-item-action text-danger py-3">
                                <i class="bi bi-box-arrow-left me-2"></i> خروج
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- محتوای اصلی -->
            <div class="col-md-9">
                <div class="card wallet-card mb-4 mt-1">
                    <div class="card-header search-button text-white">
                        <h5 class="mb-0"><i class="bi bi-wallet2 me-2"></i> کیف پول من
                        </h5>
                    </div>
                    <div class="card-body text-center py-5">
                        <div class="wallet-balance text-success mb-3">
                            <?= number_format($wallet['balance']) ?> تومان
                        </div>
                        <p class="text-muted">آخرین به‌روزرسانی:
                            <?= date('Y/m/d H:i', strtotime($wallet['updated_at'])) ?></p>
                    </div>
                </div>

                <div class="card wallet-card">
                    <div class="card-header search-button text-white">
                        <h5 class="mb-0"><i class="bi bi-clock-history me-2"></i> تاریخچه تراکنش‌ها</h5>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info">
                            در حال حاضر هیچ تراکنشی ثبت نشده است.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>