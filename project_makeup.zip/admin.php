<div class="container mt-4">
    <h2 class="mb-4">مدیریت محصولات</h2>
    <a href="add_product.php" class="btn btn-success mb-3">+ محصول جدید</a>

    <table class="table table-bordered table-hover">
        <thead class="table-dark">
            <tr>
                <th>تصویر</th>
                <th>نام محصول</th>
                <th>قیمت</th>
                <th>وضعیت‌ها</th>
                <th>عملیات</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $products = $db->query("SELECT * FROM products");
            while($product = $products->fetch()):
            ?>
            <tr>
                <td><img src="images/products/<?= $product['image'] ?>" width="60"></td>
                <td><?= $product['name'] ?></td>
                <td><?= number_format($product['price']) ?> تومان</td>
                <td>
                    <form method="post" action="update_status.php" class="d-inline">
                        <input type="hidden" name="id" value="<?= $product['id'] ?>">

                        <div class="form-check form-switch d-inline-block me-3">
                            <input class="form-check-input" type="checkbox" name="new"
                                <?= $product['is_new_arrival'] ? 'checked' : '' ?>>
                            <label class="form-check-label">جدید</label>
                        </div>

                        <div class="form-check form-switch d-inline-block">
                            <input class="form-check-input" type="checkbox" name="best"
                                <?= $product['is_best_seller'] ? 'checked' : '' ?>>
                            <label class="form-check-label">پرفروش</label>
                        </div>

                        <button type="submit" class="btn btn-sm btn-info ms-2">ذخیره</button>
                    </form>
                </td>
                <td>
                    <a href="edit_product.php?id=<?= $product['id'] ?>" class="btn btn-sm btn-warning">ویرایش</a>
                    <a href="delete_product.php?id=<?= $product['id'] ?>" class="btn btn-sm btn-danger"
                        onclick="return confirm('آیا مطمئن هستید؟')">حذف</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>