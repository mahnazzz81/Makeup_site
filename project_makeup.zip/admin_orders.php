<?php
session_start();
require_once 'db.php';

// بررسی آیا کاربر مدیر است یا نه
if(!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header('Location: login.php');
    exit;
}

// عملیات تغییر وضعیت سفارش
if(isset($_GET['change_status'])) {
    $order_id = $_GET['order_id'];
    $new_status = $_GET['new_status'];
    
    try {
        $stmt = $db->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $order_id]);
        $_SESSION['success'] = "وضعیت سفارش با موفقیت به روز رسانی شد";
    } catch(PDOException $e) {
        $_SESSION['error'] = "خطا در به روز رسانی وضعیت سفارش: " . $e->getMessage();
    }
    header('Location: admin_orders.php');
    exit;
}

// دریافت تمام سفارشات به همراه اطلاعات کاربر
$orders = $db->query("
    SELECT o.*, u.name as user_name, u.phone as user_phone
    FROM orders o
    JOIN users u ON o.user_id = u.id
    ORDER BY o.created_at DESC
")->fetchAll();
?>

<!DOCTYPE html>
<html dir="rtl" lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت سفارشات</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
    .order-card {
        transition: all 0.3s;
        border-left: 4px solid #9c1e48;
    }

    .order-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .status-badge {
        font-size: 0.85rem;
    }

    .status-pending {
        background-color: #ffc107;
        color: #000;
    }

    .status-processing {
        background-color: #0dcaf0;
        color: #000;
    }

    .status-completed {
        background-color: #198754;
        color: #fff;
    }

    .status-cancelled {
        background-color: #dc3545;
        color: #fff;
    }
    </style>
</head>

<body>
    <div class="container py-4">
        <div class="row g-4">
            <!-- سایدبار -->
            <div class="col-md-3">
                <div class="card shadow-sm sticky-top" style="top: 20px;">
                    <div class="card-body p-0">
                        <!-- منوی اصلی -->
                        <div class="list-group list-group-flush rounded">
                            <a href="dashboard.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-speedometer2 me-2"></i> داشبورد
                            </a>
                            <a href="admin_products.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-box-seam me-2"></i> محصولات
                            </a>
                            <a href="admin_categories.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-tags me-2"></i> دسته‌بندی‌ها
                            </a>
                            <a href="admin_subcategories.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-tag me-2"></i> زیردسته‌بندی‌ها
                            </a>
                            <a href="admin_orders.php" class="list-group-item list-group-item-action active py-3"
                                style="background-color: #9c1e48 !important; border:none !important;">
                                <i class="bi bi-cart-check me-2"></i> سفارشات
                            </a>
                            <a href="admin_users.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-people me-2"></i> کاربران
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- محتوای اصلی -->
            <div class="col-md-9">
                <!-- پیام‌های سیستم -->
                <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-danger"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
                <?php endif; ?>

                <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
                <?php endif; ?>

                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="mb-0">مدیریت سفارشات</h4>
                </div>

                <!-- لیست سفارشات -->
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>شماره سفارش</th>
                                        <th>مشتری</th>
                                        <th>تلفن</th>
                                        <th>مبلغ کل</th>
                                        <th>تاریخ سفارش</th>
                                        <th>وضعیت</th>
                                        <th>عملیات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($orders as $order): ?>
                                    <?php
                                        // تعیین کلاس وضعیت سفارش
                                        $status_class = [
                                            'pending' => 'status-pending',
                                            'processing' => 'status-processing',
                                            'completed' => 'status-completed',
                                            'cancelled' => 'status-cancelled'
                                        ][$order['status']] ?? '';
                                        
                                        // ترجمه وضعیت سفارش
                                        $status_text = [
                                            'pending' => 'در انتظار',
                                            'processing' => 'در حال پردازش',
                                            'completed' => 'تکمیل شده',
                                            'cancelled' => 'لغو شده'
                                        ][$order['status']] ?? $order['status'];
                                        ?>
                                    <tr>
                                        <td>#<?= $order['id'] ?></td>
                                        <td><?= htmlspecialchars($order['user_name']) ?></td>
                                        <td><?= htmlspecialchars($order['user_phone']) ?></td>
                                        <td><?= number_format($order['total_price']) ?> تومان</td>
                                        <td><?= date('Y/m/d H:i', strtotime($order['created_at'])) ?></td>
                                        <td>
                                            <span class="badge rounded-pill status-badge <?= $status_class ?>">
                                                <?= $status_text ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-sm btn-outline-secondary dropdown-toggle"
                                                    type="button" data-bs-toggle="dropdown">
                                                    تغییر وضعیت
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li><a class="dropdown-item"
                                                            href="admin_orders.php?change_status=1&order_id=<?= $order['id'] ?>&new_status=pending">در
                                                            انتظار</a></li>
                                                    <li><a class="dropdown-item"
                                                            href="admin_orders.php?change_status=1&order_id=<?= $order['id'] ?>&new_status=processing">در
                                                            حال پردازش</a></li>
                                                    <li><a class="dropdown-item"
                                                            href="admin_orders.php?change_status=1&order_id=<?= $order['id'] ?>&new_status=completed">تکمیل
                                                            شده</a></li>
                                                    <li><a class="dropdown-item"
                                                            href="admin_orders.php?change_status=1&order_id=<?= $order['id'] ?>&new_status=cancelled">لغو
                                                            شده</a></li>
                                                </ul>
                                            </div>
                                            <a href="order_details.php?id=<?= $order['id'] ?>"
                                                class="btn btn-sm btn-outline-primary ms-2">
                                                جزئیات
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>