<?php
// بررسی ادمین بودن کاربر
session_start();
if($_SESSION['user']['role'] != 'admin') {
    header('Location: login.php');
    exit;
}

require_once 'config/database.php';

$id = $_POST['id'];
$is_new = isset($_POST['new']) ? 1 : 0;
$is_best = isset($_POST['best']) ? 1 : 0;

$stmt = $db->prepare("UPDATE products SET 
    is_new_arrival = ?, 
    is_best_seller = ? 
    WHERE id = ?");
$stmt->execute([$is_new, $is_best, $id]);

header('Location: admin.php'); // بازگشت به صفحه مدیریت