<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>درباره بیوتی پینک - فروشگاه تخصصی محصولات آرایشی و بهداشتی</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
    body {
        background-color: #fff5f7;
        color: #333;
    }

    .about-header {
        background: linear-gradient(to left, #ff85a2, #ffaccb);
        color: white;
        padding: 60px 0;
        margin-bottom: 40px;
    }

    .about-section {
        background-color: white;
        border-radius: 15px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        padding: 30px;
        margin-bottom: 30px;
    }

    .mission-vision {
        border-right: 4px solid #ff85a2;
        padding-right: 20px;
    }

    .brands-section img {
        height: 60px;
        margin: 10px;
        filter: grayscale(30%);
        transition: all 0.3s;
    }

    .brands-section img:hover {
        filter: grayscale(0%);
        transform: scale(1.1);
    }

    .team-member {
        text-align: center;
        margin-bottom: 30px;
    }

    .team-member img {
        width: 150px;
        height: 150px;
        object-fit: cover;
        border-radius: 50%;
        border: 5px solid #ffc0cb;
        margin-bottom: 15px;
    }
    </style>
</head>

<body>
    <!-- Header Section -->
    <header class="about-header text-center">
        <div class="container">
            <h1 class="display-4 fw-bold">درباره بیوتی پینک</h1>
            <p class="lead">تخصص، اعتبار و تجربه‌ای بی‌نظیر در صنعت آرایشی و بهداشتی</p>
        </div>
    </header>

    <!-- Main Content -->
    <div class="container">
        <!-- Introduction Section -->
        <section class="about-section">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h2 class="fw-bold mb-4">بیوتی پینک؛ پیشرو در صنعت زیبایی</h2>
                    <p class="lead">بیوتی پینک به عنوان اولین و جامع‌ترین فروشگاه اینترنتی تخصصی آرایشی و بهداشتی و
                        نماینده رسمی بیش از ۲۵۰ برند معتبر جهانی و داخلی، مجموعه‌ای کامل از بهترین و باکیفیت‌ترین
                        محصولات آرایشی، بهداشتی و مراقبت پوست را با تضمین اصالت کالا به مشتریان عزیز ارائه می‌دهد.</p>
                    <p>ما با بیش از یک دهه تجربه درخشان در حوزه زیبایی و سلامت، با تکیه بر تیمی متخصص و مشاوران حرفه‌ای،
                        توانسته‌ایم به بزرگترین و معتبرترین فروشگاه آنلاین محصولات آرایشی و بهداشتی در ایران تبدیل شویم.
                    </p>
                </div>
                <div class="col-md-6 pe-5">
                    <img src="images/logo.jpg" alt="فروشگاه بیوتی پینک" class="img-fluid rounded w-50 h-50">
                </div>
            </div>
        </section>

        <!-- Mission & Vision -->
        <section class="about-section">
            <div class="row">
                <div class="col-md-6 mission-vision">
                    <h3 class="fw-bold text-pink mb-4">رسالت ما</h3>
                    <p>ما در بیوتی پینک باور داریم که هر زنی سزاوار دسترسی به بهترین محصولات آرایشی و بهداشتی با قیمت
                        مناسب است. رسالت ما ایجاد تجربه‌ای متفاوت و خوشایند از خرید آنلاین است که در آن اصالت کالا، تنوع
                        محصول، قیمت مناسب و خدمات پس از فروش حرفه‌ای در اولویت قرار دارد.</p>
                </div>
                <div class="col-md-6">
                    <h3 class="fw-bold text-pink mb-4">چشم‌انداز ما</h3>
                    <p>تبدیل شدن به برترین پلتفرم تخصصی زیبایی و سلامت در منطقه با ارائه جامع‌ترین سرویس‌های مرتبط با
                        صنعت آرایشی و بهداشتی از جمله مشاوره تخصصی، آموزش‌های کاربردی و سیستم هوشمند پیشنهاد محصولات
                        متناسب با نوع پوست و نیاز هر فرد.</p>
                </div>
            </div>
        </section>

        <!-- Why Choose Us -->
        <section class="about-section">
            <h2 class="fw-bold text-center mb-5">چرا بیوتی پینک را انتخاب می‌کنند؟</h2>
            <div class="row">
                <div class="col-md-4 text-center mb-4">
                    <div class="bg-light-pink p-4 rounded h-100">
                        <i class="bi bi-patch-check-fill display-4 text-pink mb-3"></i>
                        <h4>تضمین اصالت کالا</h4>
                        <p>تمامی محصولات با گارانتی اصالت و سلامت فیزیکی ارائه می‌شوند</p>
                    </div>
                </div>
                <div class="col-md-4 text-center mb-4">
                    <div class="bg-light-pink p-4 rounded h-100">
                        <i class="bi bi-truck display-4 text-pink mb-3"></i>
                        <h4>تحویل سریع و مطمئن</h4>
                        <p>ارسال به تمام نقاط ایران در کمترین زمان ممکن</p>
                    </div>
                </div>
                <div class="col-md-4 text-center mb-4">
                    <div class="bg-light-pink p-4 rounded h-100">
                        <i class="bi bi-headset display-4 text-pink mb-3"></i>
                        <h4>پشتیبانی 24 ساعته</h4>
                        <p>مشاوره رایگان و پاسخگویی به سوالات شما در هر زمان</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Brands Section -->
        <section class="about-section">
            <h2 class="fw-bold text-center mb-5">برخی از برندهای همکار ما</h2>
            <div class="brands-section text-center">
                <img src="images/برند کالیستا.png" alt="برند کالیستا">
                <img src="images/برند ژیناژن.png" alt="برند ژیناژن">
                <img src="images/برند آردن .png" alt=" برند آردن">

            </div>
        </section>

        <!-- Team Section -->
        <section class="about-section">
            <h2 class="fw-bold text-center mb-5">تیم متخصص بیوتی پینک</h2>
            <div class="row">
                <div class="col-md-3 team-member">
                    <h4>نازنین محمدی</h4>
                    <p class="text-muted">مدیر عامل و موسس</p>
                </div>
                <div class="col-md-3 team-member">
                    <h4>پریسا احمدی</h4>
                    <p class="text-muted">مشاور ارشد زیبایی</p>
                </div>
                <div class="col-md-3 team-member">
                    <h4>زهرا حسینی</h4>
                    <p class="text-muted">مدیر پشتیبانی مشتریان</p>
                </div>
                <div class="col-md-3 team-member">
                    <h4>لیلا کریمی</h4>
                    <p class="text-muted">مدیر فنی و توسعه</p>
                </div>
            </div>
        </section>

        <!-- Achievements -->
        <section class="about-section text-center">
            <h2 class="fw-bold mb-5">دستاوردهای ما</h2>
            <div class="row">
                <div class="col-md-3 mb-4">
                    <div class="display-4 fw-bold text-pink">۱۰+</div>
                    <p>سال تجربه موفق</p>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="display-4 fw-bold text-pink">۲۵۰+</div>
                    <p>برند معتبر همکار</p>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="display-4 fw-bold text-pink">۵۰۰K+</div>
                    <p>مشتری راضی</p>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="display-4 fw-bold text-pink">۱۰۰%</div>
                    <p>تضمین اصالت کالا</p>
                </div>
            </div>
        </section>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container text-center">
            <p>تمامی حقوق مادی و معنوی این سایت متعلق به فروشگاه بیوتی پینک می‌باشد.</p>
            <div class="mt-3">
                <a href="#" class="text-white mx-2"><i class="bi bi-instagram"></i></a>
                <a href="#" class="text-white mx-2"><i class="bi bi-telegram"></i></a>
                <a href="#" class="text-white mx-2"><i class="bi bi-whatsapp"></i></a>
                <a href="#" class="text-white mx-2"><i class="bi bi-linkedin"></i></a>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>