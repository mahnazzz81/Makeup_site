<!DOCTYPE html>
<html dir="rtl" lang="fa">

<head>
    <?php
session_start();
require_once 'db.php';

// ابتدا بررسی کنید آیا کاربر لاگین کرده یا نه
if(isset($_SESSION['user']) && isset($_SESSION['user']['id'])) {
    $user_id = $_SESSION['user']['id'];
    $user = $db->query("SELECT * FROM users WHERE id = $user_id")->fetch();
    $is_admin = ($user['role'] === 'admin');
    $is_user = ($user['role'] === 'user' || $user['role'] === '');
} else {
    $is_admin = false;
    $is_user = false;
    $user = null; // یا مقادیر پیش‌فرض دیگر
}
?>


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <meta name="description" content="فروشگاه اینترنتی محصولات آرایشی و بهداشتی با بهترین قیمت‌ها">
    <meta name="keywords" content="آرایشی, بهداشتی, لوازم آرایش, عطر, ادکلن">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <title>فروشگاه آرایشی | خرید آنلاین محصولات آرایشی و بهداشتی</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <!-- فونت شبنم -->
    <link href="https://cdn.fontcdn.ir/Font/Persian/Shabnam/Shabnam.css" rel="stylesheet">
    <!-- پیش‌بارگذاری فونت‌ها -->
    <link rel="preload" href="font-url.woff2" as="font" type="font/woff2" crossorigin>
</head>

<body>
    <header>


        <!-- ناوبری اصلی با Offcanvas -->
        <nav class="navbar navbar-expand-lg main-header sticky-top">
            <div class="container" style="flex-wrap: nowrap;">
                <div class="d-flex align-items-center">
                    <!-- آیکون همبرگر -->
                    <button class="navbar-toggler " type="button" data-bs-toggle="offcanvas"
                        data-bs-target="#offcanvasNavbar">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <!-- لوگو -->
                    <a class="navbar-brand mx-auto" href="index.php">
                        <img src="images/logo.jpg" alt="لوگو" width="129">
                    </a>

                    <!-- بخش جستجو (دسکتاپ) -->
                    <form class="search-form-desktop d-none d-lg-flex" action="search.php" method="GET">
                        <input type="text" name="query" placeholder="جستجوی محصولات..."
                            class="search-input form-control">
                        <button type="submit" class="search-button btn me-2" style="border:none;">
                            جستجو
                        </button>
                    </form>
                </div>
                <!-- آیکون‌های سمت چپ -->
                <!-- آیکون‌های سمت چپ -->
                <div class="icons-left-container">
                    <?php if($is_user):?>
                    <a href="cart.php" class="btn">
                        <i class="bi bi-cart3"></i>
                    </a>
                    <?php endif; ?>


                    <?php if(isset($_SESSION['user'])): ?>
                    <!-- نمایش وقتی کاربر لاگین کرده -->
                    <div class="dropdown">
                        <a class="btn dropdown-toggle d-flex align-items-center py-1 px-2 dropdown-toggle-no-caret"
                            href="profile.php" role="button" id="userDropdown" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <i class="bi bi-person-fill-down"></i>

                        </a>
                        <ul class="dropdown-menu dropdown-menu-end border-0 shadow-xl text-end"
                            style="max-width: 120px;" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item py-2 px-3" href="profile.php">پروفایل</a></li>
                            <?php if($is_user):?>
                            <li><a class="dropdown-item py-2 px-3" href="orders.php">سفارش‌ها</a></li>
                            <li><a class="dropdown-item py-2 px-3" href="wallet.php">کیف پول</a></li>
                            <li><a class="dropdown-item py-2 px-3" href="addresses.php">آدرس های من</a></li>
                            <li><a class="dropdown-item py-2 px-3" href="suppotr.php">پشتیبانی</a></li>
                            <li>
                                <hr class="dropdown-divider my-1">
                            </li>
                            <?php endif; ?>


                            <?php if($is_admin): ?> <li><a class="dropdown-item py-2 px-3 text-info"
                                    href="dashboard.php">داشبورد مدیریت</a>
                            </li>
                            <?php endif; ?>
                            <li><a class="dropdown-item py-2 px-3 text-danger" href="logout.php">خروج</a>
                            </li>
                        </ul>
                    </div>
                    <?php else: ?>
                    <!-- نمایش وقتی کاربر لاگین نکرده -->
                    <a href="login.php" class="btn d-flex align-items-center submit-btn">
                        <span class="ms-1">ورود</span>
                    </a>
                    <?php endif; ?>

                    <a href="search.php" class="btn d-lg-none">
                        <i class="bi bi-search"></i>
                    </a>
                </div>
            </div>
        </nav>
        <!-- منوی اصلی دسکتاپ -->
        <div class="main-navigation d-none d-lg-block">
            <div class="container">
                <ul class="nav justify-content-center">
                    <!-- آیتم معمولی -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="index.php" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            برندها
                        </a>
                        <ul class="dropdown-menu bg-white">
                            <div class="layout-container">
                                <div class="container">
                                    <div class="row text-end">
                                        <div class="col-md-4 flex-grow-1" style="max-height: 300px; overflow-y: auto;">
                                            <h6 class="dropdown-header text-info"> همه برند ها</h6>
                                            <?php
                        $brands = $db->query("SELECT id, name FROM brands ORDER BY name")->fetchAll();
                        foreach ($brands as $brand_item):
                        ?>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="brand.php?id=<?= $brand_item['id'] ?>">
                                                <?= htmlspecialchars($brand_item['name']) ?>
                                            </a>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            آرایشی
                        </a>
                        <ul class="dropdown-menu bg-white">
                            <div class="layout-container">
                                <div class="container">
                                    <div class="row text-end">
                                        <div class="col-md-4">
                                            <h6 class="dropdown-header text-danger">آرایش صورت</h6>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=کرم پودر">کرم پودر</a>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=پنکک">پنکک</a>
                                            <a class="dropdown-item py-2" href="products.php?subcategory=رژ گونه">رژ
                                                گونه</a>
                                        </div>
                                        <div class="col-md-4">
                                            <h6 class="dropdown-header text-danger">آرایش چشم</h6>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=ریمل">ریمل</a>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=مداد و خط چشم">مداد و خط چشم
                                            </a>
                                            <a class="dropdown-item py-2" href="products.php?subcategory=سایه چشم">سایه
                                                چشم</a>
                                        </div>
                                        <div class=" col-md-4">
                                            <h6 class="dropdown-header text-danger">آرایش لب</h6>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=رژ لب">رژ لب</a>
                                            <a class=" dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=مداد و خط لب">مداد و خط لب</a>
                                            <a class=" dropdown-item py-2" href="products.php?subcategory=تینت لب">تینت
                                                لب</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            مراقبت پوست
                        </a>
                        <ul class="dropdown-menu bg-white">
                            <div class="layout-container">
                                <div class="container">
                                    <div class="row text-end">
                                        <div class="col-md-4">
                                            <h6 class="dropdown-header text-danger">مراقبت صورت</h6>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=ضد آفتاب">ضد آفتاب</a>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=آبرسان و مرطوب کننده">آبرسان و مرطوب
                                                کننده</a>
                                            <a class="dropdown-item py-2" href="products.php?subcategory=ماسک صورت">ماسک
                                                صورت</a>
                                        </div>
                                        <div class="col-md-4">
                                            <h6 class="dropdown-header text-danger">پاک کننده و شوینده</h6>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=شوینده صورت">شوینده صورت</a>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=آرایش پاک کن ومیسلار واتر">آرایش پاک کن و
                                                میسلار واتر</a>
                                            <a class="dropdown-item py-2" href="products.php?subcategory=تونر">تونر</a>
                                        </div>
                                        <div class="col-md-4">
                                            <h6 class="dropdown-header text-danger">مراقبت بدن</h6>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=لوسیون بدن">لوسیون بدن</a>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=روشن کننده بدن">روشن کننده بدن</a>
                                            <a class="dropdown-item py-2"
                                                href="products.php?subcategory=اسکراب بدن">اسکراب
                                                بدن</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            مراقبت مو
                        </a>
                        <ul class="dropdown-menu bg-white">
                            <div class="layout-container">
                                <div class="container">
                                    <div class="row text-end">
                                        <div class="col-md-4">
                                            <h6 class="dropdown-header text-danger">شامپو</h6>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory= شامپو موی معمولی ">شامپو موی معمولی</a>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory= شامپو موی چرب">شامپو موی چرب</a>
                                            <a class="dropdown-item py-2"
                                                href="products.php?subcategory=شامپو ضد شوره">شامپو ضد
                                                شوره</a>
                                        </div>
                                        <div class="col-md-4">
                                            <h6 class="dropdown-header text-danger">مراقبت از مو</h6>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=ماسک مو">ماسک مو</a>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=روغن مو">روغن مو</a>
                                            <a class="dropdown-item py-2"
                                                href="products.php?subcategory=نرم کننده مو">نرم کننده
                                                مو</a>
                                        </div>
                                        <div class="col-md-4">
                                            <h6 class="dropdown-header text-danger">زیبایی مو</h6>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=اسپری مو">اسپری مو</a>
                                            <a class="dropdown-item py-2" href="products.php?subcategory=ژل مو">ژل
                                                مو</a>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            عطر و اسپری
                        </a>
                        <ul class="dropdown-menu bg-white">
                            <div class="layout-container">
                                <div class="container">
                                    <div class="row text-end">
                                        <div class="col-md-4">
                                            <h6 class="dropdown-header text-danger">عطر و ادکلن</h6>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=عطر زنانه">عطر زنانه</a>
                                            <a class="dropdown-item py-2" href="products.php?subcategory=عطر مردانه">عطر
                                                مردانه</a>
                                        </div>
                                        <div class="col-md-4">
                                            <h6 class="dropdown-header text-danger">اسپری</h6>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=اسپری زنانه">اسپری زنانه</a>
                                            <a class="dropdown-item py-2"
                                                href="products.php?subcategory=اسپری مردانه">اسپری مردانه</a>
                                        </div>
                                        <div class="col-md-4">
                                            <h6 class="dropdown-header text-danger">بادی اسپلش</h6>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=بادی اسپلش مردانه">بادی اسپلش مردانه</a>
                                            <a class="dropdown-item py-2"
                                                href="products.php?subcategory=بادی اسپلش زنانه">بادی
                                                اسپلش
                                                زنانه</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </ul>
                    </li>

                    <!-- آیتم دراپ‌داون مطابق تصویر شما -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            لوازم برقی
                        </a>
                        <ul class="dropdown-menu bg-white">
                            <div class="layout-container">
                                <div class="container">
                                    <div class="row text-end">
                                        <div class="col-md-4">
                                            <h6 class="dropdown-header text-danger">ابزار برقی مو</h6>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=سشوار">سشوار</a>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=اتو مو صاف کننده">اتو مو صاف کننده</a>
                                            <a class=" dropdown-item py-2"
                                                href="products.php?subcategory=برس حرارتی">برس
                                                حرارتی</a>
                                        </div>
                                        <div class="col-md-4">
                                            <h6 class="dropdown-header text-danger">ابزار اصلاح</h6>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=ماشین اصلاح صورت">ماشین اصلاح صورت</a>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=ماشین اصلاح بدن و سر">ماشین اصلاح بدن و
                                                سر</a>
                                            <a class="dropdown-item py-2"
                                                href="products.php?subcategory=اپیلیدی و بند انداز برقی">اپیلیدی
                                                و
                                                بند
                                                انداز برقی</a>
                                        </div>
                                        <div class="col-md-4">
                                            <h6 class="dropdown-header text-danger">ابزار مراقبت پوست</h6>
                                            <a class="dropdown-item border-bottom py-2"
                                                href="products.php?subcategory=فیس براش">فیس براش</a>
                                            <a class="dropdown-item py-2"
                                                href="products.php?subcategory=دستگاه لیفت صورت">دستگاه لیفت
                                                صورت</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </ul>
                    </li>

                    <!-- بقیه آیتم‌های منو -->
                </ul>
            </div>

        </div>
        <!-- منوی Offcanvas -->

        <div class="offcanvas offcanvas-end offcanvas-custom" tabindex="-1" id="offcanvasNavbar">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title">منوی فروشگاه</h5>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
            </div>
            <div class="offcanvas-body">
                <!-- منوی موبایل -->
                <ul class="navbar-nav mobile-menu">
                    <!-- برندها -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown">
                            برندها
                        </a>
                        <ul class="dropdown-menu w-75">
                            <?php foreach ($brands as $brand_item): ?>
                            <li><a class="dropdown-item" href="brand.php?id=<?= $brand_item['id'] ?>">
                                    <?= htmlspecialchars($brand_item['name']) ?>
                                </a></li>
                            <?php endforeach; ?>
                        </ul>
                    </li>

                    <!-- آرایشی -->
                    <li class="nav-item dropdown w-75">
                        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown">
                            آرایشی
                        </a>
                        <ul class="dropdown-menu w-75">
                            <li class="dropdown-submenu">
                                <a class="dropdown-item dropdown-toggle" href="#">آرایش صورت</a>
                                <ul class="dropdown-menu w-75">
                                    <li><a class="dropdown-item" href="products.php?subcategory=کرم پودر">کرم پودر</a>
                                    </li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=پنکک">پنکک</a></li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=رژ گونه">رژ گونه</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="dropdown-submenu">
                                <a class="dropdown-item dropdown-toggle" href="#">آرایش چشم</a>
                                <ul class="dropdown-menu w-75">
                                    <li><a class="dropdown-item" href="products.php?subcategory=ریمل">ریمل</a></li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=مداد و خط چشم">مداد و خط
                                            چشم</a></li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=سایه چشم">سایه چشم</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="dropdown-submenu">
                                <a class="dropdown-item dropdown-toggle" href="#">آرایش لب</a>
                                <ul class="dropdown-menu w-75">
                                    <li><a class="dropdown-item" href="products.php?subcategory=رژ لب">رژ لب</a></li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=مداد و خط لب">مداد و خط
                                            لب</a></li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=تینت لب">تینت لب</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown w-75">
                        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown">
                            مراقبت پوست
                        </a>
                        <ul class="dropdown-menu w-75">
                            <li class="dropdown-submenu">
                                <a class="dropdown-item dropdown-toggle" href="#">مراقبت صورت</a>
                                <ul class="dropdown-menu w-75">
                                    <li><a class="dropdown-item" href="products.php?subcategory=ضد آفتاب ">ضد آفتاب </a>
                                    </li>
                                    <li><a class="dropdown-item"
                                            href="products.php?subcategory=آبرسان و مرطوب کننده">آبرسان و
                                            مرطوب
                                            کننده</a></li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=ماسک صورت ">ماسک
                                            صورت</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="dropdown-submenu">
                                <a class="dropdown-item dropdown-toggle" href="#">پاک کننده و شوینده </a>
                                <ul class="dropdown-menu w-75">
                                    <li><a class="dropdown-item" href="products.php?subcategory=ریمل">شوینده صورت</a>
                                    </li>
                                    <li><a class="dropdown-item"
                                            href="products.php?subcategory= آرایش پاک کن و میسلار واتر">آرایش پاک
                                            کن و میسلار واتر
                                        </a></li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=تونر "> تونر</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="dropdown-submenu">
                                <a class="dropdown-item dropdown-toggle" href="#">مراقبت بدن </a>
                                <ul class="dropdown-menu w-75">
                                    <li><a class="dropdown-item" href="products.php?subcategory=لوسیون بدن"> لوسیون
                                            بدن </a>
                                    </li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=روشن کننده بدن"> روشن
                                            کننده بدن
                                        </a></li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=اسکراب بدن ">اسکراب بدن
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown w-75">
                        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown">
                            مراقبت مو
                        </a>
                        <ul class="dropdown-menu w-75">
                            <li class="dropdown-submenu">
                                <a class="dropdown-item dropdown-toggle" href="#">شامپو</a>
                                <ul class="dropdown-menu w-75">
                                    <li><a class="dropdown-item" href="products.php?subcategory=شامپو موی معمولی">شامپو
                                            موی معمولی</a></li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=شامپو موی چرب">شامپو موی
                                            چرب</a></li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=شامپو ضد شوره">شامپو ضد
                                            شوره</a></li>
                                </ul>
                            </li>
                            <li class="dropdown-submenu">
                                <a class="dropdown-item dropdown-toggle" href="#">مراقبت از مو</a>
                                <ul class="dropdown-menu w-75">
                                    <li><a class="dropdown-item" href="products.php?subcategory=ماسک مو">ماسک مو</a>
                                    </li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=روغن مو">روغن مو</a>
                                    </li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=نرم کننده مو">نرم کننده
                                            مو</a></li>
                                </ul>
                            </li>
                            <li class="dropdown-submenu">
                                <a class="dropdown-item dropdown-toggle" href="#">زیبایی مو</a>
                                <ul class="dropdown-menu w-75">
                                    <li><a class="dropdown-item" href="products.php?subcategory=اسپری مو">اسپری مو</a>
                                    </li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=ژل مو">ژل مو</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown w-75">
                        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown">
                            عطر و اسپری
                        </a>
                        <ul class="dropdown-menu w-75">
                            <li class="dropdown-submenu">
                                <a class="dropdown-item dropdown-toggle" href="#">عطر و ادکلن</a>
                                <ul class="dropdown-menu w-75">
                                    <li><a class="dropdown-item" href="products.php?subcategory=عطر زنانه">عطر زنانه</a>
                                    </li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=عطر مردانه">عطر
                                            مردانه</a></li>
                                </ul>
                            </li>
                            <li class="dropdown-submenu">
                                <a class="dropdown-item dropdown-toggle" href="#">اسپری</a>
                                <ul class="dropdown-menu w-75">
                                    <li><a class="dropdown-item" href="products.php?subcategory=اسپری زنانه">اسپری
                                            زنانه</a></li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=اسپری مردانه">اسپری
                                            مردانه</a></li>
                                </ul>
                            </li>
                            <li class="dropdown-submenu">
                                <a class="dropdown-item dropdown-toggle" href="#">بادی اسپلش</a>
                                <ul class="dropdown-menu w-75">
                                    <li><a class="dropdown-item" href="products.php?subcategory=بادی اسپلش مردانه">بادی
                                            اسپلش مردانه</a></li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=بادی اسپلش زنانه">بادی
                                            اسپلش زنانه</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown w-75">
                        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown">
                            لوازم برقی
                        </a>
                        <ul class="dropdown-menu w-75">
                            <li class="dropdown-submenu">
                                <a class="dropdown-item dropdown-toggle" href="#">ابزار برقی مو</a>
                                <ul class="dropdown-menu w-75">
                                    <li><a class="dropdown-item" href="products.php?subcategory=سشوار">سشوار</a></li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=اتو مو صاف کننده">اتو مو
                                            صاف کننده</a></li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=برس حرارتی">برس
                                            حرارتی</a></li>
                                </ul>
                            </li>
                            <li class="dropdown-submenu">
                                <a class="dropdown-item dropdown-toggle" href="#">ابزار اصلاح</a>
                                <ul class="dropdown-menu w-75">
                                    <li><a class="dropdown-item" href="products.php?subcategory=ماشین اصلاح صورت">ماشین
                                            اصلاح صورت</a></li>
                                    <li><a class="dropdown-item"
                                            href="products.php?subcategory=ماشین اصلاح بدن و سر">ماشین اصلاح بدن و
                                            سر</a></li>
                                    <li><a class="dropdown-item"
                                            href="products.php?subcategory=اپیلیدی و بند انداز برقی">اپیلیدی و بند انداز
                                            برقی</a></li>
                                </ul>
                            </li>
                            <li class="dropdown-submenu">
                                <a class="dropdown-item dropdown-toggle" href="#">ابزار مراقبت پوست</a>
                                <ul class="dropdown-menu w-75">
                                    <li><a class="dropdown-item" href="products.php?subcategory=فیس براش">فیس براش</a>
                                    </li>
                                    <li><a class="dropdown-item" href="products.php?subcategory=دستگاه لیفت صورت">دستگاه
                                            لیفت صورت</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>

                    <!-- بقیه آیتم‌های منو به همین شکل -->
                </ul>
            </div>

        </div>


        <style>
        /* استایل‌های سفارشی برای منوی موبایل */
        ul li {
            direction: rtl !important;
            text-align: right !important;
        }

        .mobile-menu {
            direction: rtl !important;
            text-align: right !important;
            unicode-bidi: bidi-override !important;
        }

        .mobile-menu .dropdown-menu {
            background-color: #f8f9fa;
            border: none;
            box-shadow: none;

        }

        .mobile-menu .dropdown-submenu {
            position: relative;

        }

        .mobile-menu .dropdown-submenu .dropdown-menu {
            top: 0;
            right: 100%;
            margin-top: -6px;
            margin-right: .125rem;
            border-right: 2px solid #dc3545;

        }

        .mobile-menu .dropdown-item {
            padding: 0.5rem 1.5rem;
            color: #333;
        }

        .mobile-menu .dropdown-item:hover {
            background-color: #e9ecef;
            color: #dc3545;
        }

        .mobile-menu .dropdown-toggle::after {
            float: left;
            margin-top: 0.5em;
        }

        /* خط قرمز عمودی برای زیرمنوها */
        .dropdown-submenu>.dropdown-menu {
            border-right: 2px solid #dc3545;
            margin-right: 10px;
        }
        </style>
        <script>
        // فعال‌سازی منوی آبشاری
        document.querySelectorAll('.dropdown-submenu .dropdown-toggle').forEach(function(element) {
            element.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                var submenu = this.nextElementSibling;
                submenu.style.display = submenu.style.display === 'block' ? 'none' : 'block';
            });
        });

        // بستن منوی آبشاری هنگام کلیک خارج از آن
        document.addEventListener('click', function() {
            document.querySelectorAll('.dropdown-submenu .dropdown-menu').forEach(function(element) {
                element.style.display = 'none';
            });
        });
        </script>

        <div id="carouselExampleZoom" class="carousel slide carousel-fade carouselExampleRide align-items-center"
            data-bs-ride="carousel" data-bs-interval="3000">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleZoom" data-bs-slide-to="0" class="active"
                    aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleZoom" data-bs-slide-to="1"
                    aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleZoom" data-bs-slide-to="2"
                    aria-label="Slide 3"></button>
                <button type="button" data-bs-target="#carouselExampleZoom" data-bs-slide-to="3"
                    aria-label="Slide 4"></button>
            </div>
            <div class="carousel-inner rounded-5 overflow-hidden shadow mt-3 mx-auto">
                <div class="carousel-item active">
                    <a href="brand.php?id=11">
                        <img src=" images/ginagen.jpeg" class="d-block w-100 img-zoom" alt="محصولات ژیناژن"
                            style="transform: scale(1.1);">
                    </a>
                </div>
                <div class="carousel-item">
                    <a href="products.php?category=لوازم برقی">
                        <img src="images/elctricy.jpeg" class="d-block w-100 img-zoom" alt="محصولات برقی"
                            style="transform: scale(1);"></a>
                </div>
                <div class="carousel-item">
                    <a href="brand.php?id=5">
                        <img src="images/arden.jpeg" class="d-block w-100 img-zoom" alt="محصولات  اردن"
                            style="transform: scale(1);"></a>
                </div>
                <div class="carousel-item">
                    <a href="products.php?subcategory=ضد آفتاب">
                        <img src="images/Sunscreen.jpeg" class="d-block w-100 img-zoom" alt="ضد افتاب"
                            style="transform: scale(1);"></a>
                </div>
            </div>
            <button class="carousel-control-prev d-none d-xl-block" type=" button" data-bs-target="#carouselExampleZoom"
                data-bs-slide="next">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
            <button class="carousel-control-next d-none d-xl-block" type="button" data-bs-target="#carouselExampleZoom"
                data-bs-slide="prev">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
        </div>
        <section class="categories-container mt-5 p-5">
            <div class="container">
                <div
                    class="row row-cols-2 row-cols-sm-2 row-cols-md-4 row-cols-lg-auto text-center justify-content-between">
                    <!-- دسته 1 -->
                    <div class="col">
                        <a href="products.php?subcategory=ضد آفتاب" class="text-decoration-none text-dark">
                            <div class="d-flex flex-column align-items-center c-list">
                                <div class="categori border rounded-circle">
                                    <img src="images/ZedeAftab.jpg"
                                        class="img-fluid rounded-circle w-100 h-100 object-fit-cover" alt="ضد آفتاب">
                                </div>
                                <span class="mt-2 fw-medium">ضد آفتاب</span>
                            </div>
                        </a>
                    </div>

                    <!-- دسته 2 -->
                    <div class="col">
                        <a href="products.php?subcategory=عطر زنانه" class="text-decoration-none text-dark">
                            <div class="d-flex flex-column align-items-center">
                                <div class="categori border rounded-circle">
                                    <img src="images/Atr.png"
                                        class="img-fluid rounded-circle w-100 h-100 object-fit-cover" alt="عطر و ادکلن">
                                </div>
                                <span class="mt-2 fw-medium">عطر زنانه</span>
                            </div>
                        </a>
                    </div>

                    <!-- دسته 3 -->
                    <div class="col">
                        <a href="products.php?subcategory=آبرسان و مرطوب کننده" class="text-decoration-none text-dark">
                            <div class="d-flex flex-column align-items-center">
                                <div class="categori border rounded-circle">
                                    <img src="images/Martobkonande.jpg"
                                        class="img-fluid rounded-circle w-100 h-100 object-fit-cover" alt="مرطوب کننده">
                                </div>
                                <span class="mt-2 fw-medium"> مرطوب کننده</span>
                            </div>
                        </a>
                    </div>

                    <!-- دسته 4 -->
                    <div class="col">
                        <a href="products.php?subcategory=سشوار" class="text-decoration-none text-dark">
                            <div class="d-flex flex-column align-items-center">
                                <div class="categori border rounded-circle">
                                    <img src="images/barghi.png"
                                        class="img-fluid rounded-circle w-100 h-100 object-fit-cover" alt="سشوار">
                                </div>
                                <span class=" mt-2 fw-medium">سشوار</span>
                            </div>
                        </a>
                    </div>

                    <!-- دسته 5 -->
                    <div class="col">
                        <a href="products.php?subcategory=شامپو موی چرب" class="text-decoration-none text-dark">
                            <div class="d-flex flex-column align-items-center">
                                <div class="categori border rounded-circle">
                                    <img src="images/Shampoo mo.jpg"
                                        class="img-fluid rounded-circle w-100 h-100 object-fit-cover" alt="شامپو مو">
                                </div>
                                <span class="mt-2 fw-medium">شامپو موی چرب</span>
                            </div>
                        </a>
                    </div>

                    <!-- دسته 6 -->
                    <div class="col">
                        <a href="products.php?subcategory=رژ لب" class="text-decoration-none text-dark">
                            <div class="d-flex flex-column align-items-center">
                                <div class="categori border rounded-circle">
                                    <img src="images/arayeshi.png"
                                        class="img-fluid rounded-circle w-100 h-100 object-fit-cover"
                                        alt="لوازم آرایشی">
                                </div>
                                <span class="mt-2 fw-medium">رژ لب</span>
                            </div>
                        </a>
                    </div>

                    <!-- دسته 7 -->
                    <div class="col">
                        <a href="products.php?subcategory=مداد و خط چشم" class="text-decoration-none text-dark">
                            <div class="d-flex flex-column align-items-center">
                                <div class="categori border rounded-circle">
                                    <img src="images/khat cheshm.jpg"
                                        class="img-fluid rounded-circle w-100 h-100 object-fit-cover" alt="خط چشم">
                                </div>
                                <span class="mt-2 fw-medium">مداد و خط چشم</span>
                            </div>
                        </a>
                    </div>

                    <!-- دسته 8 -->
                    <div class="col">
                        <a href="products.php?subcategory=ماسک مو" class="text-decoration-none text-dark">
                            <div class="d-flex flex-column align-items-center">
                                <div class="categori border rounded-circle">
                                    <img src="images/moraghbat mo.png"
                                        class="img-fluid rounded-circle w-100 h-100 object-fit-cover" alt="مراقبت مو">
                                </div>
                                <span class="mt-2 fw-medium">ماسک مو</span>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </section>

        <!-- جدیدترین محصولات -->
        <section class="container my-5 bg-light p-4 rounded">
            <h2 class="text-center mb-4 border-bottom pb-2">جدیدترین محصولات</h2>
            <div class="row flex-nowrap overflow-auto pb-3">
                <?php
        $new_products = $db->query("SELECT * FROM products WHERE is_new_arrival = 1 ORDER BY created_at DESC LIMIT 30");
        while($product = $new_products->fetch()):
        ?>
                <div class="col-xl-2 col-md-3 col-sm-10 mb-4">
                    <div class="card h-100 shadow-sm">
                        <img src="images/products/<?= $product['image'] ?>" class="card-img-top p-2"
                            alt="<?= htmlspecialchars($product['name']) ?>">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?= $product['name'] ?></h5>
                            <p class="text-success fw-bold"><?= number_format($product['price']) ?> تومان</p>
                            <a href="product-detail.php?id=<?= $product['id'] ?>"
                                class="btn search-button mt-auto">مشاهده</a>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </section>
        <div class="container">
            <div class="row g-4">
                <!-- محصول اول: لوازم آرایشی -->
                <div class="col-md-6">
                    <a href="products.php?category=مراقبت پوست" class="text-decoration-none">
                        <div class="card product-card h-75 border-0">
                            <img src="images/slideone.jpg" class="card-img" alt="لوازم مراقبت پوست">
                        </div>
                    </a>
                </div>

                <!-- محصول دوم: لوازم بهداشتی -->
                <div class="col-md-6">
                    <a href="products.php?category=آرایشی" class="text-decoration-none">
                        <div class="card product-card h-75 border-0">
                            <img src="images/slidetwo.jpg" class="card-img" alt="لوازم آرایشی">
                        </div>
                    </a>
                </div>
            </div>
        </div>



        <!-- پربازدید محصولات -->
        <section class="container my-5 bg-light p-4 rounded">
            <h2 class="text-center mb-4 border-bottom pb-2">پربازدیدترین محصولات</h2>
            <div class="row flex-nowrap overflow-auto">
                <?php
        // کوئری برای دریافت پربازدیدترین محصولات
        $most_viewed = $db->query("SELECT * FROM products ORDER BY views DESC LIMIT 30");
        while($product = $most_viewed->fetch()):
        ?>
                <div class="col-xl-2 col-md-3 mb-4">
                    <div class="card h-100 shadow-sm">
                        <img src="images/products/<?= htmlspecialchars($product['image']) ?>" class="card-img-top p-2"
                            alt="<?= htmlspecialchars($product['name']) ?>">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?= htmlspecialchars($product['name']) ?></h5>
                            <p class="text-success fw-bold"><?= number_format($product['price']) ?> تومان</p>
                            <div class="mt-auto">
                                <small class="text-muted"><?= $product['views'] ?> بازدید</small>
                                <a href="product-detail.php?id=<?= $product['id'] ?>"
                                    class="btn search-button d-block mt-2">
                                    مشاهده
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </section>

        <section class="brands-section py-3">
            <div class="container">

                <!-- لیست برندها -->
                <div class="row g-3">
                    <!-- برند ۱ -->
                    <div class="col-xl-3 col-md-5 text-center">
                        <a href="products.php?subcategory=اسپری زنانه"
                            class="d-block p-3 text-decoration-none text-dark bg-light rounded-4 h-100 transition-all">
                            <div class="overflow-hidden mb-3 rounded-top-4" style="height: 370px;">
                                <img src="images/عطر.jpg" alt="بلوم"
                                    class="img-fluid w-100 h-100 object-fit-cover transition-all">
                            </div>
                            <h5 class="mb-2 fs-6 fw-medium">اسپری زنانه
                            </h5>
                            <p class="text-danger fw-bold mb-0 fs-7">تخفیف 15%</p>
                        </a>
                    </div>

                    <!-- برند ۲ -->
                    <div class="col-xl-3 col-md-5 text-center">
                        <a href="products.php?subcategory=رژ گونه"
                            class="d-block p-3 text-decoration-none text-dark bg-light rounded-4 h-100 transition-all">
                            <div class="overflow-hidden mb-3 rounded-top-4" style="height: 370px;">
                                <img src="images/رژ.jpg" alt="ويكتوريا زر"
                                    class="img-fluid w-100 h-100 object-fit-cover transition-all">
                            </div>
                            <h5 class="mb-2 fs-6 fw-medium">رژ گونه</h5>
                            <p class="text-danger fw-bold mb-0 fs-7">تخفیف 20%</p>
                        </a>
                    </div>
                    <!-- برند 3 -->
                    <div class="col-xl-3 col-md-5 text-center">
                        <a href="products.php?subcategory=روغن مو"
                            class="d-block p-3 text-decoration-none text-dark bg-light rounded-4 h-100 transition-all">
                            <div class="overflow-hidden mb-3 rounded-top-4" style="height: 370px;">
                                <img src="images/روغن.jpg" alt="نوريتا"
                                    class="img-fluid w-100 h-100 object-fit-cover transition-all">
                            </div>
                            <h5 class="mb-2 fs-6 fw-medium">روغن مو</h5>
                            <p class="text-danger fw-bold mb-0 fs-7">تخفیف 5%</p>
                        </a>
                    </div>

                    <!-- برند 4 -->
                    <div class="col-xl-3 col-md-5 text-center">
                        <a href="products.php?subcategory=ریمل"
                            class="d-block p-3 text-decoration-none text-dark bg-light rounded-4 h-100 transition-all">
                            <div class="overflow-hidden mb-3 rounded-top-4" style="height: 370px;">
                                <img src="images/ریمل.jpg" alt="تگودر"
                                    class="img-fluid w-100 h-100 object-fit-cover transition-all">
                            </div>
                            <h5 class="mb-2 fs-6 fw-medium">ریمل
                            </h5>
                            <p class="text-danger fw-bold mb-0 fs-7">تخفیف 10%</p>
                        </a>
                    </div>


                </div>
            </div>
        </section>

        <style>
        /* حداقل CSS سفارشی */
        .transition-all {
            transition: all 0.2s cubic-bezier(0.25, 0.46, 0.45, 0.94);


        }

        .transition-all:hover {
            transform: translateY(-8px);


        }

        .transition-all:hover img {
            transform: scale(1.1);
        }

        .bg-light {
            background-color: #f8f9fa !important;
        }
        </style>
        <section class=" about-section container">
            <div class="container">
                <div class="row align-items-center flex-lg-row flex-column-reverse">
                    <!-- بخش تصاویر (سمت چپ) -->
                    <div class="col-lg-6 mb-4 mb-lg-0">
                        <div id="aboutCarousel"
                            class="carousel slide image-carousel carousel-fade rounded-circle overflow-hidden"
                            data-bs-ride="carousel">
                            <div class="carousel-inner h-100 rounded-circle">
                                <div class="carousel-item active">
                                    <img src="images/about1.jpg" class="d-block w-100 c-img rounded-circle"
                                        alt="بیوتی پینک">
                                </div>
                                <div class="carousel-item">
                                    <img src="images/about2.jpg" class="d-block w-100 c-img rounded-circle"
                                        alt="بیوتی پینک">
                                </div>
                            </div>
                            <button class="carousel-control-prev" type="button" data-bs-target="#aboutCarousel"
                                data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">قبلی</span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#aboutCarousel"
                                data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">بعدی</span>
                            </button>
                        </div>
                    </div>

                    <!-- بخش محتوا (سمت راست) -->
                    <div class="col-lg-6 about-content">
                        <h2 class="about-title">فروشگاه محصولات آرایشی</h2>
                        <p class="about-subtitle">درباره بیوتی پینک</p>
                        <p class="mb-4"><strong>بیوتی پینک</strong> به عنوان اولین و جامع‌ترین فروشگاه
                            اینترنتی
                            تخصصی آرایشی و بهداشتی و نماینده رسمی بیش از 250 برند، مجموعه‌ای کامل از بهترین
                            محصولات
                            آرایشی و بهداشتی را در اختیار مشتریان قرار داده و صبورانه، با اراده و منعطف، تبدیل
                            به
                            بزرگترین فروشگاه آنلاین معتبر آرایشی و بهداشتی شده است.</p>
                        <p class="mb-4">ما در<strong>فروشگاه بیوتی پینک</strong> همواره در تلاشیم که با تامین
                            کالاهای
                            آرایشی و بهداشتی باکیفیت، تجربه‌ خرید اینترنتی خوشایندی را برای شما رقم زده و نیازها
                            و
                            دانش مرتبط با زنانگی، زیبایی و باور به خویش را در قالب یک سوپر اپلیکیشن تخصصی و
                            معتبر،
                            گردآوری و در اختیار تمامی زنان از هر نقطه‌ای از ایران قرار دهیم. </p>
                        <button class="btn about-btn about-us">
                            <a href="about-us.php" class="fas fa-arrow-left ms-2 text-decoration-none"
                                style="color: #e75480;">
                                درباره
                                ما</a>
                        </button>
                    </div>
                </div>
            </div>
        </section>
        <section class="about-section container py-5">
            <h2 class="fw-bold text-center mb-5">برندهای برتر</h2>
            <div class="brands-grid text-center">
                <!-- برند کالیستا - ID را با مقدار واقعی جایگزین کنید -->
                <a href="brand.php?id=1" class="brand-logo">
                    <img src="images/برند کالیستا.png" alt="برند کالیستا" class="img-fluid">
                </a>

                <!-- برند ژیناژن - ID را با مقدار واقعی جایگزین کنید -->
                <a href="brand.php?id=11" class="brand-logo">
                    <img src="images/برند ژیناژن.png" alt="برند ژیناژن" class="img-fluid">
                </a>

                <!-- برند آردن - ID را با مقدار واقعی جایگزین کنید -->
                <a href="brand.php?id=5" class="brand-logo">
                    <img src="images/برند آردن .png" alt=" برند آردن" class="img-fluid">
                </a>
                <a href="brand.php?id=8" class="brand-logo">
                    <img src="images/برند لافارر.jpg" alt="برند لافارر" class="img-fluid">
                </a>
                <a href="brand.php?id=3" class="brand-logo">
                    <img src="images/برند مای.jpg" alt="برند مای" class="img-fluid">
                </a>
                <a href="brand.php?id=6" class="brand-logo">
                    <img src="images/برند فولیکا.png" alt="برند فولیکا" class="img-fluid">
                </a>
            </div>
        </section>

        <style>
        .brands-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 2rem;
            justify-content: center;
            align-items: center;
        }


        .brand-logo img {
            max-height: 80px;
            width: auto;
            object-fit: contain;
        }

        @media (max-width: 768px) {
            .brands-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        </style>
        <footer>
            <style>
            .about-header {
                background: linear-gradient(to left, #ff85a2, #ffaccb);
                color: white;
                padding: 60px 0;
                margin-bottom: 40px;
            }

            .about-section {
                background-color: white;
                border-radius: 15px;
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
                padding: 30px;
                margin-bottom: 30px;
            }

            .mission-vision {
                border-right: 4px solid #ff85a2;
                padding-right: 20px;
            }

            .brands-section img {
                height: 60px;
                margin: 10px;
                filter: grayscale(30%);
                transition: all 0.3s;
            }

            .brands-section img:hover {
                filter: grayscale(0%);
                transform: scale(1.1);
            }

            .team-member {
                text-align: center;
                margin-bottom: 30px;
            }

            .team-member img {
                width: 150px;
                height: 150px;
                object-fit: cover;
                border-radius: 50%;
                border: 5px solid #ffc0cb;
                margin-bottom: 15px;
            }

            .footer {
                background-color: #ff85a2;
                color: white;
                padding-top: 30px;
            }

            .footer-links h5 {
                border-bottom: 2px solid #ffc0cb;
                padding-bottom: 10px;
                margin-bottom: 20px;
            }

            .footer-links a {
                color: white;
                text-decoration: none;
                display: block;
                margin-bottom: 10px;
                transition: all 0.3s;
            }

            .footer-links a:hover {
                color: #ffe6eb;
                padding-right: 5px;
            }

            .social-icons a {
                color: white;
                font-size: 20px;
                margin-left: 15px;
                transition: all 0.3s;
            }

            .social-icons a:hover {
                color: #ffe6eb;
                transform: translateY(-3px);
            }

            .copyright {
                background-color: #e75480;
                padding: 15px 0;
                margin-top: 30px;
            }
            </style>
            </head>

            <body>
                <!-- Footer -->
                <footer class="footer">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-3 col-sm-6 mb-4">
                                <div class="footer-links">
                                    <h5>اطلاعات سایت</h5>
                                    <a href="about-us.php">درباره ما</a>
                                    <a href="contact-us.php">تماس با ما</a>
                                    <a href="jobs.php">فرصت‌های شغلی</a>
                                    <a href="privacy.php">حریم خصوصی</a>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6 mb-4">
                                <div class="footer-links">
                                    <h5>خدمات مشتریان</h5>
                                    <a href="faq.php">پرسش‌های متداول</a>
                                    <a href="shopping-guide.php">راهنمای خرید و پرداخت</a>
                                    <a href="shopping.php">رویه‌های ارسال</a>
                                    <a href="return-policy.php">شرایط مرجوعی</a>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6 mb-4">
                                <div class="footer-links">
                                    <h5>خدمات ویژه</h5>
                                    <a href="support.php">ارتباط با پشتیبانی</a>
                                    <a href="blog.php">وبلاگ زیبایی</a>
                                    <a href="consultation.php">مشاوره آرایشی</a>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6 mb-4">
                                <div class="footer-links">
                                    <h5>ما را دنبال کنید</h5>
                                    <p>برای دریافت جدیدترین تخفیف‌ها و محصولات ما را در شبکه‌های اجتماعی دنبال کنید.</p>
                                    <div class="social-icons mt-3">
                                        <a href="https://instagram.com" target="_blank"><i
                                                class="bi bi-instagram"></i></a>
                                        <a href="https://telegram.org" target="_blank"><i
                                                class="bi bi-telegram"></i></a>
                                        <a href="https://whatsapp.com" target="_blank"><i
                                                class="bi bi-whatsapp"></i></a>
                                        <a href="https://twitter.com" target="_blank"><i class="bi bi-twitter"></i></a>
                                        <a href="https://aparat.com" target="_blank"><i class="fab fa-youtube"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="copyright text-center">
                        <div class="container">
                            <p class="mb-0">© ۱۴۰۲ تمامی حقوق برای سایت لوازم آرایشی محفوظ است.</p>
                        </div>
                    </div>
                </footer>
        </footer>
        <!-- اسکریپت‌های Bootstrap -->

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>