<?php
session_start();
require_once 'db.php';

// بررسی آیا کاربر مدیر است یا نه
if(!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header('Location: login.php');
    exit;
}
// دریافت آمار جدید
$low_stock = $db->query("SELECT COUNT(*) FROM products WHERE stock < 10")->fetchColumn();
$categories_count = $db->query("SELECT COUNT(*) FROM categories")->fetchColumn();
$subcategories_count = $db->query("SELECT COUNT(*) FROM subcategories")->fetchColumn();

// دریافت آمار
$users_count = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
$products_count = $db->query("SELECT COUNT(*) FROM products")->fetchColumn();
$orders_count = $db->query("SELECT COUNT(*) FROM orders")->fetchColumn();
?>

<!DOCTYPE html>
<html dir="rtl" lang="fa">

<head>
    <style>
    .quick-actions .btn {
        margin: 5px;
        min-width: 120px;
    }

    .stat-card {
        transition: transform 0.3s;
    }

    .stat-card:hover {
        transform: translateY(-5px);
    }

    .low-stock {
        color: #dc3545;
        font-weight: bold;
    }
    </style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پنل مدیریت</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>

<body>
    <div class="container py-4">
        <div class="row g-4">
            <!-- سایدبار -->
            <div class="col-md-4">
                <div class="card shadow-sm sticky-top" style="top: 20px;">
                    <div class="card-body p-0">
                        <!-- منوی اصلی -->
                        <div class="list-group list-group-flush rounded">
                            <a href="dashboard.php" class="list-group-item list-group-item-action active py-3" style=" background-color: #9c1e48 !important;
                             border:none !important;">
                                <i class="bi bi-speedometer2 me-2"></i> داشبورد
                            </a>
                            <a href="admin_products.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-box-seam me-2"></i> محصولات
                            </a>
                            <a href="admin_categories.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-tags me-2"></i> دسته‌بندی‌ها
                            </a>
                            <a href="admin_subcategories.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-tag me-2"></i> زیردسته‌بندی‌ها
                            </a>
                            <a href="admin_orders.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-cart-check me-2"></i> سفارشات
                            </a>
                            <a href="admin_users.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-people me-2"></i> کاربران
                            </a>
                            <a href="index.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-house me-2"></i>صفحه اصلی
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- محتوای اصلی -->
            <div class="col-md-8">
                <h4 class="mb-4 p-style p-3 rounded text-white">داشبورد مدیریت</h4>

                <!-- کارت‌های آماری محصولات -->
                <div class="row g-3 mb-4">


                    <!-- کارت دسته‌بندی‌ها -->
                    <div class="col-md-4">
                        <div class="card shadow-sm border-0 stat-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted mb-2">تعداد دسته‌بندی‌ها</h6>
                                        <h3 class="mb-0"><?= number_format($categories_count) ?></h3>
                                    </div>
                                    <div class="bg-light p-3 rounded" style="background-color: #f8e1e8 !important;">
                                        <i class="bi bi-tags fs-4" style="color: #9c1e48;"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card shadow-sm border-0 stat-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted mb-2">زیردسته‌بندی‌ها</h6>
                                        <h3 class="mb-0"><?= number_format($subcategories_count) ?></h3>
                                    </div>
                                    <div class="bg-light p-3 rounded" style="background-color: #f8e1e8 !important;">
                                        <i class="bi bi-tag fs-4" style="color: #9c1e48;"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- کارت کل محصولات -->
                    <div class="col-md-4">
                        <div class="card shadow-sm border-0 stat-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted mb-2">کل محصولات</h6>
                                        <h3 class="mb-0"><?= number_format($products_count) ?></h3>
                                    </div>
                                    <div class="bg-light p-3 rounded" style="background-color: #f8e1e8 !important;">
                                        <i class="bi bi-box-seam fs-4" style="color: #9c1e48;"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>



                <!-- آخرین سفارشات -->
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-body">
                        <h5 class="card-title border-bottom pb-2">آخرین سفارشات</h5>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>شماره</th>
                                        <th>مشتری</th>
                                        <th>تاریخ</th>
                                        <th>وضعیت</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                $orders = $db->query("
                                    SELECT o.id, o.created_at, o.status, u.name as customer_name 
                                    FROM orders o
                                    JOIN users u ON o.user_id = u.id
                                    ORDER BY o.created_at DESC 
                                    LIMIT 5
                                ")->fetchAll();
                                
                                foreach($orders as $order):
                                    $status_class = [
                                        'pending' => 'warning',
                                        'processing' => 'info',
                                        'completed' => 'success',
                                        'cancelled' => 'danger'
                                    ][$order['status']] ?? 'secondary';
                                ?>
                                    <tr>
                                        <td>#<?= $order['id'] ?></td>
                                        <td><?= htmlspecialchars($order['customer_name']) ?></td>
                                        <td><?= date('Y/m/d', strtotime($order['created_at'])) ?></td>
                                        <td>
                                            <span class="badge bg-<?= $status_class ?>">
                                                <?= [
                                                'pending' => 'در انتظار',
                                                'processing' => 'در حال پردازش',
                                                'completed' => 'تکمیل شده',
                                                'cancelled' => 'لغو شده'
                                            ][$order['status']] ?? $order['status'] ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- پربازدید ترین محصولات -->
                <section class="container my-5 bg-light p-4 rounded">
                    <h2 class="text-center mb-4 border-bottom pb-2">پربازدیدترین محصولات</h2>
                    <div class="row flex-nowrap overflow-auto">
                        <?php
        // کوئری برای دریافت پربازدیدترین محصولات
        $most_viewed = $db->query("SELECT * FROM products ORDER BY views DESC LIMIT 30");
        while($product = $most_viewed->fetch()):
        ?>
                        <div class="col-md-3 mb-4">
                            <div class="card h-100 shadow-sm">
                                <div class="card-body d-flex flex-column">
                                    <h5 class="card-title"><?= htmlspecialchars($product['name']) ?></h5>
                                    <p class="text-success fw-bold"><?= number_format($product['price']) ?> تومان</p>
                                    <div class="mt-auto">
                                        <small class="text-muted"><?= $product['views'] ?> بازدید</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    </div>
                </section>

            </div>
        </div>
    </div>
</body>

</html>