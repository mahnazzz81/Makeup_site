<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پرسش‌های متداول | بیوتی پینک - فروشگاه لوازم آرایشی</title>
    <!-- Bootstrap 5 RTL -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Minimal Custom CSS -->
    <style>
    .bg-pink-light {
        background: linear-gradient(to left, #ff85a2, #ffaccb);
    }

    .text-pink {
        color: #d63384;
    }

    .accordion-button:not(.collapsed) {
        background-color: rgba(214, 51, 132, 0.1);
        color: #d63384;
    }

    .accordion-button:focus {
        box-shadow: 0 0 0 0.25rem rgba(214, 51, 132, 0.25);
    }
    </style>
</head>

<body class="bg-pink-light">
    <!-- Header -->
    <header class="bg-gradient py-5" style="background: linear-gradient(135deg, #ff85a2 0%, #d63384 100%);">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h1 class="text-white display-4 fw-bold mb-3">
                        <i class="fas fa-question-circle me-2"></i>پرسش‌های متداول
                    </h1>
                    <p class="lead text-white">پاسخ سوالات خود را اینجا پیدا کنید</p>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <!-- Search Box -->
                <div class="card shadow-sm border-0 mb-5">
                    <div class="card-body p-4">
                        <div class="input-group">
                            <input type="text" class="form-control form-control-lg" placeholder="جستجو در سوالات...">
                            <button class="btn btn-pink" type="button">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- FAQ Categories -->
                <div class="d-flex flex-wrap gap-2 mb-4 justify-content-center">
                    <a href="#" class="btn btn-outline-pink active">همه دسته‌ها</a>
                    <a href="#" class="btn btn-outline-pink">سفارش و ارسال</a>
                    <a href="#" class="btn btn-outline-pink">پرداخت</a>
                    <a href="#" class="btn btn-outline-pink">محصولات</a>
                    <a href="#" class="btn btn-outline-pink">بازگرداندن کالا</a>
                    <a href="#" class="btn btn-outline-pink">حساب کاربری</a>
                </div>

                <!-- FAQ Accordion -->
                <div class="accordion" id="faqAccordion">
                    <!-- Question 1 -->
                    <div class="accordion-item border-0 shadow-sm mb-3">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#question1">
                                <i class="fas fa-question-circle text-pink me-2"></i>
                                چگونه می‌توانم سفارش خود را پیگیری کنم؟
                            </button>
                        </h2>
                        <div id="question1" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                پس از ثبت سفارش، یک کد رهگیری برای شما ارسال می‌شود. می‌توانید با وارد کردن این کد در
                                بخش <a href="#" class="text-pink">پیگیری سفارش</a> سایت یا از طریق تماس با پشتیبانی در
                                ۰۲۱-۱۲۳۴۵۶۷۸ از وضعیت سفارش خود مطلع شوید.
                            </div>
                        </div>
                    </div>

                    <!-- Question 2 -->
                    <div class="accordion-item border-0 shadow-sm mb-3">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#question2">
                                <i class="fas fa-question-circle text-pink me-2"></i>
                                شرایط بازگرداندن کالا چگونه است؟
                            </button>
                        </h2>
                        <div id="question2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                شما می‌توانید تا ۷ روز پس از دریافت محصول، درخواست بازگشت کالا دهید. کالا باید در
                                بسته‌بندی اصلی و بدون استفاده باشد. برای شروع فرآیند بازگشت کالا، لطفاً به بخش <a
                                    href="#" class="text-pink">بازگرداندن کالا</a> در حساب کاربری خود مراجعه کنید.
                            </div>
                        </div>
                    </div>

                    <!-- Question 3 -->
                    <div class="accordion-item border-0 shadow-sm mb-3">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#question3">
                                <i class="fas fa-question-circle text-pink me-2"></i>
                                آیا امکان پرداخت در محل وجود دارد؟
                            </button>
                        </h2>
                        <div id="question3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                بله، در حال حاضر امکان پرداخت در محل برای تمام سفارشات داخل تهران وجود دارد. برای سایر
                                شهرها، این سرویس به زودی راه‌اندازی خواهد شد. مبلغ قابل پرداخت در محل شامل هزینه کالا به
                                همراه هزینه ارسال می‌باشد.
                            </div>
                        </div>
                    </div>

                    <!-- Question 4 -->
                    <div class="accordion-item border-0 shadow-sm mb-3">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#question4">
                                <i class="fas fa-question-circle text-pink me-2"></i>
                                چگونه می‌توانم از تخفیف‌های ویژه مطلع شوم؟
                            </button>
                        </h2>
                        <div id="question4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                با عضویت در خبرنامه سایت و پیج اینستاگرام بیوتی پینک <a href="#"
                                    class="text-pink">(@beautypink)</a> از آخرین تخفیف‌ها و پیشنهادهای ویژه ما با خبر
                                شوید. همچنین به اعضای ویژه سایت، کدهای تخفیف اختصاصی از طریق پیامک ارسال می‌شود.
                            </div>
                        </div>
                    </div>

                    <!-- Question 5 -->
                    <div class="accordion-item border-0 shadow-sm mb-3">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#question5">
                                <i class="fas fa-question-circle text-pink me-2"></i>
                                آیا محصولات بیوتی پینک اصل هستند؟
                            </button>
                        </h2>
                        <div id="question5" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                تمام محصولات موجود در بیوتی پینک با گارانتی اصالت کالا عرضه می‌شوند. ما تنها از
                                تامین‌کنندگان معتبر و رسمی خریداری می‌کنیم و برای اطمینان بیشتر می‌توانید کد اصالت درج
                                شده روی محصولات را از طریق سایت‌های مربوطه بررسی کنید.
                            </div>
                        </div>
                    </div>

                    <!-- Question 6 -->
                    <div class="accordion-item border-0 shadow-sm mb-3">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#question6">
                                <i class="fas fa-question-circle text-pink me-2"></i>
                                زمان تحویل سفارشات چقدر است؟
                            </button>
                        </h2>
                        <div id="question6" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                <ul class="list-unstyled">
                                    <li><strong>تهران:</strong> ۱ تا ۲ روز کاری</li>
                                    <li><strong>شهرهای مرکزی:</strong> ۲ تا ۳ روز کاری</li>
                                    <li><strong>سایر شهرها:</strong> ۳ تا ۵ روز کاری</li>
                                </ul>
                                توجه: سفارشات در روزهای غیرکاری پردازش نمی‌شوند.
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Still Have Questions -->
                <div class="card shadow-sm border-0 mt-5">
                    <div class="card-body text-center p-5">
                        <i class="fas fa-headset text-pink display-4 mb-3"></i>
                        <h3 class="text-pink mb-3">هنوز سوالی دارید؟</h3>
                        <p class="lead mb-4">تیم پشتیبانی بیوتی پینک آماده پاسخگویی به شماست</p>
                        <div class="d-flex flex-wrap justify-content-center gap-3">
                            <a href="tel:02112345678" class="btn btn-pink px-4">
                                <i class="fas fa-phone me-2"></i>تماس تلفنی
                            </a>
                            <a href="mailto:info@beautypink.ir" class="btn btn-outline-pink px-4">
                                <i class="fas fa-envelope me-2"></i>ارسال ایمیل
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-center text-md-start">
                    <p class="mb-0">© ۲۰۲۳ بیوتی پینک - تمام حقوق محفوظ است</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <a href="#" class="text-white text-decoration-none me-3">قوانین و مقررات</a>
                    <a href="#" class="text-white text-decoration-none">حریم خصوصی</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>