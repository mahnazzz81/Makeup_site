// افزایش تعداد آیتم‌های سبد خرید (مثال)
let cartCount = 0;
const cartElement = document.querySelector('.cart-count');
function toggleSearch() {
    const searchForm = document.querySelector('.search-form');
    if(searchForm.style.display === 'flex') {
        searchForm.style.display = 'none';
    } else {
        searchForm.style.display = 'flex';
    }
}
function toggleMenu() {
    const sidebar = document.getElementById('sidebar-menu');
    sidebar.classList.toggle('active');
}
document.addEventListener('DOMContentLoaded', function() {
    const carousel = document.getElementById('carouselExampleAutoplaying');
    let isAnimating = false;
  
    // تنظیمات قابل تغییر
    const ZOOM_SCALE = 1.05;
    const ZOOM_DURATION = 600; // میلی‌ثانیه
    
    carousel.addEventListener('slide.bs.carousel', function(e) {
      if (isAnimating) return;
      isAnimating = true;
      
      const currentImg = e.from === 0 ? 
        this.querySelectorAll('.carousel-item img')[e.from] : 
        this.querySelector(`.carousel-item:nth-child(${e.from + 1}) img`);
      
      const nextImg = this.querySelector(`.carousel-item:nth-child(${e.to + 1}) img`);
  
      // انیمیشن همزمان
      if (currentImg) {
        currentImg.style.transition = `transform ${ZOOM_DURATION}ms cubic-bezier(0.25, 0.46, 0.45, 0.94)`;
        currentImg.style.transform = 'scale(0.95)';
      }
  
      if (nextImg) {
        nextImg.style.transition = `transform ${ZOOM_DURATION}ms cubic-bezier(0.25, 0.46, 0.45, 0.94)`;
        nextImg.style.transform = `scale(${ZOOM_SCALE})`;
        
        setTimeout(() => {
          nextImg.style.transform = 'scale(1)';
          isAnimating = false;
        }, ZOOM_DURATION);
      }
    });
  });
