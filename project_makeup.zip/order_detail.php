<?php
session_start();
require_once 'db.php';

if(!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user']['id'];
$order_id = $_GET['id'];

// دریافت اطلاعات سفارش
$order_query = "SELECT o.*, u.name as user_name, u.phone as user_phone 
                FROM orders o
                JOIN users u ON o.user_id = u.id
                WHERE o.id = ? AND o.user_id = ?";
$order_stmt = $db->prepare($order_query);
$order_stmt->execute([$order_id, $user_id]);
$order = $order_stmt->fetch();

if(!$order) {
    die("سفارش مورد نظر یافت نشد");
}

// دریافت آیتم‌های سفارش
$items_query = "SELECT oi.*, p.description 
                FROM orders_items oi
                LEFT JOIN products p ON oi.product_id = p.id
                WHERE oi.order_id = ?";
$items_stmt = $db->prepare($items_query);
$items_stmt->execute([$order_id]);
$order_items = $items_stmt->fetchAll();
?>

<!DOCTYPE html>
<html dir="rtl" lang="fa">

<head>
    <meta charset="UTF-8">
    <title>جزئیات سفارش #<?= $order_id ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container py-5">
        <h2 class="mb-4">جزئیات سفارش #<?= $order_id ?></h2>

        <div class="row">
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        اطلاعات سفارش
                    </div>
                    <div class="card-body">
                        <p><strong>تاریخ سفارش:</strong> <?= $order['created_at'] ?></p>
                        <p><strong>وضعیت:</strong> <?= $order['status'] ?></p>
                        <p><strong>روش پرداخت:</strong> <?= $order['payment_method'] ?></p>
                        <p><strong>مبلغ کل:</strong> <?= number_format($order['total_price']) ?> تومان</p>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        اطلاعات ارسال
                    </div>
                    <div class="card-body">
                        <p><strong>آدرس:</strong> <?= nl2br($order['shipping_address']) ?></p>
                        <?php if($order['tracking_code']): ?>
                        <p><strong>کد رهگیری:</strong> <?= $order['tracking_code'] ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header bg-primary text-white">
                محصولات سفارش
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>محصول</th>
                            <th>تعداد</th>
                            <th>قیمت واحد</th>
                            <th>جمع</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($order_items as $item): ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <?php if($item['product_image']): ?>
                                    <img src="images/products/<?= $item['product_image'] ?>" width="50" class="me-3">
                                    <?php endif; ?>
                                    <div>
                                        <h6><?= $item['product_name'] ?></h6>
                                        <?php if($item['description']): ?>
                                        <small
                                            class="text-muted"><?= mb_substr($item['description'], 0, 50) ?>...</small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td><?= $item['quantity'] ?></td>
                            <td><?= number_format($item['price']) ?> تومان</td>
                            <td><?= number_format($item['price'] * $item['quantity']) ?> تومان</td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>

</html>