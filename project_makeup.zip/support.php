<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تماس با پشتیبانی | بیوتی پینک</title>
    <!-- Bootstrap 5 RTL CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
    .contact-header {
        background: linear-gradient(to left, #ff85a2, #ffaccb);

        color: white;
    }

    .contact-icon {
        font-size: 2.5rem;
        color: #d63384;
    }

    .form-control,
    .form-select {
        border-radius: 10px;
        padding: 12px 15px;
    }

    .btn-pink {
        background-color: #d63384;
        color: white;
        padding: 12px 30px;
        border-radius: 10px;
        font-weight: 600;
    }

    .btn-pink:hover {
        background-color: #a5276a;
        color: white;
    }

    .contact-card {
        border-radius: 15px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s;
        height: 100%;
    }

    .contact-card:hover {
        transform: translateY(-5px);
    }

    .social-icon {
        font-size: 1.5rem;
        color: #d63384;
        margin: 0 10px;
        transition: all 0.3s;
    }

    .social-icon:hover {
        color: #a5276a;
        transform: scale(1.2);
    }
    </style>
</head>

<body>
    <!-- هدر صفحه -->
    <header class="contact-header py-5 mb-5">
        <div class="container text-center">
            <h1 class="display-4 fw-bold mb-3">تماس با پشتیبانی بیوتی پینک</h1>
            <p class="lead">ما اینجا هستیم تا به شما کمک کنیم. سوالات و پیشنهادات خود را با ما در میان بگذارید.</p>
        </div>
    </header>

    <!-- بخش اصلی -->
    <main class="container mb-5">
        <div class="row g-5">
            <!-- فرم تماس -->
            <div class="col-lg-7">
                <div class="card contact-card p-4 p-md-5">
                    <h2 class="mb-4 text-center"><i class="fas fa-envelope me-2"></i>فرم تماس با ما</h2>
                    <form>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label for="firstName" class="form-label">نام</label>
                                <input type="text" class="form-control" id="firstName" required>
                            </div>
                            <div class="col-md-6">
                                <label for="lastName" class="form-label">نام خانوادگی</label>
                                <input type="text" class="form-control" id="lastName" required>
                            </div>
                            <div class="col-12">
                                <label for="email" class="form-label">ایمیل</label>
                                <input type="email" class="form-control" id="email" required>
                            </div>
                            <div class="col-12">
                                <label for="phone" class="form-label">شماره تماس</label>
                                <input type="tel" class="form-control" id="phone">
                            </div>
                            <div class="col-12">
                                <label for="subject" class="form-label">موضوع</label>
                                <select class="form-select" id="subject">
                                    <option selected>لطفا انتخاب کنید...</option>
                                    <option>پرسش درباره محصولات</option>
                                    <option>مشکل در سفارش</option>
                                    <option>پیشنهاد یا انتقاد</option>
                                    <option>همکاری با ما</option>
                                    <option>سایر موارد</option>
                                </select>
                            </div>
                            <div class="col-12">
                                <label for="message" class="form-label">پیام شما</label>
                                <textarea class="form-control" id="message" rows="5" required></textarea>
                            </div>
                            <div class="col-12 text-center mt-4">
                                <button type="submit" class="btn btn-pink btn-lg">ارسال پیام</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- اطلاعات تماس -->
            <div class="col-lg-5">
                <div class="card contact-card p-4 p-md-5 h-100">
                    <h2 class="mb-4 text-center"><i class="fas fa-info-circle me-2"></i>راه های ارتباطی</h2>

                    <div class="d-flex align-items-start mb-4">
                        <div class="contact-icon me-4">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold">آدرس</h5>
                            <p class="mb-0">تهران، خیابان ولیعصر، پلاک ۱۲۳۴، طبقه دوم</p>
                        </div>
                    </div>

                    <div class="d-flex align-items-start mb-4">
                        <div class="contact-icon me-4">
                            <i class="fas fa-phone-alt"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold">تلفن پشتیبانی</h5>
                            <p class="mb-0">۰۲۱-۱۲۳۴۵۶۷۸</p>
                            <p class="mb-0">۰۹۱۲-۳۴۵-۶۷۸۹</p>
                        </div>
                    </div>

                    <div class="d-flex align-items-start mb-4">
                        <div class="contact-icon me-4">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold">ایمیل</h5>
                            <p class="mb-0">support@beautypink.ir</p>
                            <p class="mb-0">info@beautypink.ir</p>
                        </div>
                    </div>

                    <div class="d-flex align-items-start">
                        <div class="contact-icon me-4">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold">ساعات کاری</h5>
                            <p class="mb-0">شنبه تا چهارشنبه: ۹ صبح تا ۵ عصر</p>
                            <p class="mb-0">پنجشنبه: ۹ صبح تا ۱ بعدازظهر</p>
                        </div>
                    </div>

                    <hr class="my-4">

                    <div class="text-center">
                        <h5 class="fw-bold mb-3">ما را در شبکه های اجتماعی دنبال کنید</h5>
                        <div>
                            <a href="#" class="social-icon"><i class="fab fa-instagram"></i></a>
                            <a href="#" class="social-icon"><i class="fab fa-telegram"></i></a>
                            <a href="#" class="social-icon"><i class="fab fa-whatsapp"></i></a>
                            <a href="#" class="social-icon"><i class="fab fa-twitter"></i></a>
                            <a href="#" class="social-icon"><i class="fab fa-facebook"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- نقشه -->
    <section class="container mb-5">
        <div class="card contact-card overflow-hidden">
            <div class="row g-0">
                <div class="col-lg-6 p-4 p-md-5">
                    <h3 class="mb-4">ما کجا هستیم؟</h3>
                    <p>شما می‌توانید برای مشاوره و خرید حضوری به آدرس فروشگاه ما مراجعه کنید. کارشناسان ما آماده
                        پاسخگویی به سوالات شما هستند.</p>
                    <div class="mt-4">
                        <button class="btn btn-pink">
                            <i class="fas fa-directions me-2"></i>دریافت مسیر از گوگل مپ
                        </button>
                    </div>
                </div>
                <div class="col-lg-6 d-none d-lg-block">
                    <div
                        style="height: 100%; background: #eee; display: flex; align-items: center; justify-content: center;">
                        <i class="fas fa-map-marked-alt" style="font-size: 3rem; color: #d63384;"></i>
                    </div>
                    <!-- در اینجا می‌توانید کد embed گوگل مپ را قرار دهید -->
                </div>
            </div>
        </div>
    </section>

    <!-- سوالات متداول -->
    <section class="container mb-5">
        <h2 class="text-center mb-5">سوالات متداول</h2>
        <div class="accordion" id="faqAccordion">
            <div class="accordion-item mb-3 border-0 shadow-sm rounded-3 overflow-hidden">
                <h3 class="accordion-header" id="headingOne">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                        data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                        چگونه می‌توانم سفارشم را پیگیری کنم؟
                    </button>
                </h3>
                <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne"
                    data-bs-parent="#faqAccordion">
                    <div class="accordion-body">
                        پس از ثبت سفارش، کد رهگیری برای شما ارسال می‌شود. شما می‌توانید با وارد کردن این کد در بخش
                        پیگیری سفارش در سایت، وضعیت سفارش خود را مشاهده کنید.
                    </div>
                </div>
            </div>
            <div class="accordion-item mb-3 border-0 shadow-sm rounded-3 overflow-hidden">
                <h3 class="accordion-header" id="headingTwo">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                        data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                        شرایط بازگشت کالا چگونه است؟
                    </button>
                </h3>
                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                    data-bs-parent="#faqAccordion">
                    <div class="accordion-body">
                        در صورت وجود مشکل در کالای دریافتی، تا ۷ روز پس از دریافت می‌توانید درخواست بازگشت دهید. کالا
                        باید در شرایط اولیه و بدون استفاده باشد. برای اطلاعات بیشتر به صفحه شرایط بازگشت مراجعه کنید.
                    </div>
                </div>
            </div>
            <div class="accordion-item mb-3 border-0 shadow-sm rounded-3 overflow-hidden">
                <h3 class="accordion-header" id="headingThree">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                        data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                        آیا امکان خرید حضوری وجود دارد؟
                    </button>
                </h3>
                <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree"
                    data-bs-parent="#faqAccordion">
                    <div class="accordion-body">
                        بله، شما می‌توانید برای خرید حضوری به آدرس فروشگاه ما مراجعه کنید. همچنین می‌توانید قبل از
                        مراجعه با شماره فروشگاه تماس بگیرید تا از موجودی محصولات مطمئن شوید.
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- فوتر -->
    <footer class="bg-light py-4">
        <div class="container text-center">
            <p class="mb-0">© 2023 بیوتی پینک - تمامی حقوق محفوظ است</p>
        </div>
    </footer>

    <!-- Bootstrap 5 JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>