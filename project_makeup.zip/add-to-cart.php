<?php
session_start();
require_once 'db.php';

// بررسی لاگین بودن کاربر
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// دریافت اطلاعات محصول
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_to_cart'])) {
    $product_id = (int)$_POST['product_id'];
    $user_id = (int)$_SESSION['user_id'];

    try {
        // بررسی وجود محصول در دیتابیس
        $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch();

        if (!$product) {
            die("محصول یافت نشد!");
        }

        // بررسی وجود محصول در سبد خرید کاربر
        $stmt = $db->prepare("SELECT * FROM cart WHERE user_id = ? AND product_id = ?");
        $stmt->execute([$user_id, $product_id]);
        $existing_item = $stmt->fetch();

        if ($existing_item) {
            // اگر موجود بود، تعداد را افزایش بده
            $new_quantity = $existing_item['quantity'] + 1;
            $stmt = $db->prepare("UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?");
            $stmt->execute([$new_quantity, $user_id, $product_id]);
            $stmt = $db->prepare("UPDATE cart SET quantity = ?, image = ? WHERE user_id = ? AND product_id = ?");
$stmt->execute([$new_quantity, $product['image'], $user_id, $product_id]);
        } else {
            // اگر موجود نبود، جدید اضافه کن
            $stmt = $db->prepare("INSERT INTO cart (user_id, product_id, product_name, price, quantity, image) VALUES (?, ?, ?, ?, 1, ?)");
            $stmt->execute([
                $user_id,
                $product_id,
                $product['name'],
                $product['price'],
                $product['image'] // اضافه کردن تصویر محصول به سبد خرید
            ]);
        }
       
         
        // تنظیم پیام موفقیت در session
        $_SESSION['add_to_cart_message'] = "محصول با موفقیت به سبد خرید اضافه شد!";
        $_SESSION['product_added'] = $product_id;
        
        // برگشت به صفحه محصول
        header("Location: product-detail.php?id=$product_id");
        exit();

    } catch (PDOException $e) {
        die("خطا در افزودن به سبد خرید: " . $e->getMessage());
    }
} else {
    header("Location: product-detail.php?id=$product_id");
    exit();
}