<?php
session_start();
require_once 'db.php';

// بررسی آیا کاربر مدیر است یا نه
if(!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header('Location: login.php');
    exit;
}

// دریافت تمام برندها
$brands = $db->query("SELECT * FROM brands ORDER BY name")->fetchAll();

// دریافت محصولات بر اساس برند
$products_by_brand = [];
foreach($brands as $brand) {
    $products = $db->prepare("
        SELECT p.* 
        FROM products p
        WHERE p.brand_id = ?
        ORDER BY p.name
    ");
    $products->execute([$brand['id']]);
    $products_by_brand[$brand['name']] = $products->fetchAll();
}
?>

<!DOCTYPE html>
<html dir="rtl" lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت محصولات - نمایش بر اساس برند</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
    .brand-section {
        margin-bottom: 2rem;
        border: 1px solid #eee;
        border-radius: 8px;
        padding: 1rem;
    }

    .brand-header {
        background-color: #9c1e48;
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 5px;
        margin-bottom: 1rem;
    }

    .product-card {
        transition: transform 0.3s;
        margin-bottom: 1rem;
    }

    .product-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    .low-stock {
        color: #dc3545;
        font-weight: bold;
    }
    </style>
</head>

<body>
    <div class="container py-4">
        <div class="row g-4">
            <!-- سایدبار -->
            <div class="col-md-3">
                <div class="card shadow-sm sticky-top" style="top: 20px;">
                    <div class="card-body p-0">
                        <!-- منوی اصلی -->
                        <div class="list-group list-group-flush rounded">
                            <a href="dashboard.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-speedometer2 me-2"></i> داشبورد
                            </a>
                            <a href="admin_products.php" class="list-group-item list-group-item-action active py-3"
                                style="background-color: #9c1e48 !important; border:none !important;">
                                <i class="bi bi-box-seam me-2"></i> محصولات
                            </a>
                            <a href="admin_categories.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-tags me-2"></i> دسته‌بندی‌ها
                            </a>
                            <a href="admin_subcategories.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-tag me-2"></i> زیردسته‌بندی‌ها
                            </a>
                            <a href="admin_orders.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-cart-check me-2"></i> سفارشات
                            </a>
                            <a href="admin_users.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-people me-2"></i> کاربران
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- محتوای اصلی -->
            <div class="col-md-9">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="mb-0">مدیریت محصولات (بر اساس برند)</h4>
                    <a href="add-product.php" class="btn" style="background-color: #9c1e48; color: white;">
                        <i class="bi bi-plus-circle"></i> افزودن محصول جدید
                    </a>
                </div>

                <!-- نمایش محصولات بر اساس برند -->
                <?php foreach($products_by_brand as $brand_name => $products): ?>
                <?php if(!empty($products)): ?>
                <div class="brand-section">
                    <div class="brand-header">
                        <h5><?= htmlspecialchars($brand_name) ?></h5>
                    </div>
                    <div class="row">
                        <?php foreach($products as $product): ?>
                        <div class="col-md-4">
                            <div class="card product-card">
                                <div class="card-body">
                                    <h6 class="card-title"><?= htmlspecialchars($product['name']) ?></h6>
                                    <p class="card-text text-muted small">
                                        موجودی:
                                        <span class="<?= $product['stock'] < 10 ? 'low-stock' : '' ?>">
                                            <?= $product['stock'] ?>
                                        </span>
                                    </p>
                                    <p class="card-text">
                                        قیمت: <?= number_format($product['price']) ?> تومان
                                    </p>
                                    <div class="d-flex justify-content-between">
                                        <a href="edit-product.php?id=<?= $product['id'] ?>"
                                            class="btn btn-sm btn-outline-primary">
                                            <i class="bi bi-pencil"></i> ویرایش
                                        </a>
                                        <a href="delete-product.php?id=<?= $product['id'] ?>"
                                            class="btn btn-sm btn-outline-danger"
                                            onclick="return confirm('آیا مطمئن هستید؟')">
                                            <i class="bi bi-trash"></i> حذف
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>