<?php
session_start();
require_once 'db.php';

// بررسی آیا کاربر مدیر است یا نه
if(!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header('Location: login.php');
    exit;
}

// دریافت ID محصول از URL
$product_id = $_GET['id'] ?? 0;

// دریافت اطلاعات محصول
$product = $db->prepare("SELECT * FROM products WHERE id = ?");
$product->execute([$product_id]);
$product = $product->fetch();

if(!$product) {
    header('Location:products.php');
    exit;
}

// پردازش حذف محصول
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    // اول تمام آیتم‌های سبد خرید مربوط به این محصول را حذف می‌کنیم
    $db->prepare("DELETE FROM cart WHERE product_id = ?")->execute([$product_id]);
    
    // سپس تصویر محصول را حذف می‌کنیم
    if($product['image'] && file_exists("images/products/" . $product['image'])) {
        unlink("images/products/" . $product['image']);
    }
    
    // در نهایت خود محصول را حذف می‌کنیم
    $db->prepare("DELETE FROM products WHERE id = ?")->execute([$product_id]);
    
    $_SESSION['success'] = "محصول با موفقیت حذف شد.";
    header('Location: products/');
    exit;
}
?>

<!DOCTYPE html>
<html dir="rtl" lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>حذف محصول</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>

<body>
    <div class="container py-4">
        <div class="row g-4">
            <!-- سایدبار -->
            <div class="col-md-4">
                <div class="card shadow-sm sticky-top" style="top: 20px;">
                    <div class="card-body p-0">
                        <!-- منوی اصلی -->
                        <div class="list-group list-group-flush rounded">
                            <a href="dashboard.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-speedometer2 me-2"></i> داشبورد
                            </a>
                            <a href="products/" class="list-group-item list-group-item-action active py-3"
                                style="background-color: #9c1e48 !important; border:none !important;">
                                <i class="bi bi-box-seam me-2"></i> محصولات
                            </a>
                            <a href="categories/" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-tags me-2"></i> دسته‌بندی‌ها
                            </a>
                            <a href="orders/" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-cart-check me-2"></i> سفارشات
                            </a>
                            <a href="users/" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-people me-2"></i> کاربران
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- محتوای اصلی -->
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h4 class="mb-4 p-style p-3 rounded text-white">حذف محصول</h4>

                        <div class="alert alert-warning">
                            <h5>آیا مطمئن هستید که می‌خواهید این محصول را حذف کنید؟</h5>
                            <p class="mb-1"><strong>نام محصول:</strong> <?= htmlspecialchars($product['name']) ?></p>
                            <p class="mb-1"><strong>قیمت:</strong> <?= number_format($product['price']) ?> تومان</p>
                            <p class="mb-1"><strong>موجودی:</strong> <?= $product['stock'] ?></p>
                            <p class="mb-1"><strong>تعداد بازدید:</strong> <?= $product['views'] ?? 0 ?></p>

                            <?php if($product['image']): ?>
                            <div class="mt-3">
                                <img src="images/products/<?= $product['image'] ?>" class="img-thumbnail"
                                    style="max-width: 200px;" alt="تصویر محصول">
                            </div>
                            <?php endif; ?>
                        </div>

                        <form method="POST">
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button type="submit" class="btn btn-danger">بله، حذف شود</button>
                                <a href="products/" class="btn btn-secondary">انصراف</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>