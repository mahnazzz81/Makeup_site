<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>راهنمای خرید و پرداخت | بیوتی پینک</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
    .bg-pink {
        background: linear-gradient(to left, #ff85a2, #ffaccb) !important;
    }

    .text-pink {
        color: #ec5a8be6 !important;
    }

    .step-icon {
        font-size: 2rem;
    }
    </style>
</head>

<body class="bg-light">
    <div class="container py-5">
        <!-- هدر -->
        <header class="bg-pink text-white p-4 mb-5 rounded text-center">
            <h1 class="mb-0"><i class="bi bi-cart-check"></i> راهنمای خرید و پرداخت</h1>
        </header>

        <!-- مراحل خرید -->
        <div class="row g-4 mb-5">
            <div class="col-md-6 col-lg-3">
                <div class="card h-100 shadow-sm">
                    <div class="card-body text-center">
                        <i class="bi bi-search step-icon text-pink mb-3"></i>
                        <h3 class="h5">۱. جستجو و انتخاب</h3>
                        <p class="text-muted">محصولات مورد نظر را در سایت جستجو و به سبد خرید اضافه کنید.</p>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-3">
                <div class="card h-100 shadow-sm">
                    <div class="card-body text-center">
                        <i class="bi bi-cart step-icon text-pink mb-3"></i>
                        <h3 class="h5">۲. ثبت سفارش</h3>
                        <p class="text-muted">پس از تکمیل سبد خرید، روی دکمه "تسویه حساب" کلیک کنید.</p>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-3">
                <div class="card h-100 shadow-sm">
                    <div class="card-body text-center">
                        <i class="bi bi-credit-card step-icon text-pink mb-3"></i>
                        <h3 class="h5">۳. پرداخت</h3>
                        <p class="text-muted">روش پرداخت را انتخاب و اطلاعات را وارد کنید.</p>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-3">
                <div class="card h-100 shadow-sm">
                    <div class="card-body text-center">
                        <i class="bi bi-truck step-icon text-pink mb-3"></i>
                        <h3 class="h5">۴. تحویل</h3>
                        <p class="text-muted">سفارش شما پردازش و در کمترین زمان ارسال می‌شود.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- روش‌های پرداخت -->
        <div class="bg-white p-4 rounded shadow-sm mb-5">
            <h2 class="text-pink mb-4"><i class="bi bi-wallet2"></i> روش‌های پرداخت</h2>
            <div class="row">
                <div class="col-md-6">
                    <div class="d-flex align-items-center mb-3 p-3 border rounded">
                        <i class="bi bi-credit-card-fill fs-3 text-pink me-3"></i>
                        <div>
                            <h3 class="h6 mb-1">درگاه بانکی</h3>
                            <p class="text-muted small">پرداخت آنلاین با تمام کارت‌های عضو شتاب</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="d-flex align-items-center mb-3 p-3 border rounded">
                        <i class="bi bi-cash-coin fs-3 text-pink me-3"></i>
                        <div>
                            <h3 class="h6 mb-1">پرداخت در محل</h3>
                            <p class="text-muted small">(فقط برای شهر تهران)</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- سوالات متداول -->
        <div class="bg-white p-4 rounded shadow-sm">
            <h2 class="text-pink mb-4"><i class="bi bi-question-circle"></i> سوالات متداول</h2>
            <div class="accordion" id="faqAccordion">
                <div class="accordion-item">
                    <h3 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#faq1">
                            چگونه می‌توانم سفارشم را پیگیری کنم؟
                        </button>
                    </h3>
                    <div id="faq1" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            پس از ثبت سفارش، کد رهگیری برای شما ارسال می‌شود. می‌توانید از طریق بخش "پیگیری سفارش" در
                            پنل کاربری وضعیت آن را مشاهده کنید.
                        </div>
                    </div>
                </div>

                <div class="accordion-item">
                    <h3 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#faq2">
                            آیا امکان بازگرداندن کالا وجود دارد؟
                        </button>
                    </h3>
                    <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            در صورت عدم رضایت از محصول تا ۷ روز پس از دریافت با حفظ شرایط اولیه کالا (در بسته‌بندی سالم)
                            می‌توانید آن را مرجوع کنید.
                        </div>
                    </div>
                </div>

                <div class="accordion-item">
                    <h3 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#faq3">
                            هزینه ارسال چگونه محاسبه می‌شود؟
                        </button>
                    </h3>
                    <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            برای خریدهای بالای ۵۰۰ هزار تومان ارسال رایگان است. در غیر این صورت هزینه ارسال بر اساس وزن
                            و مسافت محاسبه می‌شود.
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- دکمه کمک -->
        <div class="text-center mt-5">
            <a href="#" class="btn btn-pink btn-lg">
                <i class="bi bi-headset me-2"></i> نیاز به کمک دارید؟
            </a>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>