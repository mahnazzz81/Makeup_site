<?php
// فعال کردن نمایش خطاها
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// شروع سشن
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'db.php';

// بررسی مدیر بودن کاربر
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header('Location: login.php');
    exit;
}

// تنظیم متغیرهای پیام
$success = $_SESSION['success_message'] ?? '';
unset($_SESSION['success_message']);
$error = '';
// دریافت تمام دسته‌بندی‌ها
try {
    $categories = $db->query("SELECT * FROM categories")->fetchAll();
} catch (PDOException $e) {
    die("خطا در دریافت دسته‌بندی‌ها: " . $e->getMessage());
}

// دریافت تمام زیردسته‌بندی‌ها (تغییر اصلی اینجاست)
try {
    $subcategories = $db->query("SELECT * FROM subcategories")->fetchAll();
} catch (PDOException $e) {
    $error = "خطا در دریافت زیردسته‌بندی‌ها: " . $e->getMessage();
    $subcategories = [];
}


// مقادیر پیش‌فرض فرم
$formData = [
    'name' => '',
    'description' => '',
    'price' => '',
    'stock' => '',
    'category_id' => '',
    'subcategory_id' => '',
    'brand' => '',
    'is_new_arrival' => 0,
    'size' => '',
];




// پردازش فرم اصلی
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // دریافت داده‌های فرم
    $formData = [
        'name' => trim($_POST['name'] ?? ''),
        'description' => trim($_POST['description'] ?? ''),
        'price' => trim($_POST['price'] ?? ''),
        'stock' => trim($_POST['stock'] ?? ''),
        'category_id' => $_POST['category_id'] ?? '',
        'subcategory_id' => $_POST['subcategory_id'] ?? '',
        'brand' => trim($_POST['brand'] ?? ''),
        
        
        'is_new_arrival' => isset($_POST['is_new_arrival']) ? 1 : 0,
   
        'size' => trim($_POST['size'] ?? ''),
    ];

    // اعتبارسنجی
    if (empty($formData['name'])) {
        $error = "نام محصول الزامی است";
    } elseif (empty($formData['description'])) {
        $error = "توضیحات محصول الزامی است";
    } elseif (!is_numeric($formData['price']) || $formData['price'] <= 0) {
        $error = "قیمت محصول باید عددی و بزرگتر از صفر باشد";
    } elseif (!is_numeric($formData['stock']) || $formData['stock'] < 0) {
        $error = "موجودی محصول باید عددی و بزرگتر یا مساوی صفر باشد";
    } elseif (empty($formData['category_id'])) {
        $error = "دسته‌بندی الزامی است";
    } elseif (empty($formData['subcategory_id'])) {
        $error = "زیردسته‌بندی الزامی است";
    } elseif (empty($formData['brand'])) {
        $error = "برند الزامی است";
    } elseif (!isset($_FILES['image']) || $_FILES['image']['error'] != UPLOAD_ERR_OK) {
        $error = "تصویر محصول الزامی است";
    }

    // اگر خطایی وجود نداشت
    if (empty($error)) {
        $uploadDir = 'images/products/'; // پوشه products داخل images
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true); // اگر پوشه وجود ندارد، آن را ایجاد می‌کند
        }
        

        $allowedTypes = ['jpg', 'jpeg', 'png', 'webp'];
        $fileExt = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $imageName = uniqid('prod_') . '.' . $fileExt;
        $targetPath = $uploadDir . $imageName;

        if (!in_array($fileExt, $allowedTypes)) {
            $error = "فرمت فایل باید یکی از این موارد باشد: " . implode(', ', $allowedTypes);
        } elseif ($_FILES['image']['size'] > 2 * 1024 * 1024) {
            $error = "حجم فایل باید کمتر از 2 مگابایت باشد";
        } elseif (!move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
            $error = "خطا در آپلود تصویر";
        }

        // اگر تصویر با موفقیت آپلود شد
        if (empty($error)) {
            $db->beginTransaction();
            
            try {
                // مدیریت برند
                $stmt = $db->prepare("SELECT id FROM brands WHERE name = ?");
                $stmt->execute([$formData['brand']]);
                $brand = $stmt->fetch();
                
                if ($brand) {
                    $brand_id = $brand['id'];
                } else {
                    $stmt = $db->prepare("INSERT INTO brands (name, created_at) VALUES (?, NOW())");
                    $stmt->execute([$formData['brand']]);
                    $brand_id = $db->lastInsertId();
                }
               
                
                // ذخیره محصول
                $stmt = $db->prepare("INSERT INTO products 
(name, description, price, stock, image, category_id, subcategory_id, brand_id, 
is_new_arrival, size, created_at) 
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");

$stmt->execute([
    $formData['name'],
    $formData['description'],
    $formData['price'],
    $formData['stock'],
    $imageName,
    $formData['category_id'],
    $formData['subcategory_id'],
    $brand_id,
    $formData['is_new_arrival'],
    $formData['size']
]);
                
                
                $db->commit();
                
                
                
                $_SESSION['success_message'] = "محصول با موفقیت اضافه شد";
                header("Location: add-product.php");
                exit;
                
            } catch (PDOException $e) {
                $db->rollBack();
                $error = "خطا در ذخیره محصول: " . $e->getMessage();
                
                // حذف تصویر آپلود شده در صورت خطا
                if (file_exists($targetPath)) {
                    unlink($targetPath);
                }
            }
        }
    }
}

?>


<!DOCTYPE html>
<html dir="rtl" lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>افزودن محصول جدید</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
    .attribute-field {
        background-color: #f8f9fa;
        padding: 10px;
        border-radius: 5px;
    }

    .form-container {
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        padding: 30px;
    }

    .form-label {
        font-weight: 600;
    }

    .preview-image {
        max-width: 200px;
        max-height: 200px;
        display: block;
        margin-top: 10px;
    }
    </style>
</head>
<script>
// بارگذاری اولیه اگر دسته‌بندی از قبل انتخاب شده
<?php if (!empty($formData['category_id'])): ?>
document.getElementById('category_id').dispatchEvent(new Event('change'));
<?php endif; ?>
</script>

<body>
    <div class="container py-4">
        <div class="row g-4">
            <!-- سایدبار -->
            <div class="col-md-4">
                <div class="card shadow-sm sticky-top" style="top: 20px;">
                    <div class="card-body p-0">
                        <div class="list-group list-group-flush rounded">
                            <a href="dashboard.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-speedometer2 me-2"></i> داشبورد
                            </a>
                            <a href="products/" class="list-group-item list-group-item-action active py-3"
                                style="background-color: #9c1e48 !important; border:none !important;">
                                <i class="bi bi-box-seam me-2"></i> محصولات
                            </a>
                            <a href="categories/" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-tags me-2"></i> دسته‌بندی‌ها
                            </a>
                            <a href="orders/" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-cart-check me-2"></i> سفارشات
                            </a>
                            <a href="users/" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-people me-2"></i> کاربران
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- محتوای اصلی -->
            <div class="col-md-8">
                <div class="form-container">
                    <h4 class="mb-4 p-style p-3 rounded text-white" style="background-color: #9c1e48;">افزودن محصول جدید
                    </h4>

                    <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
                    <?php endif; ?>

                    <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>

                    <form method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="name" class="form-label">نام محصول</label>
                            <input type="text" class="form-control" id="name" name="name" required
                                value="<?= htmlspecialchars($formData['name']) ?>">
                        </div>

                        <div class="mb-3">
                            <label for="description" class="form-label">توضیحات محصول</label>
                            <textarea class="form-control" id="description" name="description" rows="3"
                                required><?= htmlspecialchars($formData['description']) ?></textarea>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="price" class="form-label">قیمت (تومان)</label>
                                <input type="number" class="form-control" id="price" name="price" required
                                    value="<?= htmlspecialchars($formData['price']) ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="stock" class="form-label">موجودی</label>
                                <input type="number" class="form-control" id="stock" name="stock" required
                                    value="<?= htmlspecialchars($formData['stock']) ?>">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="category_id" class="form-label">دسته‌بندی <span
                                    class="text-danger">*</span></label>
                            <select class="form-select" id="category_id" name="category_id" required>
                                <option value="">انتخاب دسته‌بندی</option>
                                <?php foreach ($categories as $category): ?>
                                <option value="<?= $category['id'] ?>"
                                    <?= ($formData['category_id'] == $category['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($category['name']) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="subcategory_id" class="form-label">زیردسته‌بندی <span
                                    class="text-danger">*</span></label>
                            <select class="form-select" id="subcategory_id" name="subcategory_id" required>
                                <option value="">انتخاب زیردسته‌بندی</option>
                                <?php foreach ($subcategories as $subcategory): ?>
                                <option value="<?= $subcategory['id'] ?>"
                                    <?= ($formData['subcategory_id'] == $subcategory['id']) ? 'selected' : '' ?>
                                    data-category="<?= $subcategory['category_id'] ?>">
                                    <?= htmlspecialchars($subcategory['name']) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>





                        <div class="mb-3">
                            <label for="brand" class="form-label">برند <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="brand" name="brand" required
                                value="<?= htmlspecialchars($formData['brand']) ?>">
                            <small class="text-muted">نام برند را وارد کنید. اگر برند جدید باشد، به صورت خودکار
                                ایجاد
                                می‌شود.</small>
                        </div>

                        <div class="mb-3">
                            <label for="image" class="form-label">تصویر محصول</label>
                            <input type="file" class="form-control" id="image" name="image" accept="image/*" required>
                        </div>

                        <div class="row mb-3">


                            <div class="col-md-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="is_new_arrival"
                                        name="is_new_arrival" <?= $formData['is_new_arrival'] ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="is_new_arrival">محصول جدید</label>
                                </div>
                            </div>

                        </div>
                        <div class="mb-3">
                            <label for="size" class="form-label">سایز</label>
                            <input type="text" class="form-control" id="size" name="size"
                                value="<?= htmlspecialchars($formData['size'] ?? '') ?>">
                            <small class="text-muted">مثال: 55ml, 100ml, 250ml, etc.</small>
                        </div>
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="submit" name="submit" class="btn"
                                style="background-color: #9c1e48; color: white;">ذخیره محصول</button>
                            <a href="products/" class="btn btn-secondary">انصراف</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
    // اختیاری: فیلتر کردن زیردسته‌بندی‌ها بر اساس دسته‌بندی انتخاب شده
    document.getElementById('category_id').addEventListener('change', function() {
        const categoryId = this.value;
        const subcategorySelect = document.getElementById('subcategory_id');
        const options = subcategorySelect.querySelectorAll('option');

        options.forEach(option => {
            if (option.value === '') return; // گزینه اول را تغییر نده

            if (!categoryId || option.dataset.category === categoryId) {
                option.style.display = '';
                option.disabled = false;
            } else {
                option.style.display = 'none';
                option.disabled = true;
            }
        });
    });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>