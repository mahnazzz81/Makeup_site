<?php
require_once 'db.php';

header('Content-Type: text/html; charset=utf-8');

if (isset($_POST['category_id']) && !empty($_POST['category_id'])) {
    try {
        $stmt = $db->prepare("SELECT * FROM subcategories WHERE category_id = ?");
        $stmt->execute([$_POST['category_id']]);
        $subcategories = $stmt->fetchAll();
        
        $options = '<option value="">انتخاب زیردسته‌بندی</option>';
        foreach ($subcategories as $subcategory) {
            $options .= sprintf(
                '<option value="%s">%s</option>',
                $subcategory['id'],
                htmlspecialchars($subcategory['name'])
            );
        }
        echo $options;
    } catch (PDOException $e) {
        echo '<option value="">خطا در دریافت زیردسته‌بندی‌ها</option>';
    }
} else {
    echo '<option value="">ابتدا دسته‌بندی را انتخاب کنید</option>';
}
?>