<?php
session_start();
require_once 'db.php';

// بررسی لاگین بودن کاربر
if(!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user']['id'];

// دریافت سبد خرید فعلی کاربر
try {
    $cart_query = "SELECT c.*, p.name as product_name, p.image, p.description 
                   FROM cart c 
                   JOIN products p ON c.product_id = p.id 
                   WHERE c.user_id = ?";
    $cart_stmt = $db->prepare($cart_query);
    $cart_stmt->execute([$user_id]);
    $cart_items = $cart_stmt->fetchAll();
    
    // محاسبه جمع کل سبد خرید
    $cart_total = 0;
    foreach($cart_items as $item) {
        $cart_total += $item['price'] * $item['quantity'];
    }
} catch(PDOException $e) {
    die("خطا در دریافت سبد خرید: " . $e->getMessage());
}

// دریافت سفارشات کاربر
try {
    $orders_query = "SELECT o.*, 
                    (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.id) as item_count
                    FROM orders o 
                    WHERE o.user_id = ? 
                    ORDER BY o.created_at DESC";
    $orders_stmt = $db->prepare($orders_query);
    $orders_stmt->execute([$user_id]);
    $orders = $orders_stmt->fetchAll();
} catch(PDOException $e) {
    die("خطا در دریافت سفارشات: " . $e->getMessage());
}

// وضعیت‌های سفارش به فارسی
$status_labels = [
    'pending' => 'در انتظار پرداخت',
    'processing' => 'در حال پردازش',
    'completed' => 'تکمیل شده',
    'cancelled' => 'لغو شده'
];

$status_classes = [
    'pending' => 'bg-warning text-dark',
    'processing' => 'bg-info text-dark',
    'completed' => 'bg-success',
    'cancelled' => 'bg-danger'
];
?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سفارشات من</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
    .cart-item-img {
        width: 80px;
        height: 80px;
        object-fit: cover;
    }

    .order-card {
        border-left: 4px solid #ec5a8b;
        transition: all 0.3s;
    }

    .order-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    .status-badge {
        font-size: 0.85rem;
    }
    </style>
</head>

<body>
    <!-- هدر و نویگیشن مانند صفحات دیگر -->

    <div class="container py-5">
        <div class="row">
            <!-- سایدبار پروفایل -->
            <div class="col-md-3">
                <div class="card shadow-sm sticky-top" style="top: 20px;">
                    <div class="card-body p-0">
                        <div class="list-group list-group-flush rounded">
                            <a href="profile.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-person-fill me-2"></i> پروفایل
                            </a>
                            <a href="orders.php" class="list-group-item list-group-item-action active py-3"
                                style="background-color: #9c1e48; border:none !important;">
                                <i class="bi bi-cart-check me-2"></i> سفارشات
                            </a>
                            <a href="wallet.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-wallet-fill me-2"></i> کیف پول
                            </a>
                            <a href="addresses.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-geo-alt-fill me-2"></i>آدرس های من
                            </a>
                            <a href="support.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-headset me-2"></i> پشتیبانی
                            </a>
                            <a href="index.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-house me-2"></i>صفحه اصلی
                            </a>
                            <a href="logout.php" class="list-group-item list-group-item-action text-danger py-3">
                                <i class="bi bi-box-arrow-left me-2"></i> خروج
                            </a>


                        </div>
                    </div>
                </div>
            </div>

            <!-- محتوای اصلی -->
            <div class="col-md-9">
                <h4 class="mb-4 pt-3">سبد خرید فعلی</h4>

                <?php if(count($cart_items) > 0): ?>
                <div class="card mb-5">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table text-center">
                                <thead>
                                    <tr>
                                        <th class="text-end">محصول</th>
                                        <th class="text-center">قیمت</th>
                                        <th class="text-center">تعداد</th>
                                        <th class="text-center">جمع</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($cart_items as $item): ?>
                                    <tr>
                                        <td class="text-end">
                                            <div class="d-flex align-items-center">
                                                <img src="images/products/<?= htmlspecialchars($item['image'] ?? 'default.jpg') ?>"
                                                    class="cart-item-img me-3"
                                                    alt="<?= htmlspecialchars($item['product_name']) ?>">
                                                <div>
                                                    <h6 class="mb-1 text-start">
                                                        <?= htmlspecialchars($item['product_name']) ?></h6>
                                                    <small
                                                        class="text-muted"><?= htmlspecialchars(mb_substr($item['description'] ?? '', 0, 50)) ?>...</small>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="text-center align-middle"><?= number_format($item['price']) ?> تومان
                                        </td>
                                        <td class="text-center align-middle"><?= $item['quantity'] ?></td>
                                        <td class="text-center align-middle">
                                            <?= number_format($item['price'] * $item['quantity']) ?> تومان</td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="3" class="text-end fw-bold">جمع کل:</td>
                                        <td class="text-center fw-bold"><?= number_format($cart_total) ?> تومان</td>
                                    </tr>
                                </tfoot>
                            </table>
                            <div class="text-end mt-3">
                                <a href="cart.php" class="btn search-button">مدیریت سبد خرید</a>
                            </div>
                        </div>

                    </div>
                </div>
                <?php else: ?>
                <div class="alert alert-info">
                    سبد خرید شما خالی است. <a href="products.php" class="alert-link">مشاهده محصولات</a>
                </div>
                <?php endif; ?>

                <h4 class="mb-4">تاریخچه سفارشات</h4>

                <?php if(count($orders) > 0): ?>
                <?php foreach($orders as $order): ?>
                <div class="card order-card mb-3">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h5 class="mb-0">سفارش #<?= $order['id'] ?></h5>
                                <small class="text-muted">تاریخ:
                                    <?= date('Y/m/d H:i', strtotime($order['created_at'])) ?></small>
                            </div>
                            <div>
                                <span class="badge rounded-pill status-badge <?= $status_classes[$order['status']] ?>">
                                    <?= $status_labels[$order['status']] ?>
                                </span>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <p class="mb-1"><strong>تعداد آیتم:</strong> <?= $order['item_count'] ?></p>
                            </div>
                            <div class="col-md-4">
                                <p class="mb-1"><strong>مبلغ کل:</strong> <?= number_format($order['total_price']) ?>
                                    تومان</p>
                            </div>
                            <div class="col-md-4 text-start">
                                <a href="order_details.php?id=<?= $order['id'] ?>"
                                    class="btn btn-sm btn-outline-primary">
                                    مشاهده جزئیات سفارش
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php else: ?>
                <div class="alert alert-info">
                    هنوز هیچ سفارشی ثبت نکرده‌اید.
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>