<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>حریم خصوصی | بیوتی پینک</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
        font-family: 'Segoe UI', Tahoma, sans-serif;
        background: linear-gradient(to left, #ff85a2, #ffaccb);
    }

    .privacy-header {
        background: linear-gradient(to left, #ff85a2, #ffaccb);
        color: white;
    }

    h2 {
        color: #ff66b3;
        margin-top: 1.5rem;
    }
    </style>
</head>

<body>
    <div class="container py-4">
        <!-- هدر -->
        <header class="privacy-header p-4 mb-4 rounded text-center">
            <h1 class="mb-0">سیاست حریم خصوصی بیوتی پینک</h1>
        </header>

        <!-- محتوا -->
        <div class="bg-white p-4 rounded shadow-sm">
            <section class="mb-4">
                <h2 class="h4">۱. اطلاعات جمع‌آوری شده</h2>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">نام، ایمیل و شماره تماس</li>
                    <li class="list-group-item">آدرس تحویل سفارشات</li>
                    <li class="list-group-item">اطلاعات پرداخت (به صورت رمزنگاری شده)</li>
                </ul>
            </section>

            <section class="mb-4">
                <h2 class="h4">۲. نحوه استفاده از اطلاعات</h2>
                <p class="mb-2">• پردازش سفارشات و ارسال محصولات</p>
                <p class="mb-2">• بهبود خدمات و تجربه کاربری</p>
                <p>• ارسال پیام‌های مرتبط (در صورت عضویت در خبرنامه)</p>
            </section>

            <section class="mb-4">
                <h2 class="h4">۳. حفاظت از داده‌ها</h2>
                <div class="alert alert-info">
                    از پروتکل HTTPS و روش‌های امنیتی استاندارد استفاده می‌کنیم.
                </div>
            </section>

            <section class="mb-4">
                <h2 class="h4">۴. تغییرات در سیاست‌ها</h2>
                <p>در صورت بروزرسانی، آخرین نسخه در این صفحه منتشر خواهد شد.</p>
            </section>

            <section>
                <h2 class="h4">۵. تماس با ما</h2>
                <div class="d-flex align-items-center mb-2">
                    <span class="badge bg-secondary me-2">ایمیل:</span>
                    <span>info@beautypink.com</span>
                </div>
                <div class="d-flex align-items-center">
                    <span class="badge bg-secondary me-2">تلفن:</span>
                    <span>۰۲۱-۱۲۳۴۵۶۷۸</span>
                </div>
            </section>
        </div>

        <!-- فوتر -->
        <footer class="mt-4 p-3 bg-light text-center rounded">
            <p class="mb-0">© ۲۰۲۳ بیوتی پینک - تمام حقوق محفوظ است</p>
        </footer>
    </div>

    <!-- Bootstrap JS (اختیاری) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>