<?php

session_start(); // این خط را اضافه کنید
include 'db.php';

// افزایش بازدید فقط وقتی که ID محصول معتبر است
if(isset($_GET['id']) && is_numeric($_GET['id'])) {
    $product_id = intval($_GET['id']);
    
    // افزایش تعداد بازدیدها
    $update_query = "UPDATE products SET views = views + 1 WHERE id = ?";
    $stmt = $db->prepare($update_query);
    $stmt->execute([$product_id]);
}



// بررسی وضعیت لاگین کاربر
$is_logged_in = isset($_SESSION['user']);
$user = $is_logged_in ? $_SESSION['user'] : null;
$is_admin = $is_logged_in && ($user['role'] === 'admin');
$is_user = $is_logged_in && ($user['role'] === 'user');

if(!isset($_GET['id']) || !is_numeric($_GET['id'])) {
die("شناسه محصول نامعتبر است!");
}

$product_id = (int)$_GET['id'];

try {
$stmt = $db->prepare("SELECT * FROM products WHERE id = :id");
$stmt->bindParam(':id', $product_id, PDO::PARAM_INT);
$stmt->execute();

$product = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$product) {
die("محصول یافت نشد!");
}
} catch(PDOException $e) {
die("خطا در دریافت اطلاعات محصول: " . $e->getMessage());
}
// نمایش پیام موفقیت اگر محصول به سبد خرید اضافه شده باشد
if (isset($_SESSION['add_to_cart_success']) && $_SESSION['add_to_cart_success'] && isset($_SESSION['product_added']) &&
$_SESSION['product_added'] == $product_id) {
echo '<div class="alert alert-success alert-dismissible fade show text-center mb-4" role="alert"
    style="margin-top: 200px;">
    <i class="fas fa-check-circle me-2"></i>
    محصول با موفقیت به سبد خرید اضافه شد!
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';

// حذف پیام از session پس از نمایش
unset($_SESSION['add_to_cart_success']);
unset($_SESSION['product_added']);
}
?>


<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($product['name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style.css">
    <meta name="description" content="فروشگاه اینترنتی محصولات آرایشی و بهداشتی با بهترین قیمت‌ها">
    <meta name="keywords" content="آرایشی, بهداشتی, لوازم آرایش, عطر, ادکلن">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <title>فروشگاه آرایشی | خرید آنلاین محصولات آرایشی و بهداشتی</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <!-- فونت شبنم -->
    <link href="https://cdn.fontcdn.ir/Font/Persian/Shabnam/Shabnam.css" rel="stylesheet">
    <!-- پیش‌بارگذاری فونت‌ها -->
    <link rel="preload" href="font-url.woff2" as="font" type="font/woff2" crossorigin>
    <style>
    /* حداقل CSS سفارشی */


    .delivery-info {
        background-color: #fff3fd;
    }
    </style>
</head>

<body class="bg-light">
    <?php include 'includes/header.php'; ?>
    <nav class="navbar navbar-expand-lg main-header sticky-top">
        <div class="container" style="flex-wrap: nowrap;">
            <div class="d-flex align-items-center">
                <!-- آیکون همبرگر -->
                <button class="navbar-toggler " type="button" data-bs-toggle="offcanvas"
                    data-bs-target="#offcanvasNavbar">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <!-- لوگو -->
                <a class="navbar-brand mx-auto" href="index.php">
                    <img src="images/logo.jpg" alt="لوگو" width="129">
                </a>

                <!-- بخش جستجو (دسکتاپ) -->
                <form class="search-form-desktop d-none d-lg-flex" action="search.php" method="GET">
                    <input type="text" name="query" placeholder="جستجوی محصولات..." class="search-input form-control">
                    <button type="submit" class="search-button btn me-2" style="border:none;">
                        جستجو
                    </button>
                </form>
            </div>
            <!-- آیکون‌های سمت چپ -->
            <!-- آیکون‌های سمت چپ -->
            <div class="icons-left-container">

                <a href="cart.php" class="btn">
                    <i class="bi bi-cart3"></i>
                </a>


                <?php if(isset($_SESSION['user'])): ?>
                <!-- نمایش وقتی کاربر لاگین کرده -->
                <div class="dropdown">
                    <a class="btn dropdown-toggle d-flex align-items-center py-1 px-2 dropdown-toggle-no-caret"
                        href="profile.php" role="button" id="userDropdown" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        <i class="bi bi-person-fill-down"></i>

                    </a>
                    <ul class="dropdown-menu dropdown-menu-end border-0 shadow-xl text-end" style="max-width: 120px;"
                        aria-labelledby="userDropdown">
                        <li><a class="dropdown-item py-2 px-3" href="profile.php">پروفایل</a></li>

                        <li><a class="dropdown-item py-2 px-3" href="orders.php">سفارش‌ها</a></li>
                        <li><a class="dropdown-item py-2 px-3" href="wallet.php">کیف پول</a></li>
                        <li><a class="dropdown-item py-2 px-3" href="addresses.php">آدرس های من</a></li>
                        <li><a class="dropdown-item py-2 px-3" href="suppotr.php">پشتیبانی</a></li>
                        <li>
                            <hr class="dropdown-divider my-1">
                        </li>



                        <?php if($is_admin): ?> <li><a class="dropdown-item py-2 px-3 text-info"
                                href="dashboard.php">داشبورد مدیریت</a>
                        </li>
                        <?php endif; ?>
                        <li><a class="dropdown-item py-2 px-3 text-danger" href="logout.php">خروج</a>
                        </li>
                    </ul>
                </div>
                <?php else: ?>
                <!-- نمایش وقتی کاربر لاگین نکرده -->
                <a href="login.php" class="btn d-flex align-items-center submit-btn">
                    <span class="d-none d-md-inline">ورود</span>
                </a>
                <?php endif; ?>

                <a href="search.php" class="btn d-lg-none">
                    <i class="bi bi-search"></i>
                </a>
            </div>
        </div>
    </nav>
    <!-- منوی اصلی دسکتاپ -->
    <div class="main-navigation d-none d-lg-block">
        <div class="container">
            <ul class="nav justify-content-center">
                <!-- آیتم معمولی -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="index.php" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        برندها
                    </a>
                    <ul class="dropdown-menu bg-white">
                        <div class="layout-container">
                            <div class="container">
                                <div class="row text-end">
                                    <div class="col-md-4 flex-grow-1" style="max-height: 300px; overflow-y: auto;">
                                        <h6 class="dropdown-header text-info"> همه برند ها</h6>
                                        <?php
                        $brands = $db->query("SELECT id, name FROM brands ORDER BY name")->fetchAll();
                        foreach ($brands as $brand_item):
                        ?>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="brand.php?id=<?= $brand_item['id'] ?>">
                                            <?= htmlspecialchars($brand_item['name']) ?>
                                        </a>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        آرایشی
                    </a>
                    <ul class="dropdown-menu bg-white">
                        <div class="layout-container">
                            <div class="container">
                                <div class="row text-end">
                                    <div class="col-md-4">
                                        <h6 class="dropdown-header text-danger">آرایش صورت</h6>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=کرم پودر">کرم پودر</a>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=پنکک">پنکک</a>
                                        <a class="dropdown-item py-2" href="products.php?subcategory=رژ گونه">رژ
                                            گونه</a>
                                    </div>
                                    <div class="col-md-4">
                                        <h6 class="dropdown-header text-danger">آرایش چشم</h6>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=ریمل">ریمل</a>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=مداد و خط چشم">مداد و خط چشم
                                        </a>
                                        <a class="dropdown-item py-2" href="products.php?subcategory=سایه چشم">سایه
                                            چشم</a>
                                    </div>
                                    <div class=" col-md-4">
                                        <h6 class="dropdown-header text-danger">آرایش لب</h6>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=رژ لب">رژ لب</a>
                                        <a class=" dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=مداد و خط لب">مداد و خط لب</a>
                                        <a class=" dropdown-item py-2" href="products.php?subcategory=تینت لب">تینت
                                            لب</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        مراقبت پوست
                    </a>
                    <ul class="dropdown-menu bg-white">
                        <div class="layout-container">
                            <div class="container">
                                <div class="row text-end">
                                    <div class="col-md-4">
                                        <h6 class="dropdown-header text-danger">مراقبت صورت</h6>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=ضد آفتاب">ضد آفتاب</a>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=آبرسان و مرطوب کننده">آبرسان و مرطوب
                                            کننده</a>
                                        <a class="dropdown-item py-2" href="products.php?subcategory=ماسک صورت">ماسک
                                            صورت</a>
                                    </div>
                                    <div class="col-md-4">
                                        <h6 class="dropdown-header text-danger">پاک کننده و شوینده</h6>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=شوینده صورت">شوینده صورت</a>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=آرایش پاک کن ومیسلار واتر">آرایش پاک کن و
                                            میسلار واتر</a>
                                        <a class="dropdown-item py-2" href="products.php?subcategory=تونر">تونر</a>
                                    </div>
                                    <div class="col-md-4">
                                        <h6 class="dropdown-header text-danger">مراقبت بدن</h6>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=لوسیون بدن">لوسیون بدن</a>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=روشن کننده بدن">روشن کننده بدن</a>
                                        <a class="dropdown-item py-2" href="products.php?subcategory=اسکراب بدن">اسکراب
                                            بدن</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        مراقبت مو
                    </a>
                    <ul class="dropdown-menu bg-white">
                        <div class="layout-container">
                            <div class="container">
                                <div class="row text-end">
                                    <div class="col-md-4">
                                        <h6 class="dropdown-header text-danger">شامپو</h6>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory= شامپو موی معمولی ">شامپو موی معمولی</a>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory= شامپو موی چرب">شامپو موی چرب</a>
                                        <a class="dropdown-item py-2"
                                            href="products.php?subcategory=شامپو ضد شوره">شامپو ضد
                                            شوره</a>
                                    </div>
                                    <div class="col-md-4">
                                        <h6 class="dropdown-header text-danger">مراقبت از مو</h6>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=ماسک مو">ماسک مو</a>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=روغن مو">روغن مو</a>
                                        <a class="dropdown-item py-2" href="products.php?subcategory=نرم کننده مو">نرم
                                            کننده
                                            مو</a>
                                    </div>
                                    <div class="col-md-4">
                                        <h6 class="dropdown-header text-danger">زیبایی مو</h6>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=اسپری مو">اسپری مو</a>
                                        <a class="dropdown-item py-2" href="products.php?subcategory=ژل مو">ژل
                                            مو</a>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        عطر و اسپری
                    </a>
                    <ul class="dropdown-menu bg-white">
                        <div class="layout-container">
                            <div class="container">
                                <div class="row text-end">
                                    <div class="col-md-4">
                                        <h6 class="dropdown-header text-danger">عطر و ادکلن</h6>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=عطر زنانه">عطر زنانه</a>
                                        <a class="dropdown-item py-2" href="products.php?subcategory=عطر مردانه">عطر
                                            مردانه</a>
                                    </div>
                                    <div class="col-md-4">
                                        <h6 class="dropdown-header text-danger">اسپری</h6>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=اسپری زنانه">اسپری زنانه</a>
                                        <a class="dropdown-item py-2" href="products.php?subcategory=اسپری مردانه">اسپری
                                            مردانه</a>
                                    </div>
                                    <div class="col-md-4">
                                        <h6 class="dropdown-header text-danger">بادی اسپلش</h6>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=بادی اسپلش مردانه">بادی اسپلش مردانه</a>
                                        <a class="dropdown-item py-2"
                                            href="products.php?subcategory=بادی اسپلش زنانه">بادی
                                            اسپلش
                                            زنانه</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </ul>
                </li>

                <!-- آیتم دراپ‌داون مطابق تصویر شما -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        لوازم برقی
                    </a>
                    <ul class="dropdown-menu bg-white">
                        <div class="layout-container">
                            <div class="container">
                                <div class="row text-end">
                                    <div class="col-md-4">
                                        <h6 class="dropdown-header text-danger">ابزار برقی مو</h6>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=سشوار">سشوار</a>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=اتو مو صاف کننده">اتو مو صاف کننده</a>
                                        <a class=" dropdown-item py-2" href="products.php?subcategory=برس حرارتی">برس
                                            حرارتی</a>
                                    </div>
                                    <div class="col-md-4">
                                        <h6 class="dropdown-header text-danger">ابزار اصلاح</h6>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=ماشین اصلاح صورت">ماشین اصلاح صورت</a>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=ماشین اصلاح بدن و سر">ماشین اصلاح بدن و
                                            سر</a>
                                        <a class="dropdown-item py-2"
                                            href="products.php?subcategory=اپیلیدی و بند انداز برقی">اپیلیدی
                                            و
                                            بند
                                            انداز برقی</a>
                                    </div>
                                    <div class="col-md-4">
                                        <h6 class="dropdown-header text-danger">ابزار مراقبت پوست</h6>
                                        <a class="dropdown-item border-bottom py-2"
                                            href="products.php?subcategory=فیس براش">فیس براش</a>
                                        <a class="dropdown-item py-2"
                                            href="products.php?subcategory=دستگاه لیفت صورت">دستگاه لیفت
                                            صورت</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </ul>
                </li>

                <!-- بقیه آیتم‌های منو -->
            </ul>
        </div>

    </div>
    <!-- منوی Offcanvas -->
    <div class="offcanvas offcanvas-end offcanvas-custom" tabindex="-1" id="offcanvasNavbar">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title">منوی فروشگاه</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
        </div>
        <div class="offcanvas-body">
            <!-- منوی موبایل -->
            <ul class="navbar-nav mobile-menu">
                <!-- برندها -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown">
                        برندها
                    </a>
                    <ul class="dropdown-menu w-75">
                        <?php foreach ($brands as $brand_item): ?>
                        <li><a class="dropdown-item" href="brand.php?id=<?= $brand_item['id'] ?>">
                                <?= htmlspecialchars($brand_item['name']) ?>
                            </a></li>
                        <?php endforeach; ?>
                    </ul>
                </li>

                <!-- آرایشی -->
                <li class="nav-item dropdown w-75">
                    <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown">
                        آرایشی
                    </a>
                    <ul class="dropdown-menu w-75">
                        <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#">آرایش صورت</a>
                            <ul class="dropdown-menu w-75">
                                <li><a class="dropdown-item" href="products.php?subcategory=کرم پودر">کرم پودر</a>
                                </li>
                                <li><a class="dropdown-item" href="products.php?subcategory=پنکک">پنکک</a></li>
                                <li><a class="dropdown-item" href="products.php?subcategory=رژ گونه">رژ گونه</a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#">آرایش چشم</a>
                            <ul class="dropdown-menu w-75">
                                <li><a class="dropdown-item" href="products.php?subcategory=ریمل">ریمل</a></li>
                                <li><a class="dropdown-item" href="products.php?subcategory=مداد و خط چشم">مداد و خط
                                        چشم</a></li>
                                <li><a class="dropdown-item" href="products.php?subcategory=سایه چشم">سایه چشم</a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#">آرایش لب</a>
                            <ul class="dropdown-menu w-75">
                                <li><a class="dropdown-item" href="products.php?subcategory=رژ لب">رژ لب</a></li>
                                <li><a class="dropdown-item" href="products.php?subcategory=مداد و خط لب">مداد و خط
                                        لب</a></li>
                                <li><a class="dropdown-item" href="products.php?subcategory=تینت لب">تینت لب</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropdown w-75">
                    <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown">
                        مراقبت پوست
                    </a>
                    <ul class="dropdown-menu w-75">
                        <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#">مراقبت صورت</a>
                            <ul class="dropdown-menu w-75">
                                <li><a class="dropdown-item" href="products.php?subcategory=ضد آفتاب ">ضد آفتاب </a>
                                </li>
                                <li><a class="dropdown-item" href="products.php?subcategory=آبرسان و مرطوب کننده">آبرسان
                                        و
                                        مرطوب
                                        کننده</a></li>
                                <li><a class="dropdown-item" href="products.php?subcategory=ماسک صورت ">ماسک
                                        صورت</a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#">پاک کننده و شوینده </a>
                            <ul class="dropdown-menu w-75">
                                <li><a class="dropdown-item" href="products.php?subcategory=ریمل">شوینده صورت</a>
                                </li>
                                <li><a class="dropdown-item"
                                        href="products.php?subcategory= آرایش پاک کن و میسلار واتر">آرایش پاک
                                        کن و میسلار واتر
                                    </a></li>
                                <li><a class="dropdown-item" href="products.php?subcategory=تونر "> تونر</a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#">مراقبت بدن </a>
                            <ul class="dropdown-menu w-75">
                                <li><a class="dropdown-item" href="products.php?subcategory=لوسیون بدن"> لوسیون
                                        بدن </a>
                                </li>
                                <li><a class="dropdown-item" href="products.php?subcategory=روشن کننده بدن"> روشن
                                        کننده بدن
                                    </a></li>
                                <li><a class="dropdown-item" href="products.php?subcategory=اسکراب بدن ">اسکراب بدن
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropdown w-75">
                    <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown">
                        مراقبت مو
                    </a>
                    <ul class="dropdown-menu w-75">
                        <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#">شامپو</a>
                            <ul class="dropdown-menu w-75">
                                <li><a class="dropdown-item" href="products.php?subcategory=شامپو موی معمولی">شامپو
                                        موی معمولی</a></li>
                                <li><a class="dropdown-item" href="products.php?subcategory=شامپو موی چرب">شامپو موی
                                        چرب</a></li>
                                <li><a class="dropdown-item" href="products.php?subcategory=شامپو ضد شوره">شامپو ضد
                                        شوره</a></li>
                            </ul>
                        </li>
                        <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#">مراقبت از مو</a>
                            <ul class="dropdown-menu w-75">
                                <li><a class="dropdown-item" href="products.php?subcategory=ماسک مو">ماسک مو</a>
                                </li>
                                <li><a class="dropdown-item" href="products.php?subcategory=روغن مو">روغن مو</a>
                                </li>
                                <li><a class="dropdown-item" href="products.php?subcategory=نرم کننده مو">نرم کننده
                                        مو</a></li>
                            </ul>
                        </li>
                        <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#">زیبایی مو</a>
                            <ul class="dropdown-menu w-75">
                                <li><a class="dropdown-item" href="products.php?subcategory=اسپری مو">اسپری مو</a>
                                </li>
                                <li><a class="dropdown-item" href="products.php?subcategory=ژل مو">ژل مو</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropdown w-75">
                    <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown">
                        عطر و اسپری
                    </a>
                    <ul class="dropdown-menu w-75">
                        <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#">عطر و ادکلن</a>
                            <ul class="dropdown-menu w-75">
                                <li><a class="dropdown-item" href="products.php?subcategory=عطر زنانه">عطر زنانه</a>
                                </li>
                                <li><a class="dropdown-item" href="products.php?subcategory=عطر مردانه">عطر
                                        مردانه</a></li>
                            </ul>
                        </li>
                        <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#">اسپری</a>
                            <ul class="dropdown-menu w-75">
                                <li><a class="dropdown-item" href="products.php?subcategory=اسپری زنانه">اسپری
                                        زنانه</a></li>
                                <li><a class="dropdown-item" href="products.php?subcategory=اسپری مردانه">اسپری
                                        مردانه</a></li>
                            </ul>
                        </li>
                        <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#">بادی اسپلش</a>
                            <ul class="dropdown-menu w-75">
                                <li><a class="dropdown-item" href="products.php?subcategory=بادی اسپلش مردانه">بادی
                                        اسپلش مردانه</a></li>
                                <li><a class="dropdown-item" href="products.php?subcategory=بادی اسپلش زنانه">بادی
                                        اسپلش زنانه</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropdown w-75">
                    <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown">
                        لوازم برقی
                    </a>
                    <ul class="dropdown-menu w-75">
                        <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#">ابزار برقی مو</a>
                            <ul class="dropdown-menu w-75">
                                <li><a class="dropdown-item" href="products.php?subcategory=سشوار">سشوار</a></li>
                                <li><a class="dropdown-item" href="products.php?subcategory=اتو مو صاف کننده">اتو مو
                                        صاف کننده</a></li>
                                <li><a class="dropdown-item" href="products.php?subcategory=برس حرارتی">برس
                                        حرارتی</a></li>
                            </ul>
                        </li>
                        <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#">ابزار اصلاح</a>
                            <ul class="dropdown-menu w-75">
                                <li><a class="dropdown-item" href="products.php?subcategory=ماشین اصلاح صورت">ماشین
                                        اصلاح صورت</a></li>
                                <li><a class="dropdown-item" href="products.php?subcategory=ماشین اصلاح بدن و سر">ماشین
                                        اصلاح بدن و
                                        سر</a></li>
                                <li><a class="dropdown-item"
                                        href="products.php?subcategory=اپیلیدی و بند انداز برقی">اپیلیدی و بند انداز
                                        برقی</a></li>
                            </ul>
                        </li>
                        <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#">ابزار مراقبت پوست</a>
                            <ul class="dropdown-menu w-75">
                                <li><a class="dropdown-item" href="products.php?subcategory=فیس براش">فیس براش</a>
                                </li>
                                <li><a class="dropdown-item" href="products.php?subcategory=دستگاه لیفت صورت">دستگاه
                                        لیفت صورت</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>

                <!-- بقیه آیتم‌های منو به همین شکل -->
            </ul>
        </div>

    </div>


    <style>
    /* استایل‌های سفارشی برای منوی موبایل */
    ul li {
        direction: rtl !important;
        text-align: right !important;
    }

    .mobile-menu {
        direction: rtl !important;
        text-align: right !important;
        unicode-bidi: bidi-override !important;
    }

    .mobile-menu .dropdown-menu {
        background-color: #f8f9fa;
        border: none;
        box-shadow: none;

    }

    .mobile-menu .dropdown-submenu {
        position: relative;

    }

    .mobile-menu .dropdown-submenu .dropdown-menu {
        top: 0;
        right: 100%;
        margin-top: -6px;
        margin-right: .125rem;
        border-right: 2px solid #dc3545;

    }

    .mobile-menu .dropdown-item {
        padding: 0.5rem 1.5rem;
        color: #333;
    }

    .mobile-menu .dropdown-item:hover {
        background-color: #e9ecef;
        color: #dc3545;
    }

    .mobile-menu .dropdown-toggle::after {
        float: left;
        margin-top: 0.5em;
    }

    /* خط قرمز عمودی برای زیرمنوها */
    .dropdown-submenu>.dropdown-menu {
        border-right: 2px solid #dc3545;
        margin-right: 10px;
    }
    </style>
    <script>
    // فعال‌سازی منوی آبشاری
    document.querySelectorAll('.dropdown-submenu .dropdown-toggle').forEach(function(element) {
        element.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var submenu = this.nextElementSibling;
            submenu.style.display = submenu.style.display === 'block' ? 'none' : 'block';
        });
    });

    // بستن منوی آبشاری هنگام کلیک خارج از آن
    document.addEventListener('click', function() {
        document.querySelectorAll('.dropdown-submenu .dropdown-menu').forEach(function(element) {
            element.style.display = 'none';
        });
    });
    </script>
    <div class="container py-4">
        <div class="card shadow-sm">
            <div class="card-body">
                <div class="row justify-content-between">
                    <div class="col-md-5 mb-4 mb-md-0 card">
                        <img src="images/products/<?= htmlspecialchars($product['image']) ?>" class="img-fluid rounded"
                            alt="<?= htmlspecialchars($product['name']) ?>">
                    </div>
                    <div class="col-md-7 mt-4">
                        <div class="card border-0 shadow-sm mb-4 delivery-info">
                            <div class="card-body">
                                <h2 class="h4 fw-bold mb-2"><?= htmlspecialchars($product['name']) ?></h2>
                                <p class="text-muted small mb-3"><?= htmlspecialchars($product['subtitle'] ?? '') ?></p>

                                <div class="d-flex align-items-center mb-3">
                                    <div class="h3 text-danger me-3">
                                        <?= number_format($product['price']) ?> تومان
                                    </div>
                                    <?php if(isset($product['old_price']) && $product['old_price'] > $product['price']): ?>
                                    <div class="text-muted text-decoration-line-through">
                                        <?= number_format($product['old_price']) ?> تومان
                                    </div>
                                    <?php endif; ?>
                                </div>

                                <div class="bg-light p-3 rounded mb-4">
                                    <div class="mb-2">
                                        <i class="fas fa-shield-alt text-success me-2"></i>
                                        <span>ضمانت اصالت و سلامت کالا</span>
                                    </div>
                                    <div class="mb-2">
                                        <i class="fas fa-undo text-success me-2"></i>
                                        <span>بازگشت کالا تا 7 روز طبق شرایط مرجوعی</span>
                                    </div>
                                    <div>
                                        <i class="fas fa-truck text-success me-2"></i>
                                        <span>ارسال رایگان با خرید بیش از 2 میلیون تومان</span>
                                    </div>
                                </div>

                                <div class="bg-light p-3 rounded mb-4">
                                    <div class="mb-2">
                                        <i class="fas fa-truck text-secondary me-2"></i>
                                        <span>ارسال از 1 روز دیگر</span>
                                    </div>
                                    <div>
                                        <i class="fas fa-box text-secondary me-2"></i>
                                        <span>سایز: <?= htmlspecialchars($product['size'] ?? 'نامشخص') ?></span>
                                    </div>
                                </div>



                                <form method="POST" action="add-to-cart.php">
                                    <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                    <button type="submit" name="add_to_cart" class="btn btn-lg w-100 py-3 text-white"
                                        style="background: #ec5a8bb5 !important;">
                                        <i class="fas fa-shopping-cart me-2"></i> افزودن به سبد خرید
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>



                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm mt-4 container mb-4">
        <div class="card-body">
            <h3 class="h5 fw-bold mb-3">معرفی محصول</h3>
            <div class="mb-4"><?= nl2br(htmlspecialchars($product['description'])) ?></div>
        </div>
    </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="script.js"></script>
</body>

</html>