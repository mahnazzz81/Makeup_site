<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "makeup_site";

// ایجاد اتصال
$conn = new mysqli($servername, $username, $password, $dbname);

// بررسی اتصال
if ($conn->connect_error) {
    die("اتصال به پایگاه داده ناموفق بود: " . $conn->connect_error);
}

// دریافت عبارت جستجو
$query = isset($_GET['query']) ? trim($_GET['query']) : '';

// شروع HTML
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نتایج جستجو برای "<?= htmlspecialchars($query) ?>"</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
    .product-card {
        transition: transform 0.3s ease;
        margin-bottom: 20px;
    }

    .product-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    }

    .search-header {
        background-color: #f8f9fa;
        padding: 30px 0;
        margin-bottom: 30px;
    }

    .no-results {
        min-height: 300px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
    }
    </style>
</head>

<body class="bg-light">
    <?php include 'includes/header.php'; ?>

    <div class="search-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1 class="h3">نتایج جستجو برای "<?= htmlspecialchars($query) ?>"</h1>
                    <form class="mt-4" action="search.php" method="GET">
                        <div class="input-group">
                            <input type="text" name="query"
                                class="form-control form-control-lg search-input rounded-3 ms-2"
                                placeholder="جستجوی محصولات..." value="<?= htmlspecialchars($query) ?>">
                            <button class="btn search-button" type="submit">
                                <i class="fas fa-search"></i> جستجو
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="container mb-5">
        <div class="row">
            <?php
            if (!empty($query)) {
                // جستجو در پایگاه داده
                $sql = "SELECT * FROM products WHERE name LIKE '%$query%' OR description LIKE '%$query%'";
                $result = $conn->query($sql);

                // نمایش نتایج
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo '
                        <div class="col-md-4 col-sm-6">
                            <div class="card product-card h-100">
                                <a href="product-detail.php?id='.$row["id"].'">
                                    <img src="images/products/'.$row["image"].'" class="card-img-top p-3" alt="'.$row["name"].'">
                                </a>
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <a href="product-detail.php?id='.$row["id"].'" class="text-decoration-none text-dark">'.$row["name"].'</a>
                                    </h5>
                                    <p class="card-text text-muted small">'.substr($row["description"], 0, 100).'...</p>
                                </div>
                                <div class="card-footer bg-transparent">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="h5 text-success">'.number_format($row["price"]).' تومان</span>
                                        <a href="product-detail.php?id='.$row["id"].'" class="btn btn-sm search-button">
                                            <i class="fas fa-shopping-cart"></i> خرید
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>';
                    }
                } else {
                    echo '
                    <div class="col-12">
                        <div class="no-results text-center py-5">
                            <i class="fas fa-search fa-3x text-muted mb-3"></i>
                            <h3 class="h4">محصولی یافت نشد</h3>
                            <p class="text-muted">متاسفانه هیچ محصولی با عبارت "'.htmlspecialchars($query).'" یافت نشد.</p>
                            <a href="products.php" class="btn btn-danger mt-3">مشاهده همه محصولات</a>
                        </div>
                    </div>';
                }
            } else {
                echo '
                <div class="col-12">
                    <div class="no-results text-center py-5">
                        <i class="fas fa-search fa-3x text-muted mb-3"></i>
                        <h3 class="h4">لطفا عبارت جستجو را وارد کنید</h3>
                        <p class="text-muted">برای یافتن محصول مورد نظر، نام یا توضیحات آن را در کادر جستجو وارد کنید.</p>
                    </div>
                </div>';
            }
            ?>
        </div>
        <a href="index.php" class="btn search-button mt-5">
            <i class="fas fa-home me-2"></i> بازگشت به صفحه اصلی
        </a>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php
// بستن اتصال
$conn->close();
?>