<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مشاوره آرایشی تخصصی | بیوتی پینک</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
    .bg-pink {
        background: linear-gradient(to left, #ff85a2, #ffaccb);
    }

    .text-pink {
        color: #e43c74;

    }

    .consultation-card {
        transition: all 0.3s ease;
        border: none;
    }

    .consultation-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    }

    .expert-img {
        width: 100px;
        height: 100px;
        object-fit: cover;
    }

    .form-control:focus {
        border-color: #ff66b3;
        box-shadow: 0 0 0 0.25rem rgba(255, 102, 179, 0.25);
    }
    </style>
</head>

<body>
    <!-- هدر -->
    <header class="bg-pink text-white py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="display-4 fw-bold mb-3"><i class="bi bi-chat-square-text"></i> مشاوره آرایشی تخصصی</h1>
                    <p class="lead mb-4">با مشاوران حرفه‌ای ما برای انتخاب بهترین محصولات و سبک آرایش مشورت کنید</p>
                    <div class="d-flex flex-wrap gap-2">
                        <span class="badge bg-light text-pink p-2">پوست چرب</span>
                        <span class="badge bg-light text-pink p-2">پوست خشک</span>
                        <span class="badge bg-light text-pink p-2">آرایش عروس</span>
                        <span class="badge bg-light text-pink p-2">آرایش روزانه</span>
                    </div>
                </div>

            </div>
        </div>
    </header>

    <!-- بخش اصلی -->
    <div class="container py-5">
        <!-- مشاوران متخصص -->
        <section class="mb-5">
            <h2 class="text-center text-pink mb-5"><i class="bi bi-people"></i> مشاوران متخصص ما</h2>
            <div class="row g-4">
                <!-- مشاور 1 -->
                <div class="col-md-4">
                    <div class="card consultation-card shadow-sm h-100">
                        <div class="card-body text-center">

                            <h3 class="h5">نیلوفر محمدی</h3>
                            <p class="text-muted small">متخصص آرایش عروس و مراسم</p>
                            <div class="d-flex justify-content-center gap-2 mb-3">
                                <span class="badge bg-pink">کنتورینگ</span>
                                <span class="badge bg-pink">آرایش چشم</span>
                            </div>
                            <p class="card-text">۱۵ سال سابقه در آرایش حرفه‌ای و آموزش در آکادمی‌های معتبر</p>
                            <a href="#" class="btn btn-pink w-100">درخواست مشاوره</a>
                        </div>
                    </div>
                </div>

                <!-- مشاور 2 -->
                <div class="col-md-4">
                    <div class="card consultation-card shadow-sm h-100">
                        <div class="card-body text-center">

                            <h3 class="h5">سارا احمدی</h3>
                            <p class="text-muted small">متخصص مراقبت پوست و آرایش روزانه</p>
                            <div class="d-flex justify-content-center gap-2 mb-3">
                                <span class="badge bg-pink">پوست چرب</span>
                                <span class="badge bg-pink">آرایش طبیعی</span>
                            </div>
                            <p class="card-text">تخصص در انتخاب محصولات مناسب برای انواع پوست و آموزش تکنیک‌های ساده</p>
                            <a href="#" class="btn btn-pink w-100">درخواست مشاوره</a>
                        </div>
                    </div>
                </div>

                <!-- مشاور 3 -->
                <div class="col-md-4">
                    <div class="card consultation-card shadow-sm h-100">
                        <div class="card-body text-center">

                            <h3 class="h5">مریم رضایی</h3>
                            <p class="text-muted small">متخصص رنگ‌شناسی و استایل</p>
                            <div class="d-flex justify-content-center gap-2 mb-3">
                                <span class="badge bg-pink">رنگ‌شناسی</span>
                                <span class="badge bg-pink">استایلینگ</span>
                            </div>
                            <p class="card-text">مشاوره تخصصی برای انتخاب بهترین رنگ‌ها متناسب با پوست و فرم صورت</p>
                            <a href="#" class="btn btn-pink w-100">درخواست مشاوره</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- فرم مشاوره -->
        <section class="mb-5">
            <div class="row">
                <div class="col-lg-6">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-pink text-white">
                            <h3 class="h5 mb-0"><i class="bi bi-pencil-square"></i> فرم درخواست مشاوره</h3>
                        </div>
                        <div class="card-body">
                            <form>
                                <div class="mb-3">
                                    <label for="name" class="form-label">نام کامل</label>
                                    <input type="text" class="form-control" id="name" required>
                                </div>
                                <div class="mb-3">
                                    <label for="phone" class="form-label">شماره تماس</label>
                                    <input type="tel" class="form-control" id="phone" required>
                                </div>
                                <div class="mb-3">
                                    <label for="email" class="form-label">ایمیل</label>
                                    <input type="email" class="form-control" id="email">
                                </div>
                                <div class="mb-3">
                                    <label for="consultant" class="form-label">انتخاب مشاور</label>
                                    <select class="form-select" id="consultant">
                                        <option selected>-- لطفا انتخاب کنید --</option>
                                        <option value="1">نیلوفر محمدی - آرایش عروس</option>
                                        <option value="2">سارا احمدی - مراقبت پوست</option>
                                        <option value="3">مریم رضایی - رنگ‌شناسی</option>
                                        <option value="4">مشاور عمومی</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="subject" class="form-label">موضوع مشاوره</label>
                                    <select class="form-select" id="subject">
                                        <option selected>-- لطفا انتخاب کنید --</option>
                                        <option>انتخاب محصولات پوستی</option>
                                        <option>آرایش روزانه</option>
                                        <option>آرایش عروس</option>
                                        <option>رنگ‌شناسی و استایل</option>
                                        <option>سایر موارد</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="details" class="form-label">توضیحات بیشتر</label>
                                    <textarea class="form-control" id="details" rows="3"></textarea>
                                </div>
                                <button type="submit" class="btn btn-pink w-100">ارسال درخواست</button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 mt-4 mt-lg-0">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-pink text-white">
                            <h3 class="h5 mb-0"><i class="bi bi-info-circle"></i> نحوه دریافت مشاوره</h3>
                        </div>
                        <div class="card-body">
                            <div class="d-flex mb-4">
                                <div class="flex-shrink-0">
                                    <div class="bg-pink text-white rounded-circle d-flex align-items-center justify-content-center"
                                        style="width: 40px; height: 40px;">1</div>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h4 class="h6">تکمیل فرم درخواست</h4>
                                    <p class="small text-muted">فرم سمت چپ را با دقت تکمیل کنید تا مشاوران ما اطلاعات
                                        کافی داشته باشند.</p>
                                </div>
                            </div>

                            <div class="d-flex mb-4">
                                <div class="flex-shrink-0">
                                    <div class="bg-pink text-white rounded-circle d-flex align-items-center justify-content-center"
                                        style="width: 40px; height: 40px;">2</div>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h4 class="h6">بررسی توسط تیم ما</h4>
                                    <p class="small text-muted">درخواست شما حداکثر طی ۲۴ ساعت کاری بررسی و مشاور مناسب
                                        انتخاب می‌شود.</p>
                                </div>
                            </div>

                            <div class="d-flex mb-4">
                                <div class="flex-shrink-0">
                                    <div class="bg-pink text-white rounded-circle d-flex align-items-center justify-content-center"
                                        style="width: 40px; height: 40px;">3</div>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h4 class="h6">تماس مشاور</h4>
                                    <p class="small text-muted">مشاور متخصص در زمان توافق شده با شما تماس خواهد گرفت.
                                    </p>
                                </div>
                            </div>

                            <div class="d-flex">
                                <div class="flex-shrink-0">
                                    <div class="bg-pink text-white rounded-circle d-flex align-items-center justify-content-center"
                                        style="width: 40px; height: 40px;">4</div>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h4 class="h6">پشتیبانی پس از مشاوره</h4>
                                    <p class="small text-muted">در صورت نیاز می‌توانید برای پیگیری بیشتر با پشتیبانی
                                        تماس بگیرید.</p>
                                </div>
                            </div>

                            <hr class="my-4">

                            <div class="alert alert-info">
                                <h4 class="h6"><i class="bi bi-clock-history"></i> ساعت پاسخگویی</h4>
                                <p class="small mb-1">شنبه تا چهارشنبه: ۹ صبح تا ۵ عصر</p>
                                <p class="small mb-0">پنجشنبه: ۹ صبح تا ۱ ظهر</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- سوالات متداول -->
        <section>
            <h2 class="text-center text-pink mb-5"><i class="bi bi-question-circle"></i> سوالات متداول</h2>
            <div class="accordion" id="faqAccordion">
                <div class="accordion-item">
                    <h3 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#faq1">
                            هزینه مشاوره چقدر است؟
                        </button>
                    </h3>
                    <div id="faq1" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            مشاوره اولیه به صورت رایگان ارائه می‌شود. برای جلسات تخصصی و طولانی‌تر ممکن است هزینه‌ای
                            دریافت شود که از قبل به شما اطلاع داده خواهد شد.
                        </div>
                    </div>
                </div>

                <div class="accordion-item">
                    <h3 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#faq2">
                            آیا مشاوره به صورت آنلاین هم امکان‌پذیر است؟
                        </button>
                    </h3>
                    <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            بله، می‌توانید نوع مشاوره (تلفنی، ویدئوکال یا حضوری) را در فرم درخواست مشخص کنید. مشاوره
                            آنلاین از طریق پلتفرم‌های ایمن انجام می‌شود.
                        </div>
                    </div>
                </div>

                <div class="accordion-item">
                    <h3 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#faq3">
                            آیا مشاوران ما محصولات خاصی را تبلیغ می‌کنند؟
                        </button>
                    </h3>
                    <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            خیر، مشاوران ما بر اساس نیازهای شما و ویژگی‌های پوست/صورتتان، بهترین پیشنهادها را ارائه
                            می‌دهند و وابسته به هیچ برند خاصی نیستند.
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- فوتر -->
    <footer class="bg-pink text-white py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <h5 class="text-pink">بیوتی پینک</h5>
                    <p class="small text-white-50">ارائه بهترین مشاوره‌های آرایشی و زیبایی توسط متخصصان با تجربه</p>
                </div>
                <div class="col-md-4 mb-3">
                    <h5 class="text-pink">تماس با ما</h5>
                    <ul class="list-unstyled small text-white-50">
                        <li><i class="bi bi-telephone me-2"></i> ۰۲۱-۱۲۳۴۵۶۷۸</li>
                        <li><i class="bi bi-envelope me-2"></i> consult@beautypink.com</li>
                        <li><i class="bi bi-geo-alt me-2"></i> تهران، خیابان نمونه، پلاک ۱۲۳</li>
                    </ul>
                </div>
                <div class="col-md-4 mb-3">
                    <h5 class="text-pink">پیوندهای سریع</h5>
                    <div class="d-flex flex-wrap gap-2">
                        <a href="#" class="btn btn-sm btn-outline-light">صفحه اصلی</a>
                        <a href="#" class="btn btn-sm btn-outline-light">محصولات</a>
                        <a href="#" class="btn btn-sm btn-outline-light">وبلاگ</a>
                        <a href="#" class="btn btn-sm btn-outline-light">درباره ما</a>
                    </div>
                </div>
            </div>
            <hr class="my-3 bg-secondary">
            <div class="text-center small text-muted">
                © ۱۴۰۲ کلیه حقوق برای بیوتی پینک محفوظ است.
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>