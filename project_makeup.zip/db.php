<?php
// config/database.php
$host = 'localhost';
$dbname = 'makeup_site';
$username = 'root';
$password = '';



try {
    $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("اتصال به پایگاه داده ناموفق بود: " . $e->getMessage());
}
function normalize_phone($phone) {
    // حذف همه کاراکترهای غیرعددی
    $phone = preg_replace('/[^0-9]/', '', $phone);
    
    // اگر با 9 شروع می‌شود (مثلا 9123456789)
    if(preg_match('/^9/', $phone)) {
        return '0' . $phone;
    }
    
    // اگر با 989 شروع می‌شود (مثلا 989123456789+)
    if(preg_match('/^989/', $phone)) {
        return '0' . substr($phone, 2);
    }
    
    return $phone;
}