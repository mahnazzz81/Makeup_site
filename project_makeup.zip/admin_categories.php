<?php
session_start();
require_once 'db.php';

// بررسی آیا کاربر مدیر است یا نه
if(!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header('Location: login.php');
    exit;
}

// عملیات حذف
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    try {
        // بررسی وجود محصولات در این دسته‌بندی
        $check = $db->prepare("SELECT COUNT(*) FROM products WHERE category_id = ?");
        $check->execute([$id]);
        $product_count = $check->fetchColumn();
        
        if($product_count > 0) {
            $_SESSION['error'] = "امکان حذف این دسته‌بندی وجود ندارد زیرا دارای محصول است";
        } else {
            $stmt = $db->prepare("DELETE FROM categories WHERE id = ?");
            $stmt->execute([$id]);
            $_SESSION['success'] = "دسته‌بندی با موفقیت حذف شد";
        }
    } catch(PDOException $e) {
        $_SESSION['error'] = "خطا در حذف دسته‌بندی: " . $e->getMessage();
    }
    header('Location: admin_categories.php');
    exit;
}

// عملیات افزودن یا ویرایش
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'] ?? null;
    $name = trim($_POST['name']);
    
    try {
        if(empty($id)) {
            // افزودن جدید
            $stmt = $db->prepare("INSERT INTO categories (name) VALUES (?)");
            $stmt->execute([$name]);
            $_SESSION['success'] = "دسته‌بندی جدید با موفقیت اضافه شد";
        } else {
            // ویرایش
            $stmt = $db->prepare("UPDATE categories SET name = ? WHERE id = ?");
            $stmt->execute([$name, $id]);
            $_SESSION['success'] = "دسته‌بندی با موفقیت ویرایش شد";
        }
    } catch(PDOException $e) {
        $_SESSION['error'] = "خطا در ذخیره اطلاعات: " . $e->getMessage();
    }
    header('Location: admin_categories.php');
    exit;
}

// دریافت اطلاعات برای ویرایش
$edit_category = null;
if(isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $stmt = $db->prepare("SELECT * FROM categories WHERE id = ?");
    $stmt->execute([$id]);
    $edit_category = $stmt->fetch();
}

// دریافت تمام دسته‌بندی‌ها
$categories = $db->query("SELECT c.*, 
                          (SELECT COUNT(*) FROM products WHERE category_id = c.id) as product_count
                          FROM categories c 
                          ORDER BY name")->fetchAll();
?>

<!DOCTYPE html>
<html dir="rtl" lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت دسته‌بندی‌ها</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
    .category-card {
        transition: all 0.3s;
        border-left: 4px solid #9c1e48;
    }

    .category-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .product-count-badge {
        background-color: #e62a68;
        color: white;
    }

    .form-section {
        background-color: #f8f9fa;
        border-radius: 8px;
        padding: 20px;
        margin-bottom: 20px;
    }
    </style>
</head>

<body>
    <div class="container py-4">
        <div class="row g-4">
            <!-- سایدبار -->
            <div class="col-md-3">
                <div class="card shadow-sm sticky-top" style="top: 20px;">
                    <div class="card-body p-0">
                        <!-- منوی اصلی -->
                        <div class="list-group list-group-flush rounded">
                            <a href="dashboard.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-speedometer2 me-2"></i> داشبورد
                            </a>
                            <a href="admin_products.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-box-seam me-2"></i> محصولات
                            </a>
                            <a href="admin_categories.php" class="list-group-item list-group-item-action active py-3"
                                style="background-color: #9c1e48 !important; border:none !important;">
                                <i class="bi bi-tags me-2"></i> دسته‌بندی‌ها
                            </a>
                            <a href="admin_subcategories.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-tag me-2"></i> زیردسته‌بندی‌ها
                            </a>
                            <a href="admin_orders.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-cart-check me-2"></i> سفارشات
                            </a>
                            <a href="admin_users.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-people me-2"></i> کاربران
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- محتوای اصلی -->
            <div class="col-md-9">
                <!-- پیام‌های سیستم -->
                <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-danger"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
                <?php endif; ?>

                <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
                <?php endif; ?>

                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="mb-0">مدیریت دسته‌بندی‌ها</h4>
                </div>

                <!-- فرم افزودن/ویرایش دسته‌بندی -->
                <div class="card shadow-sm mb-4 form-section">
                    <div class="card-body">
                        <h5 class="card-title"><?= $edit_category ? 'ویرایش دسته‌بندی' : 'افزودن دسته‌بندی جدید' ?></h5>
                        <form method="POST">
                            <input type="hidden" name="id" value="<?= $edit_category['id'] ?? '' ?>">
                            <div class="mb-3">
                                <label for="name" class="form-label">نام دسته‌بندی</label>
                                <input type="text" class="form-control" id="name" name="name"
                                    value="<?= htmlspecialchars($edit_category['name'] ?? '') ?>" required>
                            </div>
                            <button type="submit" class="btn" style="background-color: #9c1e48; color: white;">
                                <i class="bi bi-save"></i> <?= $edit_category ? 'ذخیره تغییرات' : 'افزودن دسته‌بندی' ?>
                            </button>
                            <?php if($edit_category): ?>
                            <a href="admin_categories.php" class="btn btn-outline-secondary">انصراف</a>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>

                <!-- لیست دسته‌بندی‌ها -->
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title border-bottom pb-2 mb-4">لیست دسته‌بندی‌ها</h5>

                        <?php if(empty($categories)): ?>
                        <div class="alert alert-info">هیچ دسته‌بندی ثبت نشده است</div>
                        <?php else: ?>
                        <div class="row g-3">
                            <?php foreach($categories as $category): ?>
                            <div class="col-md-6">
                                <div class="card category-card h-100">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-start">
                                            <h5><?= htmlspecialchars($category['name']) ?></h5>
                                            <span class="badge product-count-badge">
                                                <?= $category['product_count'] ?> محصول
                                            </span>
                                        </div>
                                    </div>
                                    <div class="card-footer bg-transparent d-flex justify-content-end">
                                        <a href="admin_categories.php?edit=<?= $category['id'] ?>"
                                            class="btn btn-sm btn-outline-primary me-2">
                                            <i class="bi bi-pencil"></i> ویرایش
                                        </a>
                                        <a href="admin_categories.php?delete=<?= $category['id'] ?>"
                                            class="btn btn-sm btn-outline-danger"
                                            onclick="return confirm('آیا از حذف این دسته‌بندی اطمینان دارید؟')">
                                            <i class="bi bi-trash"></i> حذف
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>