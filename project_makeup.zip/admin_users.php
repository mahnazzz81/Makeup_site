<?php
session_start();
require_once 'db.php';

// بررسی آیا کاربر مدیر است یا نه
if(!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header('Location: login.php');
    exit;
}

// عملیات حذف کاربر
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    try {
        // بررسی وجود سفارشات برای این کاربر
        $check = $db->prepare("SELECT COUNT(*) FROM orders WHERE user_id = ?");
        $check->execute([$id]);
        $order_count = $check->fetchColumn();
        
        if($order_count > 0) {
            $_SESSION['error'] = "امکان حذف این کاربر وجود ندارد زیرا دارای سفارش است";
        } else {
            $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$id]);
            $_SESSION['success'] = "کاربر با موفقیت حذف شد";
        }
    } catch(PDOException $e) {
        $_SESSION['error'] = "خطا در حذف کاربر: " . $e->getMessage();
    }
    header('Location: admin_users.php');
    exit;
}

// عملیات تغییر نقش کاربر
if(isset($_GET['change_role'])) {
    $id = $_GET['user_id'];
    $new_role = $_GET['new_role'];
    
    try {
        $stmt = $db->prepare("UPDATE users SET role = ? WHERE id = ?");
        $stmt->execute([$new_role, $id]);
        $_SESSION['success'] = "نقش کاربر با موفقیت تغییر کرد";
    } catch(PDOException $e) {
        $_SESSION['error'] = "خطا در تغییر نقش کاربر: " . $e->getMessage();
    }
    header('Location: admin_users.php');
    exit;
}

// دریافت تمام کاربران
$users = $db->query("SELECT id, name, phone, role FROM users ORDER BY id DESC")->fetchAll();
?>

<!DOCTYPE html>
<html dir="rtl" lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت کاربران</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
    .user-card {
        transition: all 0.3s;
        border-left: 4px solid #9c1e48;
    }

    .user-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .role-badge {
        font-size: 0.85rem;
    }

    .role-admin {
        background-color: #9c1e48;
        color: white;
    }

    .role-user {
        background-color: #6c757d;
        color: white;
    }
    </style>
</head>

<body>
    <div class="container py-4">
        <div class="row g-4">
            <!-- سایدبار -->
            <div class="col-md-3">
                <div class="card shadow-sm sticky-top" style="top: 20px;">
                    <div class="card-body p-0">
                        <!-- منوی اصلی -->
                        <div class="list-group list-group-flush rounded">
                            <a href="dashboard.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-speedometer2 me-2"></i> داشبورد
                            </a>
                            <a href="admin_products.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-box-seam me-2"></i> محصولات
                            </a>
                            <a href="admin_categories.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-tags me-2"></i> دسته‌بندی‌ها
                            </a>
                            <a href="admin_subcategories.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-tag me-2"></i> زیردسته‌بندی‌ها
                            </a>
                            <a href="admin_orders.php" class="list-group-item list-group-item-action py-3">
                                <i class="bi bi-cart-check me-2"></i> سفارشات
                            </a>
                            <a href="admin_users.php" class="list-group-item list-group-item-action active py-3"
                                style="background-color: #9c1e48 !important; border:none !important;">
                                <i class="bi bi-people me-2"></i> کاربران
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- محتوای اصلی -->
            <div class="col-md-9">
                <!-- پیام‌های سیستم -->
                <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-danger"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
                <?php endif; ?>

                <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
                <?php endif; ?>

                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="mb-0">مدیریت کاربران</h4>
                </div>

                <!-- لیست کاربران -->
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>نام</th>
                                        <th>تلفن</th>
                                        <th>نقش</th>
                                        <th>تاریخ ثبت‌نام</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($users as $user): ?>
                                    <?php
                                        // تعیین کلاس نقش کاربر
                                        $role_class = [
                                            'admin' => 'role-admin',
                                            'user' => 'role-user'
                                        ][$user['role']] ?? '';
                                        
                                        // ترجمه نقش کاربر
                                        $role_text = [
                                            'admin' => 'مدیر',
                                            'user' => 'کاربر عادی'
                                        ][$user['role']] ?? $user['role'];
                                        ?>
                                    <tr>
                                        <td><?= $user['id'] ?></td>
                                        <td><?= htmlspecialchars($user['name']) ?></td>
                                        <td><?= htmlspecialchars($user['phone']) ?></td>
                                        <td>
                                            <span class="badge rounded-pill role-badge <?= $role_class ?>">
                                                <?= $role_text ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-sm btn-outline-secondary dropdown-toggle"
                                                    type="button" data-bs-toggle="dropdown">
                                                    تغییر نقش
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li><a class="dropdown-item"
                                                            href="admin_users.php?change_role=1&user_id=<?= $user['id'] ?>&new_role=admin">مدیر</a>
                                                    </li>
                                                    <li><a class="dropdown-item"
                                                            href="admin_users.php?change_role=1&user_id=<?= $user['id'] ?>&new_role=user">کاربر
                                                            عادی</a></li>
                                                </ul>
                                            </div>
                                            <a href="user_details.php?id=<?= $user['id'] ?>"
                                                class="btn btn-sm btn-outline-primary ms-2">
                                                جزئیات
                                            </a>
                                            <a href="admin_users.php?delete=<?= $user['id'] ?>"
                                                class="btn btn-sm btn-outline-danger ms-2"
                                                onclick="return confirm('آیا از حذف این کاربر اطمینان دارید؟')">
                                                حذف
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>